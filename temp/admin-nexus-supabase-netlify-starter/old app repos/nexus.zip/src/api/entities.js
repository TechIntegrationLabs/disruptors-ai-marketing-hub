import { base44 } from './base44Client';


export const SystemMetric = base44.entities.SystemMetric;

export const AIModule = base44.entities.AIModule;

export const MCPServer = base44.entities.MCPServer;

export const Repository = base44.entities.Repository;

export const DevService = base44.entities.DevService;

export const TelemetryEvent = base44.entities.TelemetryEvent;

export const AIPrediction = base44.entities.AIPrediction;

export const Page = base44.entities.Page;

export const BlogPost = base44.entities.BlogPost;

export const MediaAsset = base44.entities.MediaAsset;

export const Integration = base44.entities.Integration;

export const BrandRule = base44.entities.BrandRule;

export const BrainFact = base44.entities.BrainFact;



// auth sdk:
export const User = base44.auth;