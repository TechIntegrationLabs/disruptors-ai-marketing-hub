import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { TrendingUp, TrendingDown, Activity, Zap } from 'lucide-react';
import { LineChart, Line, ResponsiveContainer, Sparklines, SparklinesLine } from 'recharts';

const InteractiveMetricCard = ({
  title,
  value,
  change,
  changeType = 'percentage', // 'percentage', 'absolute', 'none'
  trend = 'up', // 'up', 'down', 'neutral'
  icon: Icon,
  sparklineData = [],
  color = 'cyan',
  size = 'default', // 'small', 'default', 'large'
  animated = true,
  onClick,
  className = ""
}) => {
  const [isHovered, setIsHovered] = useState(false);
  const [displayValue, setDisplayValue] = useState(0);

  const colorClasses = {
    cyan: {
      icon: 'text-cyan-400',
      trend: 'text-cyan-400',
      border: 'border-cyan-500/50',
      bg: 'bg-cyan-500/10',
      glow: 'shadow-cyan-500/20'
    },
    green: {
      icon: 'text-green-400',
      trend: 'text-green-400', 
      border: 'border-green-500/50',
      bg: 'bg-green-500/10',
      glow: 'shadow-green-500/20'
    },
    blue: {
      icon: 'text-blue-400',
      trend: 'text-blue-400',
      border: 'border-blue-500/50', 
      bg: 'bg-blue-500/10',
      glow: 'shadow-blue-500/20'
    },
    red: {
      icon: 'text-red-400',
      trend: 'text-red-400',
      border: 'border-red-500/50',
      bg: 'bg-red-500/10', 
      glow: 'shadow-red-500/20'
    },
    purple: {
      icon: 'text-purple-400',
      trend: 'text-purple-400',
      border: 'border-purple-500/50',
      bg: 'bg-purple-500/10',
      glow: 'shadow-purple-500/20'
    }
  };

  const sizeClasses = {
    small: 'p-4',
    default: 'p-6',
    large: 'p-8'
  };

  const colors = colorClasses[color] || colorClasses.cyan;

  // Animate value counting up
  useEffect(() => {
    if (!animated) {
      setDisplayValue(value);
      return;
    }

    const numericValue = typeof value === 'string' ? parseFloat(value.replace(/[^0-9.-]/g, '')) : value;
    if (isNaN(numericValue)) {
      setDisplayValue(value);
      return;
    }

    let start = 0;
    const duration = 1000; // 1 second
    const steps = 50;
    const stepValue = numericValue / steps;
    const stepTime = duration / steps;

    const timer = setInterval(() => {
      start += stepValue;
      if (start >= numericValue) {
        setDisplayValue(value);
        clearInterval(timer);
      } else {
        setDisplayValue(Math.floor(start));
      }
    }, stepTime);

    return () => clearInterval(timer);
  }, [value, animated]);

  const getTrendIcon = () => {
    switch(trend) {
      case 'up': return TrendingUp;
      case 'down': return TrendingDown;
      default: return Activity;
    }
  };

  const TrendIcon = getTrendIcon();

  return (
    <motion.div
      layout
      initial={{ opacity: 0, scale: 0.9, y: 20 }}
      animate={{ opacity: 1, scale: 1, y: 0 }}
      whileHover={{ 
        scale: 1.02, 
        y: -4,
        transition: { type: "spring", stiffness: 400, damping: 25 }
      }}
      whileTap={{ scale: 0.98 }}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      onClick={onClick}
      className={`cursor-pointer ${className}`}
    >
      <Card className={`
        bg-gray-800 border-gray-700 transition-all duration-300
        ${isHovered ? `${colors.border} ${colors.glow} shadow-lg` : ''}
        ${onClick ? 'cursor-pointer' : ''}
      `}>
        <CardContent className={sizeClasses[size]}>
          <div className="flex items-start justify-between">
            <div className="flex-1">
              <div className="flex items-center justify-between mb-2">
                <h3 className="text-sm font-medium text-gray-400">{title}</h3>
                {Icon && (
                  <motion.div
                    animate={{ 
                      rotate: isHovered ? 360 : 0,
                      scale: isHovered ? 1.1 : 1
                    }}
                    transition={{ duration: 0.6 }}
                    className={`${colors.icon}`}
                  >
                    <Icon size={size === 'large' ? 24 : size === 'small' ? 16 : 20} />
                  </motion.div>
                )}
              </div>
              
              <div className="space-y-2">
                <motion.div 
                  key={displayValue}
                  initial={animated ? { scale: 0.8, opacity: 0 } : false}
                  animate={{ scale: 1, opacity: 1 }}
                  className={`font-bold text-white ${
                    size === 'large' ? 'text-3xl' : size === 'small' ? 'text-lg' : 'text-2xl'
                  }`}
                >
                  {typeof displayValue === 'number' ? displayValue.toLocaleString() : displayValue}
                </motion.div>

                <div className="flex items-center justify-between">
                  {change && changeType !== 'none' && (
                    <motion.div 
                      initial={{ opacity: 0, x: -10 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: 0.3 }}
                      className={`flex items-center gap-1 text-xs ${
                        trend === 'up' ? 'text-green-400' : 
                        trend === 'down' ? 'text-red-400' : 
                        'text-gray-400'
                      }`}
                    >
                      <TrendIcon size={12} />
                      <span>{change}</span>
                      {changeType === 'percentage' && <span>vs last period</span>}
                    </motion.div>
                  )}

                  {sparklineData.length > 0 && (
                    <div className="w-16 h-8">
                      <ResponsiveContainer width="100%" height="100%">
                        <LineChart data={sparklineData}>
                          <Line 
                            type="monotone" 
                            dataKey="value" 
                            stroke={`var(--${color}-400)`} 
                            strokeWidth={2} 
                            dot={false}
                          />
                        </LineChart>
                      </ResponsiveContainer>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>

          <AnimatePresence>
            {isHovered && onClick && (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: 10 }}
                className="mt-4 pt-4 border-t border-gray-700"
              >
                <div className="flex items-center text-cyan-400 text-xs">
                  <Zap size={12} className="mr-1" />
                  Click to explore
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default InteractiveMetricCard;