import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  TrendingUp, 
  Activity, 
  Users, 
  Eye, 
  MousePointerClick,
  BarChart3,
  PieChart,
  LineChart,
  Settings
} from 'lucide-react';
import AdvancedLineChart from './AdvancedLineChart';
import InteractiveMetricCard from './InteractiveMetricCard';

const AdvancedDashboard = ({ 
  metrics = [], 
  chartData = [], 
  chartConfigs = [],
  className = "" 
}) => {
  const [selectedChart, setSelectedChart] = useState(0);
  const [timeRange, setTimeRange] = useState('7d');

  const timeRanges = [
    { id: '24h', label: '24 Hours' },
    { id: '7d', label: '7 Days' },
    { id: '30d', label: '30 Days' },
    { id: '90d', label: '90 Days' }
  ];

  return (
    <div className={`space-y-6 ${className}`}>
      {/* Time Range Selector */}
      <motion.div 
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex items-center justify-between"
      >
        <h2 className="text-xl font-semibold text-white">Analytics Dashboard</h2>
        <div className="flex items-center gap-2">
          {timeRanges.map((range, index) => (
            <motion.div
              key={range.id}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <Button
                variant={timeRange === range.id ? "default" : "outline"}
                size="sm"
                onClick={() => setTimeRange(range.id)}
                className={`text-xs transition-all duration-200 ${
                  timeRange === range.id 
                    ? 'bg-gradient-to-r from-cyan-600 to-blue-600 text-white shadow-lg' 
                    : 'border-gray-600 text-gray-300 hover:border-cyan-500/50 hover:text-cyan-400'
                }`}
              >
                {range.label}
              </Button>
            </motion.div>
          ))}
        </div>
      </motion.div>

      {/* Metrics Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {metrics.map((metric, index) => (
          <InteractiveMetricCard
            key={metric.id || index}
            title={metric.title}
            value={metric.value}
            change={metric.change}
            trend={metric.trend}
            icon={metric.icon}
            color={metric.color}
            sparklineData={metric.sparklineData}
            animated={true}
            onClick={metric.onClick}
          />
        ))}
      </div>

      {/* Main Chart Area */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
      >
        <Card className="bg-gray-800 border-gray-700">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="text-white flex items-center gap-2">
                <BarChart3 className="w-5 h-5 text-cyan-400" />
                Performance Overview
              </CardTitle>
              <div className="flex items-center gap-2">
                <Badge variant="outline" className="text-cyan-400 border-cyan-500/50">
                  Live Data
                </Badge>
                <Button variant="ghost" size="sm" className="text-gray-400 hover:text-white">
                  <Settings size={16} />
                </Button>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <AdvancedLineChart
              data={chartData}
              lines={[
                { 
                  dataKey: 'views', 
                  stroke: '#00D4FF', 
                  name: 'Page Views',
                  strokeWidth: 3
                },
                { 
                  dataKey: 'users', 
                  stroke: '#10B981', 
                  name: 'Users',
                  strokeWidth: 3
                },
                { 
                  dataKey: 'conversions', 
                  stroke: '#8B5CF6', 
                  name: 'Conversions',
                  strokeWidth: 3
                }
              ]}
              height={400}
              showGrid={true}
              showLegend={true}
              animate={true}
              gradientFill={false}
              showTrend={true}
            />
          </CardContent>
        </Card>
      </motion.div>

      {/* Secondary Charts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.5 }}
        >
          <Card className="bg-gray-800 border-gray-700 h-full">
            <CardHeader>
              <CardTitle className="text-white text-sm">Traffic Sources</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {[
                  { source: 'Organic Search', value: 45.2, color: '#00D4FF' },
                  { source: 'Direct Traffic', value: 28.7, color: '#10B981' },
                  { source: 'Social Media', value: 15.8, color: '#8B5CF6' },
                  { source: 'Email', value: 10.3, color: '#F59E0B' }
                ].map((item, index) => (
                  <motion.div
                    key={item.source}
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.6 + index * 0.1 }}
                    className="flex items-center justify-between"
                  >
                    <div className="flex items-center gap-3">
                      <div 
                        className="w-3 h-3 rounded-full"
                        style={{ backgroundColor: item.color }}
                      />
                      <span className="text-gray-300 text-sm">{item.source}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-24 h-2 bg-gray-700 rounded-full overflow-hidden">
                        <motion.div
                          initial={{ width: 0 }}
                          animate={{ width: `${item.value}%` }}
                          transition={{ delay: 0.8 + index * 0.1, duration: 0.8 }}
                          className="h-full rounded-full"
                          style={{ backgroundColor: item.color }}
                        />
                      </div>
                      <span className="text-white text-sm font-medium w-12 text-right">
                        {item.value}%
                      </span>
                    </div>
                  </motion.div>
                ))}
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.7 }}
        >
          <Card className="bg-gray-800 border-gray-700 h-full">
            <CardHeader>
              <CardTitle className="text-white text-sm">Top Pages</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {[
                  { path: '/home', views: 12450, change: '+12%' },
                  { path: '/services', views: 8920, change: '+5%' },
                  { path: '/blog', views: 6780, change: '-2%' },
                  { path: '/contact', views: 4320, change: '+18%' }
                ].map((page, index) => (
                  <motion.div
                    key={page.path}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.8 + index * 0.1 }}
                    whileHover={{ scale: 1.02, x: 4 }}
                    className="flex items-center justify-between p-2 rounded-lg hover:bg-gray-700/50 transition-all duration-200 cursor-pointer"
                  >
                    <div>
                      <span className="text-white font-medium">{page.path}</span>
                      <div className="text-xs text-gray-400">
                        {page.views.toLocaleString()} views
                      </div>
                    </div>
                    <Badge 
                      variant="outline" 
                      className={`text-xs ${
                        page.change.startsWith('+') ? 'text-green-400 border-green-500/50' : 'text-red-400 border-red-500/50'
                      }`}
                    >
                      {page.change}
                    </Badge>
                  </motion.div>
                ))}
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
};

export default AdvancedDashboard;