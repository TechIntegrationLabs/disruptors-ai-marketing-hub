import React, { useState, useEffect } from 'react';
import { ResponsiveContainer, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, Area, AreaChart } from 'recharts';
import { motion, AnimatePresence } from 'framer-motion';
import { TrendingUp, TrendingDown, Activity } from 'lucide-react';

const CustomTooltip = ({ active, payload, label }) => {
  if (active && payload && payload.length) {
    return (
      <motion.div
        initial={{ opacity: 0, scale: 0.8, y: 10 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.8, y: 10 }}
        className="bg-gray-800/95 backdrop-blur-sm border border-cyan-500/30 rounded-lg p-4 shadow-xl"
        style={{ zIndex: 1000 }}
      >
        <p className="text-cyan-400 font-semibold mb-2">{label}</p>
        {payload.map((entry, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, x: -10 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: index * 0.05 }}
            className="flex items-center justify-between gap-4 mb-1"
          >
            <div className="flex items-center gap-2">
              <div 
                className="w-3 h-3 rounded-full"
                style={{ backgroundColor: entry.color }}
              />
              <span className="text-gray-300 text-sm">{entry.name}:</span>
            </div>
            <span className="text-white font-medium">
              {typeof entry.value === 'number' ? entry.value.toLocaleString() : entry.value}
            </span>
          </motion.div>
        ))}
      </motion.div>
    );
  }
  return null;
};

const AdvancedLineChart = ({ 
  data, 
  lines = [], 
  height = 300, 
  showGrid = true, 
  showLegend = true,
  animate = true,
  gradientFill = false,
  showTrend = true,
  className = ""
}) => {
  const [hoveredPoint, setHoveredPoint] = useState(null);
  const [chartData, setChartData] = useState([]);

  useEffect(() => {
    if (animate) {
      // Animate data entry
      const timer = setTimeout(() => {
        setChartData(data);
      }, 100);
      return () => clearTimeout(timer);
    } else {
      setChartData(data);
    }
  }, [data, animate]);

  const calculateTrend = (data, dataKey) => {
    if (!data || data.length < 2) return 0;
    const values = data.map(d => d[dataKey]).filter(v => typeof v === 'number');
    if (values.length < 2) return 0;
    return ((values[values.length - 1] - values[0]) / values[0]) * 100;
  };

  const CustomDot = ({ cx, cy, stroke, fill, payload, dataKey }) => {
    return (
      <motion.circle
        cx={cx}
        cy={cy}
        r={hoveredPoint === `${cx}-${cy}` ? 6 : 0}
        fill={fill}
        stroke={stroke}
        strokeWidth={2}
        initial={{ r: 0, opacity: 0 }}
        animate={{ 
          r: hoveredPoint === `${cx}-${cy}` ? 6 : 3,
          opacity: hoveredPoint === `${cx}-${cy}` ? 1 : 0
        }}
        transition={{ type: "spring", stiffness: 300, damping: 20 }}
        onMouseEnter={() => setHoveredPoint(`${cx}-${cy}`)}
        onMouseLeave={() => setHoveredPoint(null)}
        className="drop-shadow-lg"
      />
    );
  };

  const ChartComponent = gradientFill ? AreaChart : LineChart;

  return (
    <div className={`relative ${className}`}>
      {showTrend && lines.length > 0 && (
        <div className="flex gap-4 mb-4">
          {lines.map((line, index) => {
            const trend = calculateTrend(data, line.dataKey);
            const isPositive = trend >= 0;
            return (
              <motion.div
                key={line.dataKey}
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="flex items-center gap-2"
              >
                <div 
                  className="w-3 h-3 rounded-full"
                  style={{ backgroundColor: line.stroke }}
                />
                <span className="text-gray-400 text-sm">{line.name}</span>
                <div className={`flex items-center gap-1 ${isPositive ? 'text-green-400' : 'text-red-400'}`}>
                  {isPositive ? <TrendingUp size={14} /> : <TrendingDown size={14} />}
                  <span className="text-sm font-medium">{Math.abs(trend).toFixed(1)}%</span>
                </div>
              </motion.div>
            );
          })}
        </div>
      )}
      
      <ResponsiveContainer width="100%" height={height}>
        <ChartComponent data={chartData} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
          {showGrid && (
            <CartesianGrid 
              strokeDasharray="3 3" 
              stroke="#374151" 
              strokeOpacity={0.3}
            />
          )}
          <XAxis 
            dataKey="name" 
            stroke="#6B7280" 
            fontSize={12}
            tickLine={false}
            axisLine={false}
          />
          <YAxis 
            stroke="#6B7280" 
            fontSize={12}
            tickLine={false}
            axisLine={false}
            tickFormatter={(value) => typeof value === 'number' ? value.toLocaleString() : value}
          />
          <Tooltip content={<CustomTooltip />} />
          {showLegend && <Legend />}
          
          {lines.map((line, index) => (
            gradientFill ? (
              <Area
                key={line.dataKey}
                type="monotone"
                dataKey={line.dataKey}
                stroke={line.stroke}
                fill={`url(#gradient-${index})`}
                strokeWidth={3}
                dot={<CustomDot />}
                activeDot={{ 
                  r: 6, 
                  fill: line.stroke,
                  stroke: '#ffffff',
                  strokeWidth: 2
                }}
              />
            ) : (
              <Line
                key={line.dataKey}
                type="monotone"
                dataKey={line.dataKey}
                stroke={line.stroke}
                strokeWidth={3}
                dot={<CustomDot />}
                activeDot={{ 
                  r: 6, 
                  fill: line.stroke,
                  stroke: '#ffffff',
                  strokeWidth: 2
                }}
              />
            )
          ))}
          
          {/* Gradient definitions */}
          <defs>
            {lines.map((line, index) => (
              <linearGradient key={index} id={`gradient-${index}`} x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor={line.stroke} stopOpacity={0.3} />
                <stop offset="95%" stopColor={line.stroke} stopOpacity={0} />
              </linearGradient>
            ))}
          </defs>
        </ChartComponent>
      </ResponsiveContainer>
    </div>
  );
};

export default AdvancedLineChart;