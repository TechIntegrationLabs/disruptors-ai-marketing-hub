import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Factory, Zap, Eye, Send } from 'lucide-react';
import { AnimatePresence, motion } from 'framer-motion';

const sampleQueries = [
    { query: "how to choose a headless cms", intent: "informational", funnel: "top", volume: 850 },
    { query: "best headless cms for small business", intent: "commercial", funnel: "middle", volume: 420 },
    { query: "headless cms pricing comparison", intent: "transactional", funnel: "bottom", volume: 280 },
];

export default function LongTailPageFactory() {
    const [keyword, setKeyword] = useState('');
    const [intent, setIntent] = useState('');
    const [isGenerating, setIsGenerating] = useState(false);
    const [generatedPage, setGeneratedPage] = useState(null);

    const handleGenerate = () => {
        if (!keyword || !intent) return;
        setIsGenerating(true);
        setGeneratedPage(null);
        
        setTimeout(() => {
            setGeneratedPage({
                title: `${keyword.charAt(0).toUpperCase() + keyword.slice(1)} - Complete Guide 2025`,
                slug: `/${keyword.replace(/\s+/g, '-').toLowerCase()}`,
                metaDescription: `Everything you need to know about ${keyword}. Expert insights, comparisons, and actionable advice.`,
                content: `# ${keyword.charAt(0).toUpperCase() + keyword.slice(1)} - Complete Guide 2025

## What You Need to Know About ${keyword}

When it comes to ${keyword}, there are several key factors to consider...

## Why ${keyword} Matters for Your Business

Understanding ${keyword} can significantly impact your business operations...

## Step-by-Step Guide

1. **Research and Planning**
   - Identify your specific needs
   - Set clear objectives
   
2. **Implementation**
   - Choose the right approach
   - Execute systematically
   
3. **Optimization**
   - Monitor performance
   - Make data-driven adjustments

## Frequently Asked Questions

**Q: How long does ${keyword} typically take?**
A: The timeline depends on various factors, but most implementations take 2-4 weeks.

**Q: What are the costs involved?**
A: Costs vary based on scope and requirements, ranging from basic to enterprise levels.`,
                cta: intent === 'transactional' ? 'Get Started Free' : intent === 'commercial' ? 'Learn More' : 'Download Guide'
            });
            setIsGenerating(false);
        }, 2000);
    };

    return (
        <div className="p-6 h-full flex text-white bg-gray-900">
            <div className="w-1/3 pr-6 space-y-4">
                <h3 className="text-lg font-semibold">Page Generator</h3>
                <Input
                    placeholder="Enter target keyword"
                    value={keyword}
                    onChange={(e) => setKeyword(e.target.value)}
                    className="bg-gray-800 border-gray-600 text-white"
                />
                <Select value={intent} onValueChange={setIntent}>
                    <SelectTrigger className="bg-gray-800 border-gray-600 text-white">
                        <SelectValue placeholder="Select search intent" />
                    </SelectTrigger>
                    <SelectContent className="bg-gray-800 border-gray-600 text-white">
                        <SelectItem value="informational">Informational</SelectItem>
                        <SelectItem value="commercial">Commercial</SelectItem>
                        <SelectItem value="transactional">Transactional</SelectItem>
                    </SelectContent>
                </Select>
                <Button 
                    onClick={handleGenerate} 
                    disabled={isGenerating || !keyword || !intent}
                    className="w-full bg-cyan-600 hover:bg-cyan-700"
                >
                    <Factory className="mr-2 h-4 w-4" />
                    {isGenerating ? "Generating..." : "Generate Page"}
                </Button>

                <Card className="bg-gray-800 border-gray-700 mt-6">
                    <CardHeader>
                        <CardTitle className="text-sm">Quick Ideas</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-2">
                        {sampleQueries.map((q, index) => (
                            <div 
                                key={index}
                                className="p-2 bg-gray-700 rounded cursor-pointer hover:bg-gray-600 text-xs"
                                onClick={() => {
                                    setKeyword(q.query);
                                    setIntent(q.intent);
                                }}
                            >
                                <p className="text-white">{q.query}</p>
                                <div className="flex gap-2 mt-1">
                                    <Badge className="text-xs" variant="outline">{q.intent}</Badge>
                                    <Badge className="text-xs" variant="outline">{q.volume}/mo</Badge>
                                </div>
                            </div>
                        ))}
                    </CardContent>
                </Card>
            </div>

            <div className="flex-1 overflow-y-auto">
                {isGenerating && (
                    <div className="flex items-center justify-center h-full text-gray-400">
                        <div className="text-center">
                            <Factory className="w-12 h-12 mx-auto mb-4 animate-pulse" />
                            <p>Generating optimized content...</p>
                            <p className="text-sm mt-2">Analyzing intent, structuring content, adding CTAs...</p>
                        </div>
                    </div>
                )}
                
                <AnimatePresence>
                {generatedPage && (
                    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
                        <Card className="bg-gray-800 border-gray-700 mb-4">
                            <CardHeader>
                                <div className="flex justify-between items-start">
                                    <div>
                                        <CardTitle className="text-white">{generatedPage.title}</CardTitle>
                                        <p className="text-sm text-gray-400 mt-1">{generatedPage.slug}</p>
                                        <p className="text-sm text-gray-400 mt-2">{generatedPage.metaDescription}</p>
                                    </div>
                                    <div className="flex gap-2">
                                        <Button size="sm" variant="outline">
                                            <Eye className="mr-2 h-3 w-3" /> Preview
                                        </Button>
                                        <Button size="sm" className="bg-cyan-600 hover:bg-cyan-700">
                                            <Send className="mr-2 h-3 w-3" /> Publish
                                        </Button>
                                    </div>
                                </div>
                            </CardHeader>
                            <CardContent>
                                <div className="bg-gray-700 p-4 rounded font-mono text-sm text-gray-300 max-h-96 overflow-y-auto">
                                    <pre className="whitespace-pre-wrap">{generatedPage.content}</pre>
                                </div>
                                <div className="mt-4 p-3 bg-cyan-600/20 rounded border border-cyan-500/30">
                                    <p className="text-cyan-400 font-medium">Primary CTA: {generatedPage.cta}</p>
                                </div>
                            </CardContent>
                        </Card>
                    </motion.div>
                )}
                </AnimatePresence>

                {!isGenerating && !generatedPage && (
                    <div className="flex items-center justify-center h-full text-center text-gray-500">
                        <div>
                            <Factory className="w-16 h-16 mx-auto mb-4"/>
                            <h3 className="text-lg font-semibold">Generated pages will appear here</h3>
                            <p>Enter a keyword and select intent to begin.</p>
                        </div>
                    </div>
                )}
            </div>
        </div>
    );
}