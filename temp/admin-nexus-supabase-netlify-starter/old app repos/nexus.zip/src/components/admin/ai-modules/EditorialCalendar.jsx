import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Calendar } from "@/components/ui/calendar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { 
  Calendar as CalendarIcon, 
  Plus, 
  Users, 
  Clock,
  CheckCircle,
  AlertTriangle,
  Filter,
  Eye,
  Edit,
  BarChart3
} from 'lucide-react';
import { motion } from 'framer-motion';

const mockContentPlan = [
  {
    id: 'c1',
    title: 'Ultimate Guide to Technical SEO',
    type: 'blog',
    status: 'in-progress',
    assignee: 'Sarah Chen',
    dueDate: '2025-01-20',
    wave: 'Q1 Content Push',
    dependencies: ['c2'],
    priority: 'high',
    keywords: ['technical SEO', 'site audit', 'crawling']
  },
  {
    id: 'c2',
    title: 'SEO Tools Comparison 2025',
    type: 'resource',
    status: 'completed',
    assignee: 'Mike Johnson',
    dueDate: '2025-01-15',
    wave: 'Q1 Content Push',
    dependencies: [],
    priority: 'medium',
    keywords: ['SEO tools', 'comparison', 'review']
  },
  {
    id: 'c3',
    title: 'Local SEO Checklist',
    type: 'checklist',
    status: 'scheduled',
    assignee: 'Emma Wilson',
    dueDate: '2025-01-25',
    wave: 'Q1 Content Push',
    dependencies: ['c1'],
    priority: 'medium',
    keywords: ['local SEO', 'GMB', 'citations']
  },
  {
    id: 'c4',
    title: 'Content Marketing ROI Calculator',
    type: 'tool',
    status: 'planning',
    assignee: 'David Lee',
    dueDate: '2025-02-01',
    wave: 'Q1 Content Push',
    dependencies: [],
    priority: 'low',
    keywords: ['ROI', 'calculator', 'content marketing']
  }
];

const mockWaves = [
  {
    id: 'w1',
    name: 'Q1 Content Push',
    startDate: '2025-01-15',
    endDate: '2025-03-31',
    totalItems: 12,
    completedItems: 3,
    status: 'active'
  },
  {
    id: 'w2',
    name: 'Product Launch Series',
    startDate: '2025-02-01',
    endDate: '2025-02-28',
    totalItems: 6,
    completedItems: 0,
    status: 'scheduled'
  },
  {
    id: 'w3',
    name: 'Summer Campaign',
    startDate: '2025-06-01',
    endDate: '2025-08-31',
    totalItems: 15,
    completedItems: 0,
    status: 'planning'
  }
];

const CalendarView = ({ contentItems, onItemClick }) => {
  const [selectedDate, setSelectedDate] = useState(new Date());
  
  const getItemsForDate = (date) => {
    const dateStr = date.toISOString().split('T')[0];
    return contentItems.filter(item => item.dueDate === dateStr);
  };

  const selectedDateItems = getItemsForDate(selectedDate);

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      <div className="lg:col-span-1">
        <Card className="bg-gray-800 border-gray-700">
          <CardHeader>
            <CardTitle className="text-white">Editorial Calendar</CardTitle>
          </CardHeader>
          <CardContent>
            <Calendar
              mode="single"
              selected={selectedDate}
              onSelect={setSelectedDate}
              className="rounded-md border border-gray-600"
            />
          </CardContent>
        </Card>
      </div>
      
      <div className="lg:col-span-2 space-y-4">
        <Card className="bg-gray-800 border-gray-700">
          <CardHeader>
            <CardTitle className="text-white">
              {selectedDate.toLocaleDateString('en-US', { 
                weekday: 'long', 
                year: 'numeric', 
                month: 'long', 
                day: 'numeric' 
              })}
            </CardTitle>
          </CardHeader>
          <CardContent>
            {selectedDateItems.length > 0 ? (
              <div className="space-y-3">
                {selectedDateItems.map(item => (
                  <div 
                    key={item.id}
                    onClick={() => onItemClick(item)}
                    className="p-4 bg-gray-700 rounded-lg cursor-pointer hover:bg-gray-600 transition-colors"
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <h4 className="font-medium text-white mb-1">{item.title}</h4>
                        <div className="flex items-center gap-3 text-sm text-gray-400">
                          <span className="flex items-center gap-1">
                            <Users size={12} />
                            {item.assignee}
                          </span>
                          <Badge variant="outline" className="text-xs">
                            {item.type}
                          </Badge>
                        </div>
                      </div>
                      <Badge className={
                        item.priority === 'high' ? 'bg-red-500/20 text-red-400' :
                        item.priority === 'medium' ? 'bg-yellow-500/20 text-yellow-400' :
                        'bg-green-500/20 text-green-400'
                      }>
                        {item.priority}
                      </Badge>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center text-gray-500 py-8">
                <CalendarIcon className="w-12 h-12 mx-auto mb-4 opacity-50" />
                <p>No content scheduled for this date</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

const WaveManager = ({ waves, contentItems }) => (
  <div className="space-y-6">
    <div className="flex items-center justify-between">
      <h3 className="text-lg font-semibold text-white">Publishing Waves</h3>
      <Button className="bg-cyan-600 hover:bg-cyan-700">
        <Plus size={16} className="mr-2" />
        New Wave
      </Button>
    </div>
    
    <div className="grid gap-6">
      {waves.map(wave => {
        const waveItems = contentItems.filter(item => item.wave === wave.name);
        const progress = wave.totalItems > 0 ? (wave.completedItems / wave.totalItems) * 100 : 0;
        
        return (
          <Card key={wave.id} className="bg-gray-800 border-gray-700">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-white">{wave.name}</CardTitle>
                <Badge className={
                  wave.status === 'active' ? 'bg-green-500/20 text-green-400' :
                  wave.status === 'scheduled' ? 'bg-blue-500/20 text-blue-400' :
                  'bg-gray-500/20 text-gray-400'
                }>
                  {wave.status}
                </Badge>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="text-center">
                  <div className="text-2xl font-bold text-white">{wave.completedItems}</div>
                  <div className="text-sm text-gray-400">Completed</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-blue-400">{wave.totalItems - wave.completedItems}</div>
                  <div className="text-sm text-gray-400">Remaining</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-cyan-400">{Math.round(progress)}%</div>
                  <div className="text-sm text-gray-400">Progress</div>
                </div>
              </div>
              
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-gray-400">Timeline</span>
                  <span className="text-white">{wave.startDate} → {wave.endDate}</span>
                </div>
                <div className="w-full bg-gray-700 rounded-full h-2">
                  <div 
                    className="bg-cyan-600 h-2 rounded-full transition-all duration-300"
                    style={{ width: `${progress}%` }}
                  />
                </div>
              </div>
              
              <div className="space-y-2">
                {waveItems.slice(0, 3).map(item => (
                  <div key={item.id} className="flex items-center justify-between p-2 bg-gray-700 rounded">
                    <span className="text-white text-sm">{item.title}</span>
                    <Badge variant="outline" className={
                      item.status === 'completed' ? 'text-green-400 border-green-500/50' :
                      item.status === 'in-progress' ? 'text-blue-400 border-blue-500/50' :
                      item.status === 'scheduled' ? 'text-yellow-400 border-yellow-500/50' :
                      'text-gray-400 border-gray-500/50'
                    }>
                      {item.status}
                    </Badge>
                  </div>
                ))}
                {waveItems.length > 3 && (
                  <div className="text-center text-sm text-gray-400">
                    +{waveItems.length - 3} more items
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        );
      })}
    </div>
  </div>
);

const ContentPlanner = ({ contentItems, onAddContent }) => {
  const [filterStatus, setFilterStatus] = useState('all');
  const [filterAssignee, setFilterAssignee] = useState('all');
  
  const filteredItems = contentItems.filter(item => {
    const statusMatch = filterStatus === 'all' || item.status === filterStatus;
    const assigneeMatch = filterAssignee === 'all' || item.assignee === filterAssignee;
    return statusMatch && assigneeMatch;
  });

  const assignees = [...new Set(contentItems.map(item => item.assignee))];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold text-white">Content Pipeline</h3>
        <div className="flex gap-3">
          <Select value={filterStatus} onValueChange={setFilterStatus}>
            <SelectTrigger className="w-40 bg-gray-800 border-gray-600 text-white">
              <SelectValue />
            </SelectTrigger>
            <SelectContent className="bg-gray-800 border-gray-600">
              <SelectItem value="all">All Status</SelectItem>
              <SelectItem value="planning">Planning</SelectItem>
              <SelectItem value="in-progress">In Progress</SelectItem>
              <SelectItem value="scheduled">Scheduled</SelectItem>
              <SelectItem value="completed">Completed</SelectItem>
            </SelectContent>
          </Select>
          
          <Select value={filterAssignee} onValueChange={setFilterAssignee}>
            <SelectTrigger className="w-40 bg-gray-800 border-gray-600 text-white">
              <SelectValue />
            </SelectTrigger>
            <SelectContent className="bg-gray-800 border-gray-600">
              <SelectItem value="all">All Assignees</SelectItem>
              {assignees.map(assignee => (
                <SelectItem key={assignee} value={assignee}>{assignee}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          
          <Button onClick={onAddContent} className="bg-cyan-600 hover:bg-cyan-700">
            <Plus size={16} className="mr-2" />
            Add Content
          </Button>
        </div>
      </div>
      
      <div className="grid gap-4">
        {filteredItems.map(item => (
          <Card key={item.id} className="bg-gray-800 border-gray-700">
            <CardContent className="p-4">
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-2">
                    <h4 className="font-medium text-white">{item.title}</h4>
                    <Badge variant="outline" className="text-xs">
                      {item.type}
                    </Badge>
                    <Badge className={
                      item.priority === 'high' ? 'bg-red-500/20 text-red-400' :
                      item.priority === 'medium' ? 'bg-yellow-500/20 text-yellow-400' :
                      'bg-green-500/20 text-green-400'
                    }>
                      {item.priority}
                    </Badge>
                  </div>
                  
                  <div className="flex items-center gap-4 text-sm text-gray-400">
                    <span className="flex items-center gap-1">
                      <Users size={12} />
                      {item.assignee}
                    </span>
                    <span className="flex items-center gap-1">
                      <CalendarIcon size={12} />
                      Due: {item.dueDate}
                    </span>
                    <span>Wave: {item.wave}</span>
                  </div>
                  
                  {item.keywords.length > 0 && (
                    <div className="flex flex-wrap gap-1 mt-2">
                      {item.keywords.map((keyword, index) => (
                        <Badge key={index} variant="outline" className="text-xs text-purple-400 border-purple-500/50">
                          {keyword}
                        </Badge>
                      ))}
                    </div>
                  )}
                </div>
                
                <div className="flex items-center gap-4">
                  <Badge className={
                    item.status === 'completed' ? 'bg-green-500/20 text-green-400' :
                    item.status === 'in-progress' ? 'bg-blue-500/20 text-blue-400' :
                    item.status === 'scheduled' ? 'bg-yellow-500/20 text-yellow-400' :
                    'bg-gray-500/20 text-gray-400'
                  }>
                    {item.status === 'completed' && <CheckCircle size={12} className="mr-1" />}
                    {item.status === 'in-progress' && <Clock size={12} className="mr-1" />}
                    {item.status === 'scheduled' && <CalendarIcon size={12} className="mr-1" />}
                    {item.status === 'planning' && <AlertTriangle size={12} className="mr-1" />}
                    {item.status}
                  </Badge>
                  
                  <div className="flex gap-1">
                    <Button size="sm" variant="ghost" className="text-gray-400 hover:text-white">
                      <Eye size={14} />
                    </Button>
                    <Button size="sm" variant="ghost" className="text-gray-400 hover:text-white">
                      <Edit size={14} />
                    </Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default function EditorialCalendar() {
  const [activeTab, setActiveTab] = useState('calendar');
  const [selectedItem, setSelectedItem] = useState(null);

  const handleItemClick = (item) => {
    setSelectedItem(item);
  };

  const handleAddContent = () => {
    console.log('Adding new content item');
  };

  return (
    <div className="p-6 h-full bg-gray-900 text-white">
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <div className="flex items-center justify-between mb-6">
          <TabsList className="bg-gray-800 border-gray-700">
            <TabsTrigger value="calendar" className="data-[state=active]:bg-cyan-600">
              Calendar View
            </TabsTrigger>
            <TabsTrigger value="waves" className="data-[state=active]:bg-cyan-600">
              Publishing Waves
            </TabsTrigger>
            <TabsTrigger value="pipeline" className="data-[state=active]:bg-cyan-600">
              Content Pipeline
            </TabsTrigger>
          </TabsList>
          <Button className="bg-cyan-600 hover:bg-cyan-700">
            <BarChart3 size={16} className="mr-2" />
            View Reports
          </Button>
        </div>

        <TabsContent value="calendar">
          <CalendarView contentItems={mockContentPlan} onItemClick={handleItemClick} />
        </TabsContent>

        <TabsContent value="waves">
          <WaveManager waves={mockWaves} contentItems={mockContentPlan} />
        </TabsContent>

        <TabsContent value="pipeline">
          <ContentPlanner contentItems={mockContentPlan} onAddContent={handleAddContent} />
        </TabsContent>
      </Tabs>
    </div>
  );
}