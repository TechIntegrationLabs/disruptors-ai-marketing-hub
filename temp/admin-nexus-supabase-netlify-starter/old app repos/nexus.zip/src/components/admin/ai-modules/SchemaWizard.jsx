import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Code, CheckCircle, AlertTriangle, Copy, Sparkles } from 'lucide-react';
import { AnimatePresence, motion } from 'framer-motion';

const schemaTypes = [
  { value: 'article', label: 'Article', description: 'News articles, blog posts, research papers' },
  { value: 'product', label: 'Product', description: 'E-commerce products, services' },
  { value: 'organization', label: 'Organization', description: 'Companies, nonprofits, schools' },
  { value: 'person', label: 'Person', description: 'Individual profiles and bios' },
  { value: 'event', label: 'Event', description: 'Conferences, concerts, webinars' },
  { value: 'faq', label: 'FAQ Page', description: 'Frequently Asked Questions' },
  { value: 'breadcrumb', label: 'Breadcrumb List', description: 'Navigation breadcrumbs' },
];

const sampleSchema = {
  article: `{
  "@context": "https://schema.org",
  "@type": "Article",
  "headline": "How to Implement Schema Markup",
  "description": "A comprehensive guide to implementing structured data",
  "image": "https://example.com/image.jpg",
  "author": {
    "@type": "Person",
    "name": "John Smith"
  },
  "publisher": {
    "@type": "Organization",
    "name": "Your Website",
    "logo": {
      "@type": "ImageObject",
      "url": "https://example.com/logo.png"
    }
  },
  "datePublished": "2025-01-01",
  "dateModified": "2025-01-01"
}`,
  product: `{
  "@context": "https://schema.org",
  "@type": "Product",
  "name": "Amazing Product",
  "description": "This product will change your life",
  "image": "https://example.com/product.jpg",
  "brand": {
    "@type": "Brand",
    "name": "Your Brand"
  },
  "offers": {
    "@type": "Offer",
    "price": "99.99",
    "priceCurrency": "USD",
    "availability": "https://schema.org/InStock"
  }
}`,
};

export default function SchemaWizard() {
  const [selectedType, setSelectedType] = useState('');
  const [pageUrl, setPageUrl] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedSchema, setGeneratedSchema] = useState('');
  const [validation, setValidation] = useState(null);

  const handleGenerate = () => {
    if (!selectedType || !pageUrl) return;
    setIsGenerating(true);
    setGeneratedSchema('');
    setValidation(null);
    
    setTimeout(() => {
      const schema = sampleSchema[selectedType] || sampleSchema.article;
      setGeneratedSchema(schema);
      setValidation({
        isValid: true,
        warnings: Math.floor(Math.random() * 3),
        richResults: ['Rich Snippets', 'Knowledge Panel', 'Featured Snippet']
      });
      setIsGenerating(false);
    }, 1500);
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(generatedSchema);
  };

  return (
    <div className="p-6 h-full flex text-white bg-gray-900">
      <div className="w-1/2 pr-6 space-y-4">
        <h3 className="text-lg font-semibold flex items-center gap-2">
          <Code className="text-cyan-400" />
          Schema Generator
        </h3>
        
        <Input
          placeholder="Enter page URL to analyze"
          value={pageUrl}
          onChange={(e) => setPageUrl(e.target.value)}
          className="bg-gray-800 border-gray-600 text-white"
        />
        
        <Select value={selectedType} onValueChange={setSelectedType}>
          <SelectTrigger className="bg-gray-800 border-gray-600 text-white">
            <SelectValue placeholder="Select schema type" />
          </SelectTrigger>
          <SelectContent className="bg-gray-800 border-gray-600 text-white">
            {schemaTypes.map(type => (
              <SelectItem key={type.value} value={type.value}>
                <div>
                  <div className="font-medium">{type.label}</div>
                  <div className="text-xs text-gray-400">{type.description}</div>
                </div>
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        
        <Button 
          onClick={handleGenerate} 
          disabled={isGenerating || !selectedType || !pageUrl}
          className="w-full bg-cyan-600 hover:bg-cyan-700"
        >
          <Sparkles className="mr-2 h-4 w-4" />
          {isGenerating ? "Analyzing & Generating..." : "Generate Schema"}
        </Button>

        {validation && (
          <AnimatePresence>
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
              <Card className="bg-gray-800 border-gray-700">
                <CardHeader>
                  <CardTitle className="text-sm flex items-center gap-2">
                    <CheckCircle className="text-green-400" size={16} />
                    Validation Results
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-green-400">Valid Schema</span>
                    <CheckCircle size={16} className="text-green-400" />
                  </div>
                  {validation.warnings > 0 && (
                    <div className="flex items-center justify-between">
                      <span className="text-yellow-400">{validation.warnings} Minor Warnings</span>
                      <AlertTriangle size={16} className="text-yellow-400" />
                    </div>
                  )}
                  <div>
                    <h4 className="text-xs font-semibold text-cyan-400 mb-2">Eligible Rich Results:</h4>
                    <div className="flex flex-wrap gap-1">
                      {validation.richResults.map((result, index) => (
                        <Badge key={index} variant="secondary" className="text-xs">
                          {result}
                        </Badge>
                      ))}
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </AnimatePresence>
        )}
      </div>

      <div className="w-1/2 pl-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold">Generated Schema</h3>
          {generatedSchema && (
            <Button size="sm" variant="outline" onClick={copyToClipboard}>
              <Copy className="mr-2 h-3 w-3" />
              Copy JSON-LD
            </Button>
          )}
        </div>
        
        <div className="h-full bg-gray-800 rounded-lg border border-gray-700 p-4">
          {isGenerating ? (
            <div className="flex items-center justify-center h-full text-gray-400">
              <p>Analyzing page content and generating optimized schema...</p>
            </div>
          ) : generatedSchema ? (
            <pre className="text-xs text-green-400 font-mono whitespace-pre-wrap overflow-auto h-full">
              {generatedSchema}
            </pre>
          ) : (
            <div className="flex items-center justify-center h-full text-gray-500">
              <p>Generated schema will appear here</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}