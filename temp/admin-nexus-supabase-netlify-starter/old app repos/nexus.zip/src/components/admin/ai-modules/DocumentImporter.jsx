import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { 
  Upload, 
  FileText, 
  Image, 
  File,
  CheckCircle,
  AlertTriangle,
  Clock,
  RefreshCw,
  Trash2,
  Eye,
  Brain,
  Link,
  Folder
} from 'lucide-react';
import { motion } from 'framer-motion';

const mockImportHistory = [
  {
    id: 'i1',
    fileName: 'company-handbook-2025.pdf',
    type: 'pdf',
    size: '2.4 MB',
    status: 'completed',
    factsExtracted: 47,
    category: 'Policies',
    uploadedAt: '2025-01-12 10:30',
    processedAt: '2025-01-12 10:33'
  },
  {
    id: 'i2',
    fileName: 'product-specifications.docx',
    type: 'docx',
    size: '1.8 MB',
    status: 'processing',
    factsExtracted: 0,
    category: 'Offers',
    uploadedAt: '2025-01-12 11:15',
    processedAt: null
  },
  {
    id: 'i3',
    fileName: 'competitor-analysis.xlsx',
    type: 'xlsx',
    size: '3.2 MB',
    status: 'failed',
    factsExtracted: 0,
    category: 'Competitors',
    uploadedAt: '2025-01-12 09:45',
    processedAt: '2025-01-12 09:47'
  },
  {
    id: 'i4',
    fileName: 'brand-guidelines-final.pdf',
    type: 'pdf',
    size: '5.1 MB',
    status: 'completed',
    factsExtracted: 23,
    category: 'Overview',
    uploadedAt: '2025-01-11 16:20',
    processedAt: '2025-01-11 16:25'
  }
];

const mockWatchedFolders = [
  {
    id: 'f1',
    name: 'Google Drive - /Company Docs',
    type: 'google_drive',
    path: '/Company Docs',
    status: 'active',
    lastSync: '2025-01-12 12:00',
    itemsProcessed: 15,
    autoSync: true
  },
  {
    id: 'f2',
    name: 'Dropbox - /Marketing Materials',
    type: 'dropbox',
    path: '/Marketing Materials',
    status: 'paused',
    lastSync: '2025-01-10 14:30',
    itemsProcessed: 8,
    autoSync: false
  },
  {
    id: 'f3',
    name: 'SharePoint - Product Documentation',
    type: 'sharepoint',
    path: '/sites/ProductDocs',
    status: 'error',
    lastSync: '2025-01-11 09:15',
    itemsProcessed: 0,
    autoSync: true
  }
];

const getFileIcon = (type) => {
  const iconMap = {
    pdf: <FileText className="text-red-400" />,
    docx: <FileText className="text-blue-400" />,
    xlsx: <FileText className="text-green-400" />,
    pptx: <FileText className="text-orange-400" />,
    jpg: <Image className="text-purple-400" />,
    png: <Image className="text-purple-400" />,
  };
  return iconMap[type] || <File className="text-gray-400" />;
};

const FileUploader = ({ onUpload }) => {
  const [isDragging, setIsDragging] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState('Overview');

  const handleDrop = (e) => {
    e.preventDefault();
    setIsDragging(false);
    const files = Array.from(e.dataTransfer.files);
    files.forEach(file => onUpload(file, selectedCategory));
  };

  const handleFileSelect = (e) => {
    const files = Array.from(e.target.files);
    files.forEach(file => onUpload(file, selectedCategory));
  };

  return (
    <Card className="bg-gray-800 border-gray-700">
      <CardHeader>
        <CardTitle className="text-white">Upload Documents</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-gray-300 mb-2">Category</label>
          <Select value={selectedCategory} onValueChange={setSelectedCategory}>
            <SelectTrigger className="bg-gray-700 border-gray-600 text-white">
              <SelectValue />
            </SelectTrigger>
            <SelectContent className="bg-gray-800 border-gray-600">
              <SelectItem value="Overview">Overview</SelectItem>
              <SelectItem value="Offers">Offers</SelectItem>
              <SelectItem value="ICP">ICP</SelectItem>
              <SelectItem value="FAQ">FAQ</SelectItem>
              <SelectItem value="Proof">Proof</SelectItem>
              <SelectItem value="Compliance">Compliance</SelectItem>
              <SelectItem value="Lexicon">Lexicon</SelectItem>
              <SelectItem value="Competitors">Competitors</SelectItem>
              <SelectItem value="Policies">Policies</SelectItem>
            </SelectContent>
          </Select>
        </div>
        
        <div
          className={`border-2 border-dashed rounded-lg p-8 text-center transition-colors ${
            isDragging 
              ? 'border-cyan-500 bg-cyan-500/10' 
              : 'border-gray-600 hover:border-gray-500'
          }`}
          onDragOver={(e) => e.preventDefault()}
          onDragEnter={() => setIsDragging(true)}
          onDragLeave={() => setIsDragging(false)}
          onDrop={handleDrop}
        >
          <Upload className="w-12 h-12 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-white mb-2">
            {isDragging ? 'Drop files here' : 'Upload Documents'}
          </h3>
          <p className="text-gray-400 mb-4">
            Drag and drop files here, or click to select
          </p>
          <input
            type="file"
            multiple
            accept=".pdf,.docx,.xlsx,.pptx,.txt,.md"
            onChange={handleFileSelect}
            className="hidden"
            id="file-upload"
          />
          <label htmlFor="file-upload">
            <Button className="bg-cyan-600 hover:bg-cyan-700">
              Select Files
            </Button>
          </label>
          <p className="text-xs text-gray-500 mt-2">
            Supports: PDF, Word, Excel, PowerPoint, Text, Markdown
          </p>
        </div>
      </CardContent>
    </Card>
  );
};

const ImportHistory = ({ imports, onRetry, onDelete }) => (
  <Card className="bg-gray-800 border-gray-700">
    <CardHeader>
      <div className="flex items-center justify-between">
        <CardTitle className="text-white">Import History</CardTitle>
        <Button size="sm" variant="outline" className="text-gray-300 border-gray-600">
          <RefreshCw size={14} className="mr-2" />
          Refresh
        </Button>
      </div>
    </CardHeader>
    <CardContent>
      <div className="space-y-3">
        {imports.map((item, index) => (
          <motion.div
            key={item.id}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.05 }}
            className="flex items-center justify-between p-4 bg-gray-700 rounded-lg"
          >
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 flex items-center justify-center">
                {getFileIcon(item.type)}
              </div>
              <div className="flex-1">
                <h4 className="font-medium text-white">{item.fileName}</h4>
                <div className="flex items-center gap-3 text-sm text-gray-400 mt-1">
                  <span>{item.size}</span>
                  <span>•</span>
                  <Badge variant="outline" className="text-xs">
                    {item.category}
                  </Badge>
                  <span>•</span>
                  <span>Uploaded: {item.uploadedAt}</span>
                </div>
              </div>
            </div>
            
            <div className="flex items-center gap-4">
              <div className="text-right">
                {item.status === 'completed' && (
                  <>
                    <div className="text-green-400 font-medium">{item.factsExtracted} facts</div>
                    <div className="text-xs text-gray-400">extracted</div>
                  </>
                )}
                {item.status === 'processing' && (
                  <>
                    <div className="text-blue-400 font-medium">Processing...</div>
                    <Progress value={65} className="w-20 h-1 mt-1" />
                  </>
                )}
                {item.status === 'failed' && (
                  <>
                    <div className="text-red-400 font-medium">Failed</div>
                    <div className="text-xs text-gray-400">error occurred</div>
                  </>
                )}
              </div>
              
              <div className="flex items-center gap-1">
                <Badge className={
                  item.status === 'completed' ? 'bg-green-500/20 text-green-400' :
                  item.status === 'processing' ? 'bg-blue-500/20 text-blue-400' :
                  'bg-red-500/20 text-red-400'
                }>
                  {item.status === 'completed' && <CheckCircle size={12} className="mr-1" />}
                  {item.status === 'processing' && <Clock size={12} className="mr-1" />}
                  {item.status === 'failed' && <AlertTriangle size={12} className="mr-1" />}
                  {item.status}
                </Badge>
              </div>
              
              <div className="flex gap-1">
                <Button size="sm" variant="ghost" className="text-gray-400 hover:text-white">
                  <Eye size={14} />
                </Button>
                {item.status === 'failed' && (
                  <Button 
                    size="sm" 
                    variant="ghost" 
                    onClick={() => onRetry(item.id)}
                    className="text-blue-400 hover:text-blue-300"
                  >
                    <RefreshCw size={14} />
                  </Button>
                )}
                <Button 
                  size="sm" 
                  variant="ghost" 
                  onClick={() => onDelete(item.id)}
                  className="text-red-400 hover:text-red-300"
                >
                  <Trash2 size={14} />
                </Button>
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </CardContent>
  </Card>
);

const FolderWatcher = ({ folders, onToggleSync, onConfigure }) => (
  <Card className="bg-gray-800 border-gray-700">
    <CardHeader>
      <div className="flex items-center justify-between">
        <CardTitle className="text-white">Watched Folders</CardTitle>
        <Button size="sm" className="bg-cyan-600 hover:bg-cyan-700">
          <Link size={14} className="mr-2" />
          Connect Folder
        </Button>
      </div>
    </CardHeader>
    <CardContent>
      <div className="space-y-4">
        {folders.map((folder) => (
          <div key={folder.id} className="p-4 bg-gray-700 rounded-lg">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Folder className="w-6 h-6 text-cyan-400" />
                <div>
                  <h4 className="font-medium text-white">{folder.name}</h4>
                  <p className="text-sm text-gray-400">{folder.path}</p>
                </div>
              </div>
              
              <div className="flex items-center gap-4">
                <div className="text-right text-sm">
                  <div className="text-white">{folder.itemsProcessed} items</div>
                  <div className="text-gray-400">Last sync: {folder.lastSync}</div>
                </div>
                
                <Badge className={
                  folder.status === 'active' ? 'bg-green-500/20 text-green-400' :
                  folder.status === 'paused' ? 'bg-yellow-500/20 text-yellow-400' :
                  'bg-red-500/20 text-red-400'
                }>
                  {folder.status}
                </Badge>
                
                <div className="flex gap-1">
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => onToggleSync(folder.id)}
                    className={folder.status === 'active' ? 'text-yellow-400 hover:text-yellow-300' : 'text-green-400 hover:text-green-300'}
                  >
                    {folder.status === 'active' ? <Clock size={14} /> : <RefreshCw size={14} />}
                  </Button>
                  <Button 
                    size="sm" 
                    variant="ghost" 
                    onClick={() => onConfigure(folder.id)}
                    className="text-gray-400 hover:text-white"
                  >
                    <Eye size={14} />
                  </Button>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </CardContent>
  </Card>
);

export default function DocumentImporter() {
  const [activeTab, setActiveTab] = useState('upload');
  const [uploadProgress, setUploadProgress] = useState({});

  const handleFileUpload = (file, category) => {
    const uploadId = Date.now();
    setUploadProgress(prev => ({ ...prev, [uploadId]: 0 }));
    
    // Simulate upload progress
    const interval = setInterval(() => {
      setUploadProgress(prev => {
        const current = prev[uploadId] || 0;
        if (current >= 100) {
          clearInterval(interval);
          setTimeout(() => {
            setUploadProgress(prev => {
              const { [uploadId]: _, ...rest } = prev;
              return rest;
            });
          }, 2000);
          return prev;
        }
        return { ...prev, [uploadId]: current + 10 };
      });
    }, 200);
    
    console.log('Uploading file:', file.name, 'Category:', category);
  };

  const handleRetryImport = (importId) => {
    console.log('Retrying import:', importId);
  };

  const handleDeleteImport = (importId) => {
    console.log('Deleting import:', importId);
  };

  const handleToggleSync = (folderId) => {
    console.log('Toggling sync for folder:', folderId);
  };

  const handleConfigureFolder = (folderId) => {
    console.log('Configuring folder:', folderId);
  };

  return (
    <div className="p-6 h-full bg-gray-900 text-white">
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <div className="flex items-center justify-between mb-6">
          <TabsList className="bg-gray-800 border-gray-700">
            <TabsTrigger value="upload" className="data-[state=active]:bg-cyan-600">
              Upload
            </TabsTrigger>
            <TabsTrigger value="history" className="data-[state=active]:bg-cyan-600">
              Import History
            </TabsTrigger>
            <TabsTrigger value="folders" className="data-[state=active]:bg-cyan-600">
              Watched Folders
            </TabsTrigger>
          </TabsList>
          <Button className="bg-cyan-600 hover:bg-cyan-700">
            <Brain size={16} className="mr-2" />
            Update Brain Summary
          </Button>
        </div>

        <TabsContent value="upload" className="space-y-6">
          <FileUploader onUpload={handleFileUpload} />
          
          {Object.keys(uploadProgress).length > 0 && (
            <Card className="bg-gray-800 border-gray-700">
              <CardHeader>
                <CardTitle className="text-white">Upload Progress</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {Object.entries(uploadProgress).map(([uploadId, progress]) => (
                    <div key={uploadId} className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-300">Processing document...</span>
                        <span className="text-white">{progress}%</span>
                      </div>
                      <Progress value={progress} className="h-2" />
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="history">
          <ImportHistory 
            imports={mockImportHistory}
            onRetry={handleRetryImport}
            onDelete={handleDeleteImport}
          />
        </TabsContent>

        <TabsContent value="folders">
          <FolderWatcher 
            folders={mockWatchedFolders}
            onToggleSync={handleToggleSync}
            onConfigure={handleConfigureFolder}
          />
        </TabsContent>
      </Tabs>
    </div>
  );
}