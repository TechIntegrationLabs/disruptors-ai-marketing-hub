import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Progress } from "@/components/ui/progress";
import { 
  Users, 
  Globe, 
  CheckCircle, 
  AlertTriangle,
  Settings,
  Download,
  Upload,
  Zap,
  Copy,
  Eye,
  Plus
} from 'lucide-react';
import { motion } from 'framer-motion';

const mockClients = [
  {
    id: 'c1',
    businessName: 'Acme Digital Marketing',
    website: 'https://acmedigital.com',
    status: 'active',
    setupProgress: 100,
    industry: 'Marketing Agency',
    onboardedDate: '2024-12-15',
    config: {
      brandColors: ['#FF6B6B', '#4ECDC4'],
      voiceTone: 'Professional & Friendly',
      targetAudience: 'Small business owners',
      contentTypes: ['Blog Posts', 'Case Studies', 'Social Media']
    }
  },
  {
    id: 'c2',
    businessName: 'TechStart Solutions',
    website: 'https://techstartsolutions.io',
    status: 'onboarding',
    setupProgress: 67,
    industry: 'SaaS',
    onboardedDate: '2025-01-10',
    config: {
      brandColors: ['#3B82F6', '#10B981'],
      voiceTone: 'Technical & Authoritative',
      targetAudience: 'Software developers',
      contentTypes: ['Technical Guides', 'API Documentation']
    }
  },
  {
    id: 'c3',
    businessName: 'Fitness First Coaching',
    website: 'https://fitnessfirst.coach',
    status: 'pending',
    setupProgress: 25,
    industry: 'Health & Fitness',
    onboardedDate: '2025-01-12',
    config: {
      brandColors: [],
      voiceTone: '',
      targetAudience: '',
      contentTypes: []
    }
  }
];

const onboardingSteps = [
  { id: 'basic', title: 'Basic Information', description: 'Business name, website, industry' },
  { id: 'brand', title: 'Brand Identity', description: 'Colors, fonts, voice & tone' },
  { id: 'audience', title: 'Target Audience', description: 'Demographics and preferences' },
  { id: 'content', title: 'Content Strategy', description: 'Types, frequency, topics' },
  { id: 'integrations', title: 'Integrations', description: 'CMS, analytics, social media' },
  { id: 'validation', title: 'Validation', description: 'Review and activate setup' }
];

const ClientCard = ({ client, onSelect, isSelected }) => {
  const statusColors = {
    active: 'bg-green-500/20 text-green-400 border-green-500/50',
    onboarding: 'bg-blue-500/20 text-blue-400 border-blue-500/50',
    pending: 'bg-yellow-500/20 text-yellow-400 border-yellow-500/50'
  };

  return (
    <Card 
      className={`cursor-pointer transition-all ${
        isSelected ? 'bg-cyan-900 border-cyan-500' : 'bg-gray-800 border-gray-700 hover:border-cyan-500/50'
      }`}
      onClick={() => onSelect(client)}
    >
      <CardContent className="p-4">
        <div className="flex items-start justify-between mb-3">
          <div className="flex-1">
            <h3 className="font-medium text-white">{client.businessName}</h3>
            <p className="text-sm text-gray-400">{client.website}</p>
          </div>
          <Badge className={statusColors[client.status]}>
            {client.status}
          </Badge>
        </div>
        
        <div className="space-y-2">
          <div className="flex justify-between text-sm">
            <span className="text-gray-400">Setup Progress</span>
            <span className="text-white">{client.setupProgress}%</span>
          </div>
          <Progress value={client.setupProgress} className="h-2" />
        </div>
        
        <div className="flex justify-between text-xs text-gray-500 mt-3">
          <span>{client.industry}</span>
          <span>Since {client.onboardedDate}</span>
        </div>
      </CardContent>
    </Card>
  );
};

const ClientDetails = ({ client }) => (
  <div className="space-y-6">
    <Card className="bg-gray-800 border-gray-700">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="text-white">{client.businessName}</CardTitle>
          <div className="flex gap-2">
            <Button size="sm" variant="outline" className="text-gray-300 border-gray-600">
              <Eye size={14} className="mr-2" />
              Preview
            </Button>
            <Button size="sm" className="bg-cyan-600 hover:bg-cyan-700">
              <Settings size={14} className="mr-2" />
              Configure
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-1">Website</label>
            <p className="text-white">{client.website}</p>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-1">Industry</label>
            <p className="text-white">{client.industry}</p>
          </div>
        </div>
        
        <div className="space-y-2">
          <div className="flex justify-between text-sm">
            <span className="text-gray-400">Setup Progress</span>
            <span className="text-white">{client.setupProgress}%</span>
          </div>
          <Progress value={client.setupProgress} className="h-3" />
        </div>
      </CardContent>
    </Card>

    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
      <Card className="bg-gray-800 border-gray-700">
        <CardHeader>
          <CardTitle className="text-white">Brand Configuration</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">Brand Colors</label>
            <div className="flex gap-2">
              {client.config.brandColors.map((color, index) => (
                <div 
                  key={index}
                  className="w-8 h-8 rounded-full border border-gray-600"
                  style={{ backgroundColor: color }}
                />
              ))}
              {client.config.brandColors.length === 0 && (
                <span className="text-gray-500 text-sm">No colors configured</span>
              )}
            </div>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">Voice & Tone</label>
            <p className="text-white">{client.config.voiceTone || 'Not configured'}</p>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">Target Audience</label>
            <p className="text-white">{client.config.targetAudience || 'Not configured'}</p>
          </div>
        </CardContent>
      </Card>

      <Card className="bg-gray-800 border-gray-700">
        <CardHeader>
          <CardTitle className="text-white">Content Strategy</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">Content Types</label>
            <div className="flex flex-wrap gap-1">
              {client.config.contentTypes.map((type, index) => (
                <Badge key={index} variant="outline" className="text-purple-400 border-purple-500/50">
                  {type}
                </Badge>
              ))}
              {client.config.contentTypes.length === 0 && (
                <span className="text-gray-500 text-sm">No content types configured</span>
              )}
            </div>
          </div>
          
          <Button className="w-full bg-cyan-600 hover:bg-cyan-700">
            <Zap size={16} className="mr-2" />
            Generate Content Plan
          </Button>
        </CardContent>
      </Card>
    </div>

    <Card className="bg-gray-800 border-gray-700">
      <CardHeader>
        <CardTitle className="text-white">Onboarding Progress</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {onboardingSteps.map((step, index) => {
            const isCompleted = (index + 1) <= (client.setupProgress / 100) * onboardingSteps.length;
            const isCurrent = Math.ceil((client.setupProgress / 100) * onboardingSteps.length) === index + 1;
            
            return (
              <div key={step.id} className={`flex items-center gap-3 p-3 rounded-lg ${
                isCurrent ? 'bg-cyan-900 border border-cyan-500' : 'bg-gray-700'
              }`}>
                {isCompleted ? (
                  <CheckCircle size={20} className="text-green-400" />
                ) : (
                  <div className={`w-5 h-5 rounded-full border-2 ${
                    isCurrent ? 'border-cyan-400' : 'border-gray-600'
                  }`} />
                )}
                <div className="flex-1">
                  <h4 className="font-medium text-white">{step.title}</h4>
                  <p className="text-sm text-gray-400">{step.description}</p>
                </div>
                {isCurrent && (
                  <Button size="sm" className="bg-cyan-600 hover:bg-cyan-700">
                    Continue
                  </Button>
                )}
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  </div>
);

const OnboardingWizard = ({ onComplete }) => {
  const [currentStep, setCurrentStep] = useState(0);
  const [formData, setFormData] = useState({
    businessName: '',
    website: '',
    industry: '',
    brandColors: [],
    voiceTone: '',
    targetAudience: '',
    contentTypes: []
  });

  const handleNext = () => {
    if (currentStep < onboardingSteps.length - 1) {
      setCurrentStep(currentStep + 1);
    } else {
      onComplete(formData);
    }
  };

  const handleBack = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  const currentStepData = onboardingSteps[currentStep];
  const progress = ((currentStep + 1) / onboardingSteps.length) * 100;

  return (
    <Card className="bg-gray-800 border-gray-700">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="text-white">Client Onboarding</CardTitle>
          <Badge variant="outline" className="text-cyan-400 border-cyan-500/50">
            Step {currentStep + 1} of {onboardingSteps.length}
          </Badge>
        </div>
        <div className="space-y-2">
          <Progress value={progress} className="h-2" />
          <p className="text-sm text-gray-400">{progress.toFixed(0)}% complete</p>
        </div>
      </CardHeader>
      <CardContent className="space-y-6">
        <div>
          <h3 className="text-lg font-medium text-white mb-2">{currentStepData.title}</h3>
          <p className="text-gray-400">{currentStepData.description}</p>
        </div>

        {currentStep === 0 && (
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">Business Name</label>
              <Input
                placeholder="Enter business name"
                value={formData.businessName}
                onChange={(e) => setFormData({...formData, businessName: e.target.value})}
                className="bg-gray-700 border-gray-600 text-white"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">Website URL</label>
              <Input
                placeholder="https://example.com"
                value={formData.website}
                onChange={(e) => setFormData({...formData, website: e.target.value})}
                className="bg-gray-700 border-gray-600 text-white"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">Industry</label>
              <Input
                placeholder="e.g., Marketing, SaaS, E-commerce"
                value={formData.industry}
                onChange={(e) => setFormData({...formData, industry: e.target.value})}
                className="bg-gray-700 border-gray-600 text-white"
              />
            </div>
          </div>
        )}

        {currentStep === 1 && (
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">Voice & Tone</label>
              <Textarea
                placeholder="Describe your brand's personality and communication style"
                value={formData.voiceTone}
                onChange={(e) => setFormData({...formData, voiceTone: e.target.value})}
                className="bg-gray-700 border-gray-600 text-white h-20"
              />
            </div>
          </div>
        )}

        {currentStep === 2 && (
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">Target Audience</label>
              <Textarea
                placeholder="Describe your ideal customers and their needs"
                value={formData.targetAudience}
                onChange={(e) => setFormData({...formData, targetAudience: e.target.value})}
                className="bg-gray-700 border-gray-600 text-white h-20"
              />
            </div>
          </div>
        )}

        <div className="flex justify-between">
          <Button 
            onClick={handleBack}
            disabled={currentStep === 0}
            variant="outline"
            className="text-gray-300 border-gray-600"
          >
            Back
          </Button>
          <Button onClick={handleNext} className="bg-cyan-600 hover:bg-cyan-700">
            {currentStep === onboardingSteps.length - 1 ? 'Complete Setup' : 'Next'}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

export default function ClientIntake() {
  const [activeTab, setActiveTab] = useState('clients');
  const [selectedClient, setSelectedClient] = useState(mockClients[0]);
  const [showOnboarding, setShowOnboarding] = useState(false);

  const handleCompleteOnboarding = (data) => {
    console.log('Onboarding completed:', data);
    setShowOnboarding(false);
    setActiveTab('clients');
  };

  return (
    <div className="p-6 h-full bg-gray-900 text-white">
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <div className="flex items-center justify-between mb-6">
          <TabsList className="bg-gray-800 border-gray-700">
            <TabsTrigger value="clients" className="data-[state=active]:bg-cyan-600">
              Client Dashboard
            </TabsTrigger>
            <TabsTrigger value="onboarding" className="data-[state=active]:bg-cyan-600">
              Quick Onboarding
            </TabsTrigger>
          </TabsList>
          <Button 
            onClick={() => setShowOnboarding(true)}
            className="bg-cyan-600 hover:bg-cyan-700"
          >
            <Plus size={16} className="mr-2" />
            Onboard New Client
          </Button>
        </div>

        <TabsContent value="clients" className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <h3 className="text-lg font-semibold text-white">Clients</h3>
              <Badge variant="outline" className="text-cyan-400 border-cyan-500/50">
                {mockClients.length} total
              </Badge>
            </div>
            <div className="space-y-3">
              {mockClients.map(client => (
                <ClientCard 
                  key={client.id}
                  client={client}
                  onSelect={setSelectedClient}
                  isSelected={selectedClient.id === client.id}
                />
              ))}
            </div>
          </div>
          
          <div className="lg:col-span-2">
            <ClientDetails client={selectedClient} />
          </div>
        </TabsContent>

        <TabsContent value="onboarding">
          <OnboardingWizard onComplete={handleCompleteOnboarding} />
        </TabsContent>
      </Tabs>
    </div>
  );
}