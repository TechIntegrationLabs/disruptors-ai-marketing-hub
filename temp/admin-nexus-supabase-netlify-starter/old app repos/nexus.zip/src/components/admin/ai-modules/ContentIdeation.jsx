import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Search, Zap, Lightbulb, FileText, Check, Copy } from 'lucide-react';
import { AnimatePresence, motion } from 'framer-motion';

const sampleTopics = [
    { title: "What is headless CMS?", volume: "1.2k", intent: "Informational", funnel: "Top" },
    { title: "Headless CMS for e-commerce", volume: "800", intent: "Commercial", funnel: "Middle" },
    { title: "Best headless CMS for developers", volume: "950", intent: "Commercial", funnel: "Middle" },
    { title: "Migrating to a headless CMS", volume: "300", intent: "Transactional", funnel: "Bottom" },
];

export default function ContentIdeation() {
    const [topic, setTopic] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [ideas, setIdeas] = useState([]);
    const [selectedIdea, setSelectedIdea] = useState(null);
    const [brief, setBrief] = useState('');

    const handleSearch = () => {
        if (!topic) return;
        setIsLoading(true);
        setIdeas([]);
        setSelectedIdea(null);
        setBrief('');
        setTimeout(() => {
            setIdeas(sampleTopics);
            setIsLoading(false);
        }, 1500);
    };

    const handleGenerateBrief = (idea) => {
        setSelectedIdea(idea);
        setBrief('');
        setIsLoading(true);
        setTimeout(() => {
            setBrief(`**Title:** ${idea.title}\n\n**Primary Keyword:** ${idea.title}\n\n**Target Intent:** ${idea.intent}\n\n**Funnel Stage:** ${idea.funnel}\n\n**Outline:**\n- Introduction to the topic\n- Key benefits and features\n- Comparison with alternatives\n- How-to guide/implementation steps\n- Conclusion with a strong CTA.`);
            setIsLoading(false);
        }, 1000);
    };

    return (
        <div className="p-6 h-full flex flex-col text-white bg-gray-900">
            <div className="flex items-center gap-4 mb-6">
                <Input
                    placeholder="Enter a core topic (e.g., 'Headless CMS')"
                    value={topic}
                    onChange={(e) => setTopic(e.target.value)}
                    className="flex-1 bg-gray-800 border-gray-600 text-white placeholder-gray-500"
                />
                <Button onClick={handleSearch} disabled={isLoading} className="bg-cyan-600 hover:bg-cyan-700">
                    <Search className="mr-2 h-4 w-4" />
                    {isLoading && !ideas.length ? "Finding Opportunities..." : "Find Opportunities"}
                </Button>
            </div>

            <div className="flex-1 grid grid-cols-1 md:grid-cols-2 gap-6 overflow-hidden">
                {/* Left Panel: Ideas */}
                <div className="flex flex-col space-y-4 overflow-y-auto pr-2">
                    <h3 className="text-lg font-semibold flex items-center gap-2"><Lightbulb className="text-cyan-400" /> Topic Ideas & Keywords</h3>
                    <AnimatePresence>
                        {ideas.map((idea, index) => (
                            <motion.div
                                key={index}
                                initial={{ opacity: 0, y: 20 }}
                                animate={{ opacity: 1, y: 0 }}
                                transition={{ delay: index * 0.1 }}
                            >
                                <Card 
                                    className={`bg-gray-800 border-gray-700 cursor-pointer hover:border-cyan-500/50 ${selectedIdea?.title === idea.title ? 'border-cyan-500' : ''}`}
                                    onClick={() => handleGenerateBrief(idea)}
                                >
                                    <CardContent className="p-4">
                                        <div className="flex justify-between items-start">
                                            <p className="font-medium text-white">{idea.title}</p>
                                            <div className="text-right text-xs text-gray-400">
                                                <p>Vol: {idea.volume}</p>
                                            </div>
                                        </div>
                                        <div className="flex gap-2 mt-2">
                                            <Badge variant="outline" className="text-cyan-300 border-cyan-500/30">{idea.intent}</Badge>
                                            <Badge variant="outline" className="text-purple-300 border-purple-500/30">{idea.funnel} Funnel</Badge>
                                        </div>
                                    </CardContent>
                                </Card>
                            </motion.div>
                        ))}
                    </AnimatePresence>
                    {isLoading && !ideas.length && <div className="text-center p-8 text-gray-400">Analyzing SERPs and finding related topics...</div>}
                </div>

                {/* Right Panel: Brief */}
                <div className="flex flex-col space-y-4 overflow-y-auto">
                    <h3 className="text-lg font-semibold flex items-center gap-2"><FileText className="text-cyan-400" /> Generated Content Brief</h3>
                    <Card className="flex-1 bg-gray-800 border-gray-700">
                        <CardContent className="p-6">
                            {isLoading && selectedIdea && <div className="text-center p-8 text-gray-400">Generating brief based on Brand DNA and top results...</div>}
                            {brief ? (
                                <div>
                                    <div className="prose prose-invert prose-sm max-w-none" dangerouslySetInnerHTML={{ __html: brief.replace(/\n/g, '<br/>') }}></div>
                                    <div className="mt-4 flex gap-2">
                                        <Button size="sm" variant="outline" onClick={() => navigator.clipboard.writeText(brief)}><Copy className="mr-2 h-3 w-3" /> Copy Brief</Button>
                                        <Button size="sm" className="bg-cyan-600 hover:bg-cyan-700"><Check className="mr-2 h-3 w-3" /> Send to CMS</Button>
                                    </div>
                                </div>
                            ) : (
                                !isLoading && (
                                    <div className="text-center text-gray-500 p-8">
                                        Select an idea to generate a detailed content brief.
                                    </div>
                                )
                            )}
                        </CardContent>
                    </Card>
                </div>
            </div>
        </div>
    );
}