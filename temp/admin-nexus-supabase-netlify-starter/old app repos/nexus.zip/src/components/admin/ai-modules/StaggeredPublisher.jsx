import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Calendar } from "@/components/ui/calendar";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { 
  Calendar as CalendarIcon, 
  Clock, 
  Send, 
  Pause, 
  Play,
  CheckCircle,
  AlertTriangle,
  Eye,
  Globe,
  Zap
} from 'lucide-react';
import { motion } from 'framer-motion';

const mockWaves = [
  {
    id: 'w1',
    name: 'Q1 Content Push',
    status: 'active',
    progress: 67,
    published: 8,
    scheduled: 4,
    total: 12,
    startDate: '2025-01-15',
    endDate: '2025-03-31',
    pages: [
      { title: 'Ultimate SEO Guide 2025', status: 'published', publishDate: '2025-01-15' },
      { title: 'Technical SEO Checklist', status: 'scheduled', publishDate: '2025-01-22' },
      { title: 'Local SEO Strategies', status: 'scheduled', publishDate: '2025-01-29' },
      { title: 'Content Marketing ROI', status: 'draft', publishDate: '2025-02-05' }
    ]
  },
  {
    id: 'w2', 
    name: 'Product Launch Series',
    status: 'scheduled',
    progress: 0,
    published: 0,
    scheduled: 6,
    total: 6,
    startDate: '2025-02-01',
    endDate: '2025-02-28',
    pages: [
      { title: 'Introducing Our New Platform', status: 'ready', publishDate: '2025-02-01' },
      { title: 'Platform Features Deep Dive', status: 'ready', publishDate: '2025-02-08' },
      { title: 'Migration Guide', status: 'ready', publishDate: '2025-02-15' }
    ]
  }
];

const mockIndexStatus = [
  { url: '/blog/ultimate-seo-guide-2025', status: 'indexed', lastCrawled: '2 hours ago', clicks: 847, impressions: 12453 },
  { url: '/blog/technical-seo-checklist', status: 'pending', lastCrawled: 'Never', clicks: 0, impressions: 0 },
  { url: '/blog/local-seo-strategies', status: 'error', lastCrawled: '1 day ago', clicks: 23, impressions: 156 },
  { url: '/resources/content-marketing-roi', status: 'indexed', lastCrawled: '4 hours ago', clicks: 234, impressions: 3421 }
];

const WaveCard = ({ wave, onSelect, isSelected }) => {
  const statusColors = {
    active: 'bg-green-500/20 text-green-400 border-green-500/50',
    scheduled: 'bg-blue-500/20 text-blue-400 border-blue-500/50', 
    completed: 'bg-gray-500/20 text-gray-400 border-gray-500/50',
    paused: 'bg-yellow-500/20 text-yellow-400 border-yellow-500/50'
  };

  return (
    <Card 
      className={`cursor-pointer transition-all ${
        isSelected ? 'bg-cyan-900 border-cyan-500' : 'bg-gray-800 border-gray-700 hover:border-cyan-500/50'
      }`}
      onClick={() => onSelect(wave)}
    >
      <CardContent className="p-4">
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-white font-medium">{wave.name}</h3>
          <Badge className={statusColors[wave.status]}>
            {wave.status}
          </Badge>
        </div>
        
        <div className="space-y-2">
          <div className="flex justify-between text-sm">
            <span className="text-gray-400">Progress</span>
            <span className="text-white">{wave.progress}%</span>
          </div>
          <Progress value={wave.progress} className="h-2" />
          
          <div className="grid grid-cols-3 gap-2 text-xs">
            <div className="text-center">
              <div className="text-green-400 font-bold">{wave.published}</div>
              <div className="text-gray-500">Published</div>
            </div>
            <div className="text-center">
              <div className="text-blue-400 font-bold">{wave.scheduled}</div>
              <div className="text-gray-500">Scheduled</div>
            </div>
            <div className="text-center">
              <div className="text-gray-400 font-bold">{wave.total}</div>
              <div className="text-gray-500">Total</div>
            </div>
          </div>
          
          <div className="text-xs text-gray-400 mt-2">
            {wave.startDate} → {wave.endDate}
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

const WaveDetails = ({ wave }) => (
  <div className="space-y-4">
    <div className="flex items-center justify-between">
      <h2 className="text-xl font-bold text-white">{wave.name}</h2>
      <div className="flex gap-2">
        <Button size="sm" variant="outline" className="text-gray-300 border-gray-600">
          <Pause size={14} className="mr-2" />
          Pause Wave
        </Button>
        <Button size="sm" className="bg-cyan-600 hover:bg-cyan-700">
          <Send size={14} className="mr-2" />
          Publish Next
        </Button>
      </div>
    </div>
    
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
      <Card className="bg-gray-800 border-gray-700">
        <CardContent className="p-4 text-center">
          <div className="text-2xl font-bold text-green-400">{wave.published}</div>
          <div className="text-sm text-gray-400">Published</div>
        </CardContent>
      </Card>
      <Card className="bg-gray-800 border-gray-700">
        <CardContent className="p-4 text-center">
          <div className="text-2xl font-bold text-blue-400">{wave.scheduled}</div>
          <div className="text-sm text-gray-400">Scheduled</div>
        </CardContent>
      </Card>
      <Card className="bg-gray-800 border-gray-700">
        <CardContent className="p-4 text-center">
          <div className="text-2xl font-bold text-white">{wave.progress}%</div>
          <div className="text-sm text-gray-400">Complete</div>
        </CardContent>
      </Card>
    </div>
    
    <Card className="bg-gray-800 border-gray-700">
      <CardHeader>
        <CardTitle className="text-white">Content Schedule</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {wave.pages.map((page, index) => (
            <div key={index} className="flex items-center justify-between p-3 bg-gray-700 rounded-lg">
              <div className="flex items-center gap-3">
                {page.status === 'published' && <CheckCircle size={16} className="text-green-400" />}
                {page.status === 'scheduled' && <Clock size={16} className="text-blue-400" />}
                {page.status === 'draft' && <AlertTriangle size={16} className="text-yellow-400" />}
                {page.status === 'ready' && <Play size={16} className="text-cyan-400" />}
                <div>
                  <div className="text-white font-medium">{page.title}</div>
                  <div className="text-xs text-gray-400">Scheduled: {page.publishDate}</div>
                </div>
              </div>
              <Badge variant="outline" className={
                page.status === 'published' ? 'text-green-400 border-green-500/50' :
                page.status === 'scheduled' ? 'text-blue-400 border-blue-500/50' :
                page.status === 'ready' ? 'text-cyan-400 border-cyan-500/50' :
                'text-yellow-400 border-yellow-500/50'
              }>
                {page.status}
              </Badge>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  </div>
);

const IndexMonitor = () => (
  <Card className="bg-gray-800 border-gray-700">
    <CardHeader>
      <CardTitle className="text-white flex items-center gap-2">
        <Globe size={20} />
        Search Index Monitor
      </CardTitle>
    </CardHeader>
    <CardContent>
      <div className="space-y-3">
        {mockIndexStatus.map((item, index) => (
          <div key={index} className="flex items-center justify-between p-3 bg-gray-700 rounded-lg">
            <div className="flex items-center gap-3">
              {item.status === 'indexed' && <CheckCircle size={16} className="text-green-400" />}
              {item.status === 'pending' && <Clock size={16} className="text-yellow-400" />}
              {item.status === 'error' && <AlertTriangle size={16} className="text-red-400" />}
              <div>
                <div className="text-white font-mono text-sm">{item.url}</div>
                <div className="text-xs text-gray-400">Last crawled: {item.lastCrawled}</div>
              </div>
            </div>
            <div className="text-right text-sm">
              <div className="text-white">{item.clicks} clicks</div>
              <div className="text-gray-400">{item.impressions} impressions</div>
            </div>
          </div>
        ))}
      </div>
    </CardContent>
  </Card>
);

export default function StaggeredPublisher() {
  const [selectedWave, setSelectedWave] = useState(mockWaves[0]);
  const [activeTab, setActiveTab] = useState('waves');

  return (
    <div className="p-6 h-full bg-gray-900 text-white">
      <Tabs value={activeTab} onValueChange={setActiveTab} className="h-full">
        <div className="flex items-center justify-between mb-6">
          <TabsList className="bg-gray-800 border-gray-700">
            <TabsTrigger value="waves" className="data-[state=active]:bg-cyan-600">
              Publishing Waves
            </TabsTrigger>
            <TabsTrigger value="monitor" className="data-[state=active]:bg-cyan-600">
              Index Monitor
            </TabsTrigger>
          </TabsList>
          <Button className="bg-cyan-600 hover:bg-cyan-700">
            <Zap size={16} className="mr-2" />
            Create New Wave
          </Button>
        </div>

        <TabsContent value="waves" className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="space-y-4">
            <Input
              placeholder="Search waves..."
              className="bg-gray-800 border-gray-600 text-white"
            />
            <div className="space-y-3">
              {mockWaves.map(wave => (
                <WaveCard 
                  key={wave.id}
                  wave={wave}
                  onSelect={setSelectedWave}
                  isSelected={selectedWave.id === wave.id}
                />
              ))}
            </div>
          </div>
          
          <div className="lg:col-span-2">
            <WaveDetails wave={selectedWave} />
          </div>
        </TabsContent>

        <TabsContent value="monitor">
          <IndexMonitor />
        </TabsContent>
      </Tabs>
    </div>
  );
}