import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Link, 
  Search, 
  Map, 
  Lightbulb, 
  Check, 
  Plus,
  ArrowRight,
  ArrowLeft,
  Network,
  Target
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

const mockPages = [
  { id: 'p1', title: 'Ultimate Guide to SEO', linksIn: 12, linksOut: 8, opportunities: 5, category: 'guide' },
  { id: 'p2', title: 'What is a SERP?', linksIn: 3, linksOut: 5, opportunities: 8, category: 'definition' },
  { id: 'p3', title: 'Keyword Research Basics', linksIn: 5, linksOut: 4, opportunities: 2, category: 'tutorial' },
  { id: 'p4', title: 'Building Quality Backlinks', linksIn: 8, linksOut: 6, opportunities: 4, category: 'strategy' },
  { id: 'p5', title: 'On-Page SEO Checklist', linksIn: 2, linksOut: 7, opportunities: 6, category: 'checklist' },
  { id: 'p6', title: 'Technical SEO Audit', linksIn: 4, linksOut: 3, opportunities: 3, category: 'audit' }
];

const mockSuggestions = {
  p2: [
    { targetId: 'p1', targetTitle: 'Ultimate Guide to SEO', anchorText: 'comprehensive SEO guide', context: '...for a more detailed understanding, check out our comprehensive SEO guide...', confidence: 85 },
    { targetId: 'p3', targetTitle: 'Keyword Research Basics', anchorText: 'keyword research', context: '...understanding SERPs starts with solid keyword research fundamentals...', confidence: 92 }
  ],
  p1: [
    { targetId: 'p4', targetTitle: 'Building Quality Backlinks', anchorText: 'link building strategies', context: '...off-page optimization includes proven link building strategies...', confidence: 88 },
    { targetId: 'p5', targetTitle: 'On-Page SEO Checklist', anchorText: 'on-page optimization', context: '...combine these techniques with thorough on-page optimization...', confidence: 90 }
  ]
};

const TopicalMap = ({ pages, onPageSelect }) => {
  const categories = [...new Set(pages.map(p => p.category))];
  
  return (
    <div className="h-80 bg-gray-800 rounded-lg border border-gray-700 p-4 overflow-hidden">
      <div className="flex items-center justify-center h-full">
        <div className="text-center">
          <Network className="w-16 h-16 text-cyan-400 mx-auto mb-4" />
          <h3 className="text-white font-medium mb-2">Interactive Topical Map</h3>
          <p className="text-gray-400 text-sm mb-4">Visual representation of your site's content relationships</p>
          <div className="grid grid-cols-3 gap-4">
            {categories.map(category => (
              <div key={category} className="p-3 bg-gray-700 rounded-lg text-center">
                <div className="text-cyan-400 font-medium text-sm capitalize">{category}</div>
                <div className="text-xs text-gray-400 mt-1">
                  {pages.filter(p => p.category === category).length} pages
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

const PageAnalysis = ({ page }) => {
  const suggestions = mockSuggestions[page.id] || [];
  
  return (
    <div className="space-y-4">
      <div className="grid grid-cols-3 gap-4">
        <Card className="bg-gray-800 border-gray-700">
          <CardContent className="p-3 text-center">
            <div className="text-2xl font-bold text-white">{page.linksIn}</div>
            <div className="text-xs text-gray-400">Inbound Links</div>
          </CardContent>
        </Card>
        <Card className="bg-gray-800 border-gray-700">
          <CardContent className="p-3 text-center">
            <div className="text-2xl font-bold text-white">{page.linksOut}</div>
            <div className="text-xs text-gray-400">Outbound Links</div>
          </CardContent>
        </Card>
        <Card className="bg-gray-800 border-gray-700">
          <CardContent className="p-3 text-center">
            <div className="text-2xl font-bold text-cyan-400">{page.opportunities}</div>
            <div className="text-xs text-gray-400">Opportunities</div>
          </CardContent>
        </Card>
      </div>
      
      <Card className="bg-gray-800 border-gray-700">
        <CardHeader>
          <CardTitle className="text-white text-sm">Link Opportunities</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {suggestions.map((suggestion, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="p-3 bg-gray-700 rounded-lg"
            >
              <div className="flex items-start justify-between mb-2">
                <div className="text-sm">
                  <span className="text-gray-300">Link "</span>
                  <span className="text-purple-400 font-medium">{suggestion.anchorText}</span>
                  <span className="text-gray-300">" to </span>
                  <span className="text-cyan-400 font-medium">{suggestion.targetTitle}</span>
                </div>
                <Badge variant="outline" className="text-green-400 border-green-500/50 text-xs">
                  {suggestion.confidence}% confidence
                </Badge>
              </div>
              <p className="text-xs text-gray-400 italic mb-3">{suggestion.context}</p>
              <div className="flex justify-end gap-2">
                <Button size="sm" variant="ghost" className="text-gray-400 hover:text-white text-xs">Skip</Button>
                <Button size="sm" className="bg-green-600 hover:bg-green-700 text-white text-xs">
                  <Check size={12} className="mr-1" />
                  Apply
                </Button>
              </div>
            </motion.div>
          ))}
          {suggestions.length === 0 && (
            <div className="text-center text-gray-500 py-4">
              <Target className="w-8 h-8 mx-auto mb-2 opacity-50" />
              <p className="text-sm">No link opportunities found for this page</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default function InternalLinkingArchitect() {
  const [selectedPage, setSelectedPage] = useState(mockPages[0]);
  const [searchTerm, setSearchTerm] = useState('');
  
  const filteredPages = mockPages.filter(page =>
    page.title.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="p-6 h-full bg-gray-900 text-white">
      <Tabs defaultValue="opportunities" className="h-full">
        <div className="flex items-center justify-between mb-6">
          <TabsList className="bg-gray-800 border-gray-700">
            <TabsTrigger value="opportunities" className="data-[state=active]:bg-cyan-600">
              Link Opportunities
            </TabsTrigger>
            <TabsTrigger value="map" className="data-[state=active]:bg-cyan-600">
              Topical Map
            </TabsTrigger>
          </TabsList>
          <Button className="bg-cyan-600 hover:bg-cyan-700">
            <Plus size={16} className="mr-2" />
            Scan for New Opportunities
          </Button>
        </div>

        <TabsContent value="opportunities" className="grid grid-cols-1 lg:grid-cols-3 gap-6 h-full">
          <div className="space-y-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Input
                placeholder="Search pages..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 bg-gray-800 border-gray-600 text-white"
              />
            </div>
            <div className="space-y-2 max-h-96 overflow-y-auto">
              {filteredPages.map(page => (
                <Card 
                  key={page.id}
                  onClick={() => setSelectedPage(page)}
                  className={`cursor-pointer transition-all ${
                    selectedPage.id === page.id 
                      ? 'bg-cyan-900 border-cyan-500' 
                      : 'bg-gray-800 border-gray-700 hover:border-cyan-500/50'
                  }`}
                >
                  <CardContent className="p-3">
                    <h4 className="text-white font-medium text-sm">{page.title}</h4>
                    <div className="flex items-center justify-between text-xs text-gray-400 mt-2">
                      <span className="flex items-center gap-1">
                        <ArrowLeft size={12} />
                        In: {page.linksIn}
                      </span>
                      <span className="flex items-center gap-1">
                        <ArrowRight size={12} />
                        Out: {page.linksOut}
                      </span>
                      <Badge variant="outline" className="text-cyan-400 border-cyan-500/50 text-xs">
                        <Lightbulb size={10} className="mr-1" />
                        {page.opportunities}
                      </Badge>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
          
          <div className="lg:col-span-2">
            <AnimatePresence mode="wait">
              <motion.div
                key={selectedPage.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                transition={{ duration: 0.2 }}
              >
                <Card className="bg-gray-800 border-gray-700 mb-4">
                  <CardHeader>
                    <CardTitle className="text-white">{selectedPage.title}</CardTitle>
                  </CardHeader>
                </Card>
                <PageAnalysis page={selectedPage} />
              </motion.div>
            </AnimatePresence>
          </div>
        </TabsContent>

        <TabsContent value="map" className="h-full">
          <TopicalMap pages={mockPages} onPageSelect={setSelectedPage} />
        </TabsContent>
      </Tabs>
    </div>
  );
}