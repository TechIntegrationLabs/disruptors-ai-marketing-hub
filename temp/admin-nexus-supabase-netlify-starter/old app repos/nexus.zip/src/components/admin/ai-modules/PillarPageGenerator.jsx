import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Wand2, Share, FileText, Check, Copy } from 'lucide-react';
import { AnimatePresence, motion } from 'framer-motion';

const sampleClusterPlan = {
  pillar: "The Ultimate Guide to Headless CMS",
  clusters: [
    { title: "What is a Headless CMS and How Does It Work?", links_to: [] },
    { title: "Benefits of a Headless CMS for Modern Web Development", links_to: ["pillar"] },
    { title: "Top 5 Headless CMS Platforms in 2025", links_to: ["pillar"] },
    { title: "Migrating from a Monolithic CMS to Headless: A Step-by-Step Guide", links_to: ["pillar", "cluster_0"] },
    { title: "Headless CMS vs. Traditional CMS: Which is Right for You?", links_to: ["pillar", "cluster_1"] },
    { title: "Building a Blog with a Headless CMS and Next.js", links_to: ["pillar", "cluster_0"] },
  ]
};

export default function PillarPageGenerator() {
  const [topic, setTopic] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [plan, setPlan] = useState(null);

  const handleGenerate = () => {
    if (!topic) return;
    setIsLoading(true);
    setPlan(null);
    setTimeout(() => {
      setPlan(sampleClusterPlan);
      setIsLoading(false);
    }, 1500);
  };

  return (
    <div className="p-6 h-full flex flex-col text-white bg-gray-900">
      <div className="flex items-center gap-4 mb-6">
        <Input
          placeholder="Enter a broad Pillar Topic (e.g., 'Content Marketing')"
          value={topic}
          onChange={(e) => setTopic(e.target.value)}
          className="flex-1 bg-gray-800 border-gray-600 text-white placeholder-gray-500"
        />
        <Button onClick={handleGenerate} disabled={isLoading} className="bg-cyan-600 hover:bg-cyan-700">
          <Wand2 className="mr-2 h-4 w-4" />
          {isLoading ? "Building Plan..." : "Generate Pillar Plan"}
        </Button>
      </div>

      <div className="flex-1 overflow-y-auto pr-2">
        {isLoading && (
          <div className="flex items-center justify-center h-full text-gray-400">
            <p>Analyzing topic... Identifying sub-topics and creating content structure...</p>
          </div>
        )}
        <AnimatePresence>
        {plan && (
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
            <Card className="bg-gray-800 border-gray-700">
              <CardHeader>
                <CardTitle className="text-xl text-white">{plan.pillar}</CardTitle>
                <div className="flex gap-2 mt-2">
                    <Badge variant="secondary" className="bg-purple-500/20 text-purple-300">Pillar Page</Badge>
                    <Button size="sm" variant="outline"><Copy className="mr-2 h-3 w-3" /> Copy Plan</Button>
                    <Button size="sm" className="bg-cyan-600 hover:bg-cyan-700"><Share className="mr-2 h-3 w-3" /> Send to CMS</Button>
                </div>
              </CardHeader>
              <CardContent>
                <h4 className="font-semibold mb-4 text-cyan-400">Supporting Cluster Pages:</h4>
                <div className="space-y-3">
                  {plan.clusters.map((cluster, index) => (
                    <motion.div 
                        key={index}
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: 0.2 + index * 0.1 }}
                    >
                        <Card className="bg-gray-700/50 p-4 border-gray-600">
                            <p className="font-medium text-white">{cluster.title}</p>
                            <div className="flex items-center gap-2 mt-2 text-xs text-gray-400">
                                <span>Links to:</span>
                                <Badge variant="outline" className="text-purple-300 border-purple-500/30">Pillar Page</Badge>
                                {cluster.links_to.map(link => link.startsWith('cluster') && (
                                    <Badge key={link} variant="outline" className="text-cyan-300 border-cyan-500/30">
                                        Cluster #{parseInt(link.split('_')[1]) + 1}
                                    </Badge>
                                ))}
                            </div>
                        </Card>
                    </motion.div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </motion.div>
        )}
        </AnimatePresence>
        {!isLoading && !plan && (
             <div className="flex items-center justify-center h-full text-center text-gray-500">
                <div>
                    <FileText className="w-16 h-16 mx-auto mb-4"/>
                    <h3 className="text-lg font-semibold">Content structure will be generated here.</h3>
                    <p>Enter a pillar topic to create a map of supporting content.</p>
                </div>
            </div>
        )}
      </div>
    </div>
  );
}