import React from 'react';
import { Construction } from 'lucide-react';
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";

export default function ComingSoonModule({ module }) {
  return (
    <div className="flex flex-col items-center justify-center h-full p-10 text-center bg-gray-900 text-white">
      <Construction className="w-24 h-24 text-cyan-500 mb-6 animate-pulse" />
      <h2 className="text-2xl font-bold mb-4">{module.title}</h2>
      <p className="text-gray-400 max-w-2xl mb-6 text-lg leading-relaxed">{module.purpose}</p>
      <div className="flex items-center gap-4 mb-8">
        <Badge variant="outline" className="text-cyan-400 border-cyan-500/50 px-4 py-2">
          Phase {module.phase}
        </Badge>
        <Badge variant="outline" className="text-orange-400 border-orange-500/50 px-4 py-2">
          Coming Soon
        </Badge>
      </div>
      
      <div className="space-y-3 text-sm text-gray-500 max-w-lg">
        <div className="flex items-center justify-between py-2 border-b border-gray-700">
          <span>UI Design</span>
          <Badge className="bg-green-500/20 text-green-400">✓ Complete</Badge>
        </div>
        <div className="flex items-center justify-between py-2 border-b border-gray-700">
          <span>Data Models</span>
          <Badge className="bg-yellow-500/20 text-yellow-400">⚠ In Progress</Badge>
        </div>
        <div className="flex items-center justify-between py-2 border-b border-gray-700">
          <span>MCP Integration</span>
          <Badge className="bg-gray-500/20 text-gray-400">⏳ Planned</Badge>
        </div>
        <div className="flex items-center justify-between py-2 border-b border-gray-700">
          <span>Testing</span>
          <Badge className="bg-gray-500/20 text-gray-400">⏳ Planned</Badge>
        </div>
      </div>

      <div className="mt-8 flex gap-3">
        <Button variant="outline" className="border-gray-600 text-gray-300">
          Request Early Access
        </Button>
        <Button className="bg-cyan-600 hover:bg-cyan-700">
          View Roadmap
        </Button>
      </div>
    </div>
  );
}