import React, { useState, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Plus, User, Trash2, TestTube2 } from 'lucide-react';
import { Persona } from '@/api/entities/Persona';
import { AnimatePresence, motion } from 'framer-motion';

const samplePersonas = [
  {
    id: "pers_builder",
    name: "The Builder",
    bio: "Hands-on operator who prizes speed and clarity.",
    voice: "Direct, practical, a little playful.",
    constraints: "Max 12-word sentences.",
    exampleSnippets: ["Here’s the fastest way to test it."]
  },
  {
    id: "pers_strategist",
    name: "The Strategist",
    bio: "Sees the big picture and connects actions to outcomes.",
    voice: "Authoritative, insightful, forward-looking.",
    constraints: "Always explain the 'why' behind the 'what'.",
    exampleSnippets: ["This approach de-risks the launch by validating demand first."]
  },
];

export default function AuthorPersonas() {
  const [personas, setPersonas] = useState([]);
  const [selectedPersona, setSelectedPersona] = useState(null);

  useEffect(() => {
    // In a real app, you'd fetch from the Persona entity
    // await Persona.list();
    setPersonas(samplePersonas);
  }, []);

  const handleSelectPersona = (persona) => {
    setSelectedPersona(persona);
  };

  const handleSave = (personaToSave) => {
    if(personaToSave.id) {
        setPersonas(personas.map(p => p.id === personaToSave.id ? personaToSave : p));
    } else {
        const newPersona = { ...personaToSave, id: `pers_${Math.random().toString(36).substr(2, 9)}`};
        setPersonas([...personas, newPersona]);
    }
    setSelectedPersona(null);
  };

  const handleDelete = (personaId) => {
    setPersonas(personas.filter(p => p.id !== personaId));
    setSelectedPersona(null);
  };

  const PersonaForm = ({ persona, onSave, onCancel, onDelete }) => (
    <div className="p-6 space-y-6">
      <Input 
        defaultValue={persona?.name} 
        placeholder="Persona Name (e.g., The Expert)" 
        className="text-lg font-bold bg-gray-800 border-gray-600 text-white"
        onChange={(e) => setSelectedPersona({...selectedPersona, name: e.target.value})}
      />
      <Textarea 
        defaultValue={persona?.bio} 
        placeholder="Bio: A short description of this persona's point of view." 
        className="bg-gray-800 border-gray-600 text-white"
        onChange={(e) => setSelectedPersona({...selectedPersona, bio: e.target.value})}
      />
      <Textarea 
        defaultValue={persona?.voice} 
        placeholder="Voice: Describe the tone and style (e.g., 'Direct, helpful, confident')." 
        className="bg-gray-800 border-gray-600 text-white"
        onChange={(e) => setSelectedPersona({...selectedPersona, voice: e.target.value})}
      />
      <Textarea 
        defaultValue={persona?.constraints} 
        placeholder="Constraints: Any specific rules (e.g., 'Avoid jargon, use active voice')." 
        className="bg-gray-800 border-gray-600 text-white"
        onChange={(e) => setSelectedPersona({...selectedPersona, constraints: e.target.value})}
      />
      
      <div>
          <label className="text-sm font-medium text-gray-300 mb-2 block">Example Snippets</label>
          <Textarea 
            defaultValue={persona?.exampleSnippets?.join('\n')} 
            placeholder="One example sentence per line demonstrating the voice." 
            className="bg-gray-800 border-gray-600 text-white font-mono text-sm"
            onChange={(e) => setSelectedPersona({...selectedPersona, exampleSnippets: e.target.value.split('\n')})}
          />
      </div>

      <div className="flex justify-between items-center">
        <div>
            {persona?.id && (
                <Button variant="destructive" size="sm" onClick={() => onDelete(persona.id)}>
                    <Trash2 className="mr-2 h-4 w-4" /> Delete
                </Button>
            )}
        </div>
        <div className="flex gap-4">
          <Button variant="outline" onClick={onCancel}>Cancel</Button>
          <Button onClick={() => onSave(selectedPersona)} className="bg-cyan-600 hover:bg-cyan-700">Save Persona</Button>
        </div>
      </div>
    </div>
  );
  
  return (
    <div className="h-full flex text-white bg-gray-900">
      <div className="w-1/3 border-r border-gray-700 p-4 space-y-2 overflow-y-auto">
        <Button 
            className="w-full justify-start mb-4" 
            variant="outline" 
            onClick={() => handleSelectPersona({})}
        >
            <Plus className="mr-2 h-4 w-4" /> New Persona
        </Button>
        <AnimatePresence>
        {personas.map(p => (
          <motion.div key={p.id} layout initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
            <Card 
              className={`cursor-pointer bg-gray-800 border-gray-700 ${selectedPersona?.id === p.id ? 'border-cyan-500' : 'hover:border-gray-600'}`}
              onClick={() => handleSelectPersona(p)}
            >
              <CardHeader>
                <CardTitle className="text-base flex items-center gap-2">
                    <User /> {p.name}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-gray-400 line-clamp-2">{p.bio}</p>
              </CardContent>
            </Card>
          </motion.div>
        ))}
        </AnimatePresence>
      </div>
      <div className="w-2/3 overflow-y-auto">
        {selectedPersona ? (
          <PersonaForm 
            persona={selectedPersona}
            onSave={handleSave}
            onCancel={() => setSelectedPersona(null)}
            onDelete={handleDelete}
          />
        ) : (
          <div className="flex flex-col items-center justify-center h-full text-center p-8">
            <User className="w-16 h-16 text-gray-600 mb-4" />
            <h3 className="text-xl font-bold">Select or Create a Persona</h3>
            <p className="text-gray-500 mt-2 max-w-md">Personas define the voice and style for AI-generated content. Select a persona on the left to edit, or create a new one.</p>
          </div>
        )}
      </div>
    </div>
  );
}