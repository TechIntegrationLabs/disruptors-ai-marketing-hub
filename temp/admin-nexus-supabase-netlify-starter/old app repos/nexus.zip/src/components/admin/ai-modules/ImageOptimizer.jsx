
import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import { Slider } from "@/components/ui/slider";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { 
  Image, 
  Upload, 
  Download, 
  Zap, 
  CheckCircle, 
  Clock,
  FileImage,
  Shrink, // Changed from Compress to Shrink
  Palette,
  Tag,
  Settings
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

const optimizationPresets = [
  { id: 'web', name: 'Web Optimized', quality: 85, format: 'webp', description: 'Best for websites and blogs' },
  { id: 'print', name: 'Print Quality', quality: 95, format: 'jpg', description: 'High quality for print materials' },
  { id: 'thumbnail', name: 'Thumbnail', quality: 70, format: 'webp', description: 'Small preview images' },
  { id: 'social', name: 'Social Media', quality: 80, format: 'jpg', description: 'Optimized for social platforms' }
];

const mockImages = [
  {
    id: 1,
    name: 'hero-banner.jpg',
    originalSize: '2.4 MB',
    optimizedSize: '180 KB',
    savings: 92,
    status: 'completed',
    altText: 'Modern office workspace with laptop and coffee',
    tags: ['hero', 'office', 'workspace']
  },
  {
    id: 2,
    name: 'product-shot.png',
    originalSize: '1.8 MB',
    optimizedSize: '220 KB',
    savings: 88,
    status: 'processing',
    altText: '',
    tags: []
  },
  {
    id: 3,
    name: 'team-photo.jpg',
    originalSize: '3.2 MB',
    optimizedSize: '0 KB',
    savings: 0,
    status: 'pending',
    altText: 'Company team photo at annual retreat',
    tags: ['team', 'company', 'people']
  }
];

const BatchOptimizer = ({ images, onOptimize }) => {
  const [selectedImages, setSelectedImages] = useState([]);
  const [preset, setPreset] = useState('web');
  const [isOptimizing, setIsOptimizing] = useState(false);

  const handleOptimize = () => {
    if (selectedImages.length === 0) return;
    setIsOptimizing(true);
    setTimeout(() => {
      setIsOptimizing(false);
      onOptimize(selectedImages, preset);
    }, 2000);
  };

  const toggleImageSelection = (imageId) => {
    setSelectedImages(prev => 
      prev.includes(imageId) 
        ? prev.filter(id => id !== imageId)
        : [...prev, imageId]
    );
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold text-white">Batch Optimization</h3>
        <div className="flex items-center gap-2">
          <Select value={preset} onValueChange={setPreset}>
            <SelectTrigger className="w-48 bg-gray-800 border-gray-600 text-white">
              <SelectValue />
            </SelectTrigger>
            <SelectContent className="bg-gray-800 border-gray-600">
              {optimizationPresets.map(p => (
                <SelectItem key={p.id} value={p.id} className="text-white">
                  {p.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Button 
            onClick={handleOptimize}
            disabled={selectedImages.length === 0 || isOptimizing}
            className="bg-cyan-600 hover:bg-cyan-700"
          >
            {isOptimizing ? (
              <>
                <Clock className="w-4 h-4 mr-2 animate-spin" />
                Optimizing...
              </>
            ) : (
              <>
                <Shrink className="w-4 h-4 mr-2" /> {/* Changed from Compress to Shrink */}
                Optimize Selected ({selectedImages.length})
              </>
            )}
          </Button>
        </div>
      </div>

      <div className="grid gap-4">
        {images.map(image => (
          <Card key={image.id} className="bg-gray-800 border-gray-700">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <input
                    type="checkbox"
                    checked={selectedImages.includes(image.id)}
                    onChange={() => toggleImageSelection(image.id)}
                    className="w-4 h-4 text-cyan-600 bg-gray-700 border-gray-600 rounded focus:ring-cyan-500"
                  />
                  <FileImage className="w-8 h-8 text-gray-400" />
                  <div>
                    <h4 className="font-medium text-white">{image.name}</h4>
                    <div className="flex items-center gap-4 text-sm text-gray-400">
                      <span>{image.originalSize}</span>
                      {image.status === 'completed' && (
                        <>
                          <span>→ {image.optimizedSize}</span>
                          <Badge className="bg-green-500/20 text-green-400">
                            {image.savings}% smaller
                          </Badge>
                        </>
                      )}
                    </div>
                  </div>
                </div>
                
                <div className="flex items-center gap-2">
                  {image.status === 'processing' && (
                    <div className="flex items-center gap-2 text-yellow-400">
                      <Clock className="w-4 h-4 animate-spin" />
                      <span className="text-sm">Processing...</span>
                    </div>
                  )}
                  {image.status === 'completed' && (
                    <CheckCircle className="w-4 h-4 text-green-400" />
                  )}
                  <Button variant="ghost" size="sm" className="text-gray-400">
                    <Settings className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
};

const MetadataEditor = ({ image, onSave }) => {
  const [altText, setAltText] = useState(image?.altText || '');
  const [tags, setTags] = useState(image?.tags?.join(', ') || '');
  const [isGeneratingAlt, setIsGeneratingAlt] = useState(false);

  const generateAltText = () => {
    setIsGeneratingAlt(true);
    setTimeout(() => {
      setAltText('AI-generated alt text describing the image content for accessibility');
      setIsGeneratingAlt(false);
    }, 1500);
  };

  return (
    <div className="space-y-4">
      <h3 className="text-lg font-semibold text-white flex items-center gap-2">
        <Tag className="text-cyan-400" />
        Metadata & SEO
      </h3>
      
      <div className="space-y-3">
        <div>
          <label className="block text-sm font-medium text-gray-300 mb-2">
            Alt Text (for accessibility)
          </label>
          <div className="flex gap-2">
            <Textarea
              value={altText}
              onChange={(e) => setAltText(e.target.value)}
              placeholder="Describe what's in this image..."
              className="bg-gray-800 border-gray-600 text-white"
              rows={3}
            />
            <Button
              onClick={generateAltText}
              disabled={isGeneratingAlt}
              variant="outline"
              className="border-gray-600 text-gray-300 shrink-0"
            >
              {isGeneratingAlt ? (
                <Clock className="w-4 h-4 animate-spin" />
              ) : (
                <Zap className="w-4 h-4" />
              )}
            </Button>
          </div>
        </div>
        
        <div>
          <label className="block text-sm font-medium text-gray-300 mb-2">
            Tags (comma separated)
          </label>
          <Input
            value={tags}
            onChange={(e) => setTags(e.target.value)}
            placeholder="hero, product, lifestyle..."
            className="bg-gray-800 border-gray-600 text-white"
          />
        </div>
        
        <Button onClick={() => onSave({ altText, tags: tags.split(',').map(t => t.trim()) })}>
          Save Metadata
        </Button>
      </div>
    </div>
  );
};

const OptimizationSettings = () => {
  const [quality, setQuality] = useState([85]);
  const [format, setFormat] = useState('webp');
  const [autoAlt, setAutoAlt] = useState(true);
  const [autoTags, setAutoTags] = useState(false);

  return (
    <div className="space-y-6">
      <h3 className="text-lg font-semibold text-white flex items-center gap-2">
        <Settings className="text-cyan-400" />
        Optimization Settings
      </h3>
      
      <div className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-gray-300 mb-2">
            Quality: {quality[0]}%
          </label>
          <Slider
            value={quality}
            onValueChange={setQuality}
            min={10}
            max={100}
            step={5}
            className="w-full"
          />
        </div>
        
        <div>
          <label className="block text-sm font-medium text-gray-300 mb-2">
            Output Format
          </label>
          <Select value={format} onValueChange={setFormat}>
            <SelectTrigger className="bg-gray-800 border-gray-600 text-white">
              <SelectValue />
            </SelectTrigger>
            <SelectContent className="bg-gray-800 border-gray-600">
              <SelectItem value="webp">WebP (Best compression)</SelectItem>
              <SelectItem value="jpg">JPEG (Universal support)</SelectItem>
              <SelectItem value="png">PNG (Lossless)</SelectItem>
              <SelectItem value="avif">AVIF (Next-gen format)</SelectItem>
            </SelectContent>
          </Select>
        </div>
        
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <label className="text-sm font-medium text-gray-300">
              Auto-generate Alt Text
            </label>
            <Switch
              checked={autoAlt}
              onCheckedChange={setAutoAlt}
              className="data-[state=checked]:bg-cyan-600"
            />
          </div>
          
          <div className="flex items-center justify-between">
            <label className="text-sm font-medium text-gray-300">
              Auto-generate Tags
            </label>
            <Switch
              checked={autoTags}
              onCheckedChange={setAutoTags}
              className="data-[state=checked]:bg-cyan-600"
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default function ImageOptimizer() {
  const [images, setImages] = useState(mockImages);
  const [selectedImage, setSelectedImage] = useState(null);

  const handleOptimize = (imageIds, preset) => {
    setImages(prev => prev.map(img => 
      imageIds.includes(img.id) 
        ? { ...img, status: 'completed', optimizedSize: '150 KB', savings: 85 }
        : img
    ));
  };

  const handleSaveMetadata = (metadata) => {
    console.log('Saving metadata:', metadata);
  };

  return (
    <div className="p-6 h-full bg-gray-900 text-white">
      <Tabs defaultValue="batch" className="h-full flex flex-col">
        <TabsList className="grid w-full grid-cols-3 bg-gray-800 border-gray-700">
          <TabsTrigger value="batch" className="data-[state=active]:bg-gray-700 data-[state=active]:text-white">
            Batch Optimize
          </TabsTrigger>
          <TabsTrigger value="metadata" className="data-[state=active]:bg-gray-700 data-[state=active]:text-white">
            Metadata & Tags
          </TabsTrigger>
          <TabsTrigger value="settings" className="data-[state=active]:bg-gray-700 data-[state=active]:text-white">
            Settings
          </TabsTrigger>
        </TabsList>
        
        <TabsContent value="batch" className="flex-1 mt-4">
          <BatchOptimizer images={images} onOptimize={handleOptimize} />
        </TabsContent>
        
        <TabsContent value="metadata" className="flex-1 mt-4">
          <MetadataEditor image={selectedImage} onSave={handleSaveMetadata} />
        </TabsContent>
        
        <TabsContent value="settings" className="flex-1 mt-4">
          <OptimizationSettings />
        </TabsContent>
      </Tabs>
    </div>
  );
}
