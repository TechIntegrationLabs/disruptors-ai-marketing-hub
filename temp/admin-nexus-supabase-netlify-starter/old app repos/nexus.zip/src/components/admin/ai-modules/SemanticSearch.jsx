import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";
import { 
  Search, 
  Zap, 
  Settings, 
  BarChart3,
  Brain,
  Target,
  Clock,
  TrendingUp
} from 'lucide-react';

const mockSearchResults = [
  {
    id: 1,
    title: 'Ultimate Guide to SEO in 2025',
    url: '/blog/ultimate-seo-guide-2025',
    excerpt: 'Comprehensive guide covering all aspects of modern SEO including technical optimization, content strategy, and link building.',
    relevanceScore: 0.95,
    semanticMatch: 0.87,
    type: 'content'
  },
  {
    id: 2,
    title: 'SEO Tools Comparison',
    url: '/resources/seo-tools-comparison',
    excerpt: 'Compare the best SEO tools available in 2025, from free options to enterprise solutions.',
    relevanceScore: 0.82,
    semanticMatch: 0.74,
    type: 'resource'
  },
  {
    id: 3,
    title: 'Local SEO Strategies',
    url: '/blog/local-seo-strategies',
    excerpt: 'Proven strategies to improve your local search rankings and attract more customers.',
    relevanceScore: 0.78,
    semanticMatch: 0.69,
    type: 'content'
  }
];

const mockAnalytics = {
  totalSearches: 15847,
  avgResultsClicked: 2.3,
  zeroResultQueries: 8.2,
  avgResponseTime: 0.12,
  topQueries: [
    { query: 'SEO optimization', count: 892, ctr: 0.23 },
    { query: 'content marketing', count: 743, ctr: 0.31 },
    { query: 'keyword research', count: 621, ctr: 0.18 },
    { query: 'technical SEO', count: 534, ctr: 0.27 },
    { query: 'link building', count: 467, ctr: 0.22 }
  ]
};

const SearchDemo = ({ onSearch, results, isSearching }) => {
  const [query, setQuery] = useState('');
  const [semanticWeight, setSemanticWeight] = useState([70]);
  const [usePersonalization, setUsePersonalization] = useState(true);
  
  const handleSearch = () => {
    if (query.trim()) {
      onSearch(query, { semanticWeight: semanticWeight[0], usePersonalization });
    }
  };

  return (
    <div className="space-y-6">
      <Card className="bg-gray-800 border-gray-700">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Search size={20} />
            Search Demo
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex gap-3">
            <Input
              placeholder="Try searching: SEO best practices, content marketing tips..."
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
              className="flex-1 bg-gray-700 border-gray-600 text-white"
            />
            <Button 
              onClick={handleSearch}
              disabled={!query.trim() || isSearching}
              className="bg-cyan-600 hover:bg-cyan-700"
            >
              {isSearching ? <Clock size={16} className="animate-spin" /> : <Search size={16} />}
            </Button>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <label className="text-sm text-gray-300">Semantic Weight: {semanticWeight[0]}%</label>
              <Slider
                value={semanticWeight}
                onValueChange={setSemanticWeight}
                max={100}
                step={5}
                className="w-full"
              />
              <div className="flex justify-between text-xs text-gray-500">
                <span>Keyword Match</span>
                <span>Semantic Understanding</span>
              </div>
            </div>
            
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <label className="text-sm text-gray-300">Use Personalization</label>
                <Switch 
                  checked={usePersonalization}
                  onCheckedChange={setUsePersonalization}
                />
              </div>
              <div className="flex items-center justify-between">
                <label className="text-sm text-gray-300">Include Synonyms</label>
                <Switch defaultChecked />
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {results.length > 0 && (
        <Card className="bg-gray-800 border-gray-700">
          <CardHeader>
            <CardTitle className="text-white">Search Results ({results.length})</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {results.map(result => (
                <div key={result.id} className="p-4 bg-gray-700 rounded-lg">
                  <div className="flex items-start justify-between mb-2">
                    <div className="flex-1">
                      <h3 className="text-cyan-400 font-medium hover:text-cyan-300 cursor-pointer">
                        {result.title}
                      </h3>
                      <p className="text-xs text-gray-500 mb-2">{result.url}</p>
                      <p className="text-gray-300 text-sm">{result.excerpt}</p>
                    </div>
                    <div className="ml-4 text-right">
                      <Badge variant="outline" className="text-green-400 border-green-500/50 mb-1">
                        {Math.round(result.relevanceScore * 100)}% relevance
                      </Badge>
                      <div className="text-xs text-gray-400">
                        Semantic: {Math.round(result.semanticMatch * 100)}%
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

const SearchAnalytics = () => (
  <div className="space-y-6">
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
      <Card className="bg-gray-800 border-gray-700">
        <CardContent className="p-4 text-center">
          <div className="text-2xl font-bold text-white">{mockAnalytics.totalSearches.toLocaleString()}</div>
          <div className="text-sm text-gray-400">Total Searches</div>
          <div className="text-xs text-green-400 flex items-center justify-center mt-1">
            <TrendingUp size={12} className="mr-1" />
            +15% this month
          </div>
        </CardContent>
      </Card>
      
      <Card className="bg-gray-800 border-gray-700">
        <CardContent className="p-4 text-center">
          <div className="text-2xl font-bold text-white">{mockAnalytics.avgResultsClicked}</div>
          <div className="text-sm text-gray-400">Avg Results Clicked</div>
          <div className="text-xs text-green-400 flex items-center justify-center mt-1">
            <TrendingUp size={12} className="mr-1" />
            +8% this month
          </div>
        </CardContent>
      </Card>
      
      <Card className="bg-gray-800 border-gray-700">
        <CardContent className="p-4 text-center">
          <div className="text-2xl font-bold text-white">{mockAnalytics.zeroResultQueries}%</div>
          <div className="text-sm text-gray-400">Zero Result Queries</div>
          <div className="text-xs text-red-400 flex items-center justify-center mt-1">
            -3% this month
          </div>
        </CardContent>
      </Card>
      
      <Card className="bg-gray-800 border-gray-700">
        <CardContent className="p-4 text-center">
          <div className="text-2xl font-bold text-white">{mockAnalytics.avgResponseTime}s</div>
          <div className="text-sm text-gray-400">Avg Response Time</div>
          <div className="text-xs text-green-400 flex items-center justify-center mt-1">
            -12ms this month
          </div>
        </CardContent>
      </Card>
    </div>
    
    <Card className="bg-gray-800 border-gray-700">
      <CardHeader>
        <CardTitle className="text-white">Top Search Queries</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {mockAnalytics.topQueries.map((item, index) => (
            <div key={index} className="flex items-center justify-between p-3 bg-gray-700 rounded-lg">
              <div className="flex items-center gap-3">
                <div className="w-6 h-6 bg-cyan-600 rounded-full flex items-center justify-center text-xs font-bold text-white">
                  {index + 1}
                </div>
                <div>
                  <div className="text-white font-medium">{item.query}</div>
                  <div className="text-xs text-gray-400">{item.count} searches</div>
                </div>
              </div>
              <div className="text-right">
                <div className="text-white font-medium">{Math.round(item.ctr * 100)}%</div>
                <div className="text-xs text-gray-400">CTR</div>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  </div>
);

export default function SemanticSearch() {
  const [activeTab, setActiveTab] = useState('demo');
  const [searchResults, setSearchResults] = useState([]);
  const [isSearching, setIsSearching] = useState(false);

  const handleSearch = (query, options) => {
    setIsSearching(true);
    setSearchResults([]);
    
    setTimeout(() => {
      // Filter mock results based on query
      const filteredResults = mockSearchResults.filter(result =>
        result.title.toLowerCase().includes(query.toLowerCase()) ||
        result.excerpt.toLowerCase().includes(query.toLowerCase())
      );
      
      setSearchResults(filteredResults.length > 0 ? filteredResults : mockSearchResults);
      setIsSearching(false);
    }, 800);
  };

  return (
    <div className="p-6 h-full bg-gray-900 text-white">
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <div className="flex items-center justify-between mb-6">
          <TabsList className="bg-gray-800 border-gray-700">
            <TabsTrigger value="demo" className="data-[state=active]:bg-cyan-600">
              Search Demo
            </TabsTrigger>
            <TabsTrigger value="analytics" className="data-[state=active]:bg-cyan-600">
              Analytics
            </TabsTrigger>
            <TabsTrigger value="settings" className="data-[state=active]:bg-cyan-600">
              Settings
            </TabsTrigger>
          </TabsList>
          <Button className="bg-cyan-600 hover:bg-cyan-700">
            <Brain size={16} className="mr-2" />
            Reindex Content
          </Button>
        </div>

        <TabsContent value="demo">
          <SearchDemo 
            onSearch={handleSearch}
            results={searchResults}
            isSearching={isSearching}
          />
        </TabsContent>

        <TabsContent value="analytics">
          <SearchAnalytics />
        </TabsContent>

        <TabsContent value="settings">
          <Card className="bg-gray-800 border-gray-700">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <Settings size={20} />
                Search Configuration
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="text-center text-gray-400 py-8">
                <Settings className="w-12 h-12 mx-auto mb-4 opacity-50" />
                <p>Advanced search settings and index management coming soon</p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}