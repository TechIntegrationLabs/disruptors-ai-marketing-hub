import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { 
  Layout, 
  Eye, 
  Settings, 
  Zap,
  Palette,
  Type,
  MousePointerClick,
  BarChart3,
  Copy,
  Smartphone,
  Monitor
} from 'lucide-react';

const templates = [
  {
    id: 'saas-hero',
    name: 'SaaS Hero',
    category: 'Software',
    description: 'Perfect for software products with feature highlights',
    conversionRate: 8.2,
    preview: '/api/placeholder/300/200'
  },
  {
    id: 'lead-magnet',
    name: 'Lead Magnet',
    category: 'Lead Gen',
    description: 'Optimized for collecting email addresses',
    conversionRate: 12.5,
    preview: '/api/placeholder/300/200'
  },
  {
    id: 'product-launch',
    name: 'Product Launch',
    category: 'E-commerce',
    description: 'High-impact page for product announcements',
    conversionRate: 6.8,
    preview: '/api/placeholder/300/200'
  },
  {
    id: 'webinar-signup',
    name: 'Webinar Signup',
    category: 'Events',
    description: 'Drive registrations for webinars and events',
    conversionRate: 15.3,
    preview: '/api/placeholder/300/200'
  }
];

const mockPages = [
  {
    id: 1,
    name: 'Q1 Product Launch',
    template: 'product-launch',
    status: 'published',
    visits: 2847,
    conversions: 194,
    conversionRate: 6.8,
    lastModified: '2 days ago'
  },
  {
    id: 2,
    name: 'Free SEO Audit',
    template: 'lead-magnet',
    status: 'draft',
    visits: 0,
    conversions: 0,
    conversionRate: 0,
    lastModified: '1 hour ago'
  },
  {
    id: 3,
    name: 'Webinar: AI in Marketing',
    template: 'webinar-signup',
    status: 'published',
    visits: 1294,
    conversions: 198,
    conversionRate: 15.3,
    lastModified: '5 days ago'
  }
];

const TemplateGallery = ({ onSelectTemplate }) => (
  <div className="space-y-4">
    <div className="flex items-center justify-between">
      <h3 className="text-lg font-semibold text-white">Choose a Template</h3>
      <Select defaultValue="all">
        <SelectTrigger className="w-48 bg-gray-800 border-gray-600 text-white">
          <SelectValue />
        </SelectTrigger>
        <SelectContent className="bg-gray-800 border-gray-600">
          <SelectItem value="all">All Categories</SelectItem>
          <SelectItem value="software">Software</SelectItem>
          <SelectItem value="leadgen">Lead Generation</SelectItem>
          <SelectItem value="ecommerce">E-commerce</SelectItem>
          <SelectItem value="events">Events</SelectItem>
        </SelectContent>
      </Select>
    </div>
    
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
      {templates.map(template => (
        <Card key={template.id} className="bg-gray-800 border-gray-700 hover:border-cyan-500/50 transition-colors cursor-pointer">
          <div className="aspect-video bg-gray-700 rounded-t-lg flex items-center justify-center">
            <Layout className="w-12 h-12 text-gray-500" />
          </div>
          <CardContent className="p-4">
            <div className="flex items-start justify-between mb-2">
              <h4 className="font-medium text-white">{template.name}</h4>
              <Badge variant="outline" className="text-green-400 border-green-500/50 text-xs">
                {template.conversionRate}% CVR
              </Badge>
            </div>
            <p className="text-sm text-gray-400 mb-3">{template.description}</p>
            <Button 
              onClick={() => onSelectTemplate(template)}
              className="w-full bg-cyan-600 hover:bg-cyan-700"
              size="sm"
            >
              Use Template
            </Button>
          </CardContent>
        </Card>
      ))}
    </div>
  </div>
);

const PageBuilder = ({ template }) => {
  const [pageName, setPageName] = useState('');
  const [headline, setHeadline] = useState('');
  const [subheadline, setSubheadline] = useState('');
  const [ctaText, setCtaText] = useState('Get Started');
  const [selectedDevice, setSelectedDevice] = useState('desktop');

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      <div className="space-y-6">
        <Card className="bg-gray-800 border-gray-700">
          <CardHeader>
            <CardTitle className="text-white">Page Settings</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">Page Name</label>
              <Input
                placeholder="My Landing Page"
                value={pageName}
                onChange={(e) => setPageName(e.target.value)}
                className="bg-gray-700 border-gray-600 text-white"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">Headline</label>
              <Input
                placeholder="Compelling headline that converts"
                value={headline}
                onChange={(e) => setHeadline(e.target.value)}
                className="bg-gray-700 border-gray-600 text-white"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">Subheadline</label>
              <Textarea
                placeholder="Supporting text that explains your value proposition"
                value={subheadline}
                onChange={(e) => setSubheadline(e.target.value)}
                className="bg-gray-700 border-gray-600 text-white h-20"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">Call-to-Action Text</label>
              <Input
                placeholder="Get Started"
                value={ctaText}
                onChange={(e) => setCtaText(e.target.value)}
                className="bg-gray-700 border-gray-600 text-white"
              />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gray-800 border-gray-700">
          <CardHeader>
            <CardTitle className="text-white">Design Options</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <label className="text-sm text-gray-300">Dark Mode</label>
              <Switch />
            </div>
            <div className="flex items-center justify-between">
              <label className="text-sm text-gray-300">Include Social Proof</label>
              <Switch defaultChecked />
            </div>
            <div className="flex items-center justify-between">
              <label className="text-sm text-gray-300">Mobile Optimized</label>
              <Switch defaultChecked />
            </div>
          </CardContent>
        </Card>

        <div className="flex gap-2">
          <Button className="flex-1 bg-green-600 hover:bg-green-700">
            <Eye size={16} className="mr-2" />
            Preview
          </Button>
          <Button className="flex-1 bg-cyan-600 hover:bg-cyan-700">
            <Zap size={16} className="mr-2" />
            Publish
          </Button>
        </div>
      </div>
      
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-semibold text-white">Live Preview</h3>
          <div className="flex gap-1">
            <Button 
              size="sm" 
              variant={selectedDevice === 'desktop' ? 'default' : 'ghost'}
              onClick={() => setSelectedDevice('desktop')}
            >
              <Monitor size={16} />
            </Button>
            <Button 
              size="sm" 
              variant={selectedDevice === 'mobile' ? 'default' : 'ghost'}
              onClick={() => setSelectedDevice('mobile')}
            >
              <Smartphone size={16} />
            </Button>
          </div>
        </div>
        
        <Card className="bg-gray-800 border-gray-700">
          <div className={`aspect-video bg-gray-700 rounded-lg flex items-center justify-center ${
            selectedDevice === 'mobile' ? 'max-w-xs mx-auto aspect-[9/16]' : 'aspect-video'
          }`}>
            <div className="text-center">
              <Layout className="w-16 h-16 text-gray-500 mx-auto mb-4" />
              <h3 className="text-white font-bold text-lg mb-2">{headline || 'Your Headline Here'}</h3>
              <p className="text-gray-400 mb-4 max-w-md mx-auto">{subheadline || 'Your compelling subheadline appears here'}</p>
              <Button className="bg-cyan-600 hover:bg-cyan-700">
                {ctaText}
              </Button>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
};

const PageManager = () => (
  <div className="space-y-4">
    <div className="flex items-center justify-between">
      <h3 className="text-lg font-semibold text-white">Your Landing Pages</h3>
      <Button className="bg-cyan-600 hover:bg-cyan-700">
        <Zap size={16} className="mr-2" />
        New Page
      </Button>
    </div>
    
    <div className="grid gap-4">
      {mockPages.map(page => (
        <Card key={page.id} className="bg-gray-800 border-gray-700">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div>
                  <h4 className="font-medium text-white">{page.name}</h4>
                  <div className="flex items-center gap-2 text-sm text-gray-400 mt-1">
                    <span>Template: {page.template}</span>
                    <span>•</span>
                    <span>Modified: {page.lastModified}</span>
                  </div>
                </div>
              </div>
              
              <div className="flex items-center gap-6">
                <div className="text-center">
                  <div className="text-lg font-bold text-white">{page.visits.toLocaleString()}</div>
                  <div className="text-xs text-gray-400">Visits</div>
                </div>
                <div className="text-center">
                  <div className="text-lg font-bold text-white">{page.conversions}</div>
                  <div className="text-xs text-gray-400">Conversions</div>
                </div>
                <div className="text-center">
                  <div className="text-lg font-bold text-green-400">{page.conversionRate}%</div>
                  <div className="text-xs text-gray-400">CVR</div>
                </div>
                
                <Badge className={
                  page.status === 'published' ? 'bg-green-500/20 text-green-400' : 
                  'bg-yellow-500/20 text-yellow-400'
                }>
                  {page.status}
                </Badge>
                
                <div className="flex gap-1">
                  <Button size="sm" variant="ghost" className="text-gray-400 hover:text-white">
                    <Eye size={14} />
                  </Button>
                  <Button size="sm" variant="ghost" className="text-gray-400 hover:text-white">
                    <Copy size={14} />
                  </Button>
                  <Button size="sm" variant="ghost" className="text-gray-400 hover:text-white">
                    <Settings size={14} />
                  </Button>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  </div>
);

export default function LandingPageBuilder() {
  const [activeTab, setActiveTab] = useState('templates');
  const [selectedTemplate, setSelectedTemplate] = useState(null);

  const handleSelectTemplate = (template) => {
    setSelectedTemplate(template);
    setActiveTab('builder');
  };

  return (
    <div className="p-6 h-full bg-gray-900 text-white">
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <div className="flex items-center justify-between mb-6">
          <TabsList className="bg-gray-800 border-gray-700">
            <TabsTrigger value="templates" className="data-[state=active]:bg-cyan-600">
              Templates
            </TabsTrigger>
            <TabsTrigger value="builder" className="data-[state=active]:bg-cyan-600">
              Builder
            </TabsTrigger>
            <TabsTrigger value="pages" className="data-[state=active]:bg-cyan-600">
              My Pages
            </TabsTrigger>
          </TabsList>
          <Button className="bg-cyan-600 hover:bg-cyan-700">
            <BarChart3 size={16} className="mr-2" />
            View Analytics
          </Button>
        </div>

        <TabsContent value="templates">
          <TemplateGallery onSelectTemplate={handleSelectTemplate} />
        </TabsContent>

        <TabsContent value="builder">
          {selectedTemplate ? (
            <PageBuilder template={selectedTemplate} />
          ) : (
            <div className="text-center py-12">
              <Layout className="w-16 h-16 text-gray-500 mx-auto mb-4" />
              <h3 className="text-xl font-medium text-white mb-2">Select a Template</h3>
              <p className="text-gray-400 mb-4">Choose a template from the gallery to start building</p>
              <Button onClick={() => setActiveTab('templates')} className="bg-cyan-600 hover:bg-cyan-700">
                Browse Templates
              </Button>
            </div>
          )}
        </TabsContent>

        <TabsContent value="pages">
          <PageManager />
        </TabsContent>
      </Tabs>
    </div>
  );
}