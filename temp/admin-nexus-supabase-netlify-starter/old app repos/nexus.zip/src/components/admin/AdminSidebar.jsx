
import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { 
  LayoutDashboard, 
  GitBranch, 
  Brain, 
  Palette, 
  FileText, 
  BarChart3, 
  Cpu, 
  Network, 
  Bot, 
  Settings,
  Zap,
  Shield,
  ChevronDown,
  ChevronsLeft,
  ChevronsRight,
  X,
  Sparkles // Added Sparkles icon
} from "lucide-react";
import { motion, AnimatePresence } from 'framer-motion';

const mainModules = [
  { id: 'dashboard', name: 'Dashboard', icon: LayoutDashboard, count: null },
  { id: 'website-os', name: 'WebsiteOS CMS', icon: FileText, count: null },
  { id: 'business-brain', name: 'Business Brain', icon: Brain, count: null },
  { id: 'brand-dna', name: 'Brand DNA', icon: Palette, count: null },
  { id: 'telemetry', name: 'Telemetry', icon: BarChart3, count: null },
  { id: 'ai-modules', name: 'AI Modules', icon: Cpu, count: 33 },
  { id: 'agent-orchestra', name: 'Agent Orchestra', icon: Bot, count: 10 },
  { id: 'generative-core', name: 'Generative Core', icon: Sparkles, count: null }, // Added Generative Core
  { id: 'integrations', name: 'Integrations Hub', icon: Zap, count: null },
  { id: 'replicate-ai', name: 'Replicate AI', icon: Zap, count: null },
];

const developerModules = [
  { id: 'repo-admin', name: 'Repo Admin', icon: GitBranch, count: null },
  { id: 'mcp-servers', name: 'MCP Servers', icon: Network, count: 20 },
  { id: 'dev-services', name: 'Dev Services', icon: Settings, count: 8 },
  { id: 'sub-agents', name: 'Sub-Agents', icon: Shield, count: 4 }
];

const CollapsibleAdminMenu = ({ title, icon: Icon, subModules, activeModule, onModuleChange, isCollapsed }) => {
  const isActive = subModules.some(m => m.id === activeModule);
  const [isOpen, setIsOpen] = useState(isActive);

  if (isCollapsed) {
    return (
       <Tooltip>
        <TooltipTrigger asChild>
          <motion.div
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            transition={{ type: "spring", stiffness: 400, damping: 25 }}
          >
            <Button
              variant="ghost"
              onClick={() => setIsOpen(!isOpen)}
              className="w-full justify-center text-left h-auto p-3 text-gray-300 hover:text-cyan-400 hover:bg-gray-800/50 transition-all duration-200"
            >
              <Icon className="w-5 h-5" />
            </Button>
          </motion.div>
        </TooltipTrigger>
        <TooltipContent side="right" className="bg-gray-800 text-white border-cyan-500/30 shadow-xl">
          <p>{title}</p>
        </TooltipContent>
      </Tooltip>
    );
  }

  return (
    <div>
      <motion.div
        whileHover={{ scale: 1.02 }}
        whileTap={{ scale: 0.98 }}
        transition={{ type: "spring", stiffness: 400, damping: 25 }}
      >
        <Button
          variant="ghost"
          onClick={() => setIsOpen(!isOpen)}
          className="w-full justify-between text-left h-auto p-3 text-gray-300 hover:text-cyan-400 hover:bg-gray-800/50 transition-all duration-200"
        >
          <div className="flex items-center space-x-3">
            <Icon className="w-4 h-4" />
            <span className="text-sm">{title}</span>
          </div>
          <motion.div
            animate={{ rotate: isOpen ? 180 : 0 }}
            transition={{ duration: 0.2 }}
          >
            <ChevronDown className="w-4 h-4" />
          </motion.div>
        </Button>
      </motion.div>
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.3, ease: "easeInOut" }}
            className="overflow-hidden pl-4"
          >
            <div className="py-1 space-y-1">
              {subModules.map(module => (
                <motion.div
                  key={module.id}
                  whileHover={{ scale: 1.02, x: 4 }}
                  whileTap={{ scale: 0.98 }}
                  transition={{ type: "spring", stiffness: 400, damping: 25 }}
                >
                  <Button
                    variant={activeModule === module.id ? "default" : "ghost"}
                    onClick={() => onModuleChange(module.id)}
                    className={`w-full justify-start text-left h-auto p-3 transition-all duration-200 ${
                      activeModule === module.id 
                        ? "bg-gradient-cyber text-white font-semibold shadow-lg glow-cyan" 
                        : "text-gray-400 hover:text-cyan-400 hover:bg-gray-700/50"
                    }`}
                  >
                    <div className="flex items-center space-x-3">
                      <module.icon className="w-4 h-4" />
                      <span className="text-xs">{module.name}</span>
                    </div>
                    {module.count && (
                      <Badge variant="outline" className={`text-xs ml-auto transition-colors duration-200 ${
                        activeModule === module.id 
                          ? "border-cyan-200 text-cyan-100"
                          : "border-gray-600 text-gray-400"
                      }`}>
                        {module.count}
                      </Badge>
                    )}
                  </Button>
                </motion.div>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

const ExitButton = () => {
  const [isHovered, setIsHovered] = useState(false);
  
  const handleExit = () => {
    window.location.href = 'https://disruptors-ai-marketing-hub-copy-ff241cda.base44.app';
  };

  return (
    <motion.button
      onClick={handleExit}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      whileHover={{ scale: 1.1 }}
      whileTap={{ scale: 0.9 }}
      className={`absolute top-4 right-4 w-8 h-8 rounded-lg border border-red-500/50 flex items-center justify-center transition-all duration-200 z-50 ${
        isHovered 
          ? 'bg-red-500 text-white shadow-lg' 
          : 'bg-red-500/20 text-red-400 hover:bg-red-500/30'
      }`}
      title="Exit to Marketing Hub"
    >
      <X size={16} />
    </motion.button>
  );
};

export default function AdminSidebar({ activeModule, onModuleChange, isCollapsed, onToggle }) {
  return (
    <TooltipProvider delayDuration={100}>
      <motion.div 
        animate={{ width: isCollapsed ? '5rem' : '20rem' }}
        transition={{ duration: 0.3, ease: "easeInOut" }}
        className="bg-gray-900 border-r border-cyan-500/20 flex flex-col overflow-hidden relative backdrop-blur-sm"
      >
        <ExitButton />
        
        {/* Header */}
        <div className="p-6 border-b border-cyan-500/20 flex items-center" style={{ minHeight: '89px' }}>
          <motion.div 
            whileHover={{ scale: 1.05, rotate: 5 }}
            transition={{ type: "spring", stiffness: 400, damping: 25 }}
            className={`w-10 h-10 bg-gradient-cyber rounded-xl flex items-center justify-center flex-shrink-0 shadow-lg glow-cyan ${isCollapsed ? 'mx-auto' : ''}`}
          >
            <Shield className="w-5 h-5 text-white" />
          </motion.div>
          <AnimatePresence>
          {!isCollapsed && (
            <motion.div 
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ delay: 0.2, duration: 0.2 }}
              className="ml-3"
            >
              <h2 className="text-xl font-bold text-white">WebsiteOS</h2>
              <p className="text-xs text-cyan-400 font-medium">CLIENT DASHBOARD</p>
            </motion.div>
          )}
          </AnimatePresence>
        </div>

        {/* System Status */}
        <div className="p-6 border-b border-cyan-500/20" style={{ minHeight: '81px' }}>
           <div className="flex items-center justify-between">
            {!isCollapsed && <span className="text-sm text-gray-400">System Status</span>}
            <div className={`flex items-center space-x-2 ${isCollapsed ? 'mx-auto' : ''}`}>
              <motion.div 
                animate={{ scale: [1, 1.2, 1] }}
                transition={{ duration: 2, repeat: Infinity }}
                className="w-2 h-2 bg-green-500 rounded-full"
              ></motion.div>
              {!isCollapsed && <span className="text-xs text-green-400 font-semibold">ALL SYSTEMS GO</span>}
            </div>
          </div>
        </div>

        {/* Navigation */}
        <div className="flex-1 overflow-y-auto overflow-x-hidden p-4">
          <div className="space-y-1">
            {mainModules.map((module) => {
              if(isCollapsed) {
                return (
                  <Tooltip key={module.id}>
                    <TooltipTrigger asChild>
                      <motion.div
                        whileHover={{ scale: 1.05 }}
                        whileTap={{ scale: 0.95 }}
                        transition={{ type: "spring", stiffness: 400, damping: 25 }}
                      >
                        <Button
                          variant={activeModule === module.id ? "default" : "ghost"}
                          onClick={() => onModuleChange(module.id)}
                          className={`w-full justify-center h-auto p-3 transition-all duration-200 ${
                            activeModule === module.id 
                              ? "bg-gradient-cyber text-white shadow-lg glow-cyan" 
                              : "text-gray-300 hover:text-cyan-400 hover:bg-gray-800/50"
                          }`}
                        >
                          <module.icon className="w-5 h-5" />
                        </Button>
                      </motion.div>
                    </TooltipTrigger>
                    <TooltipContent side="right" className="bg-gray-800 text-white border-cyan-500/30 shadow-xl">
                      <p>{module.name}</p>
                    </TooltipContent>
                  </Tooltip>
                );
              }
              return (
                <motion.div
                  key={module.id}
                  whileHover={{ scale: 1.02, x: 2 }}
                  whileTap={{ scale: 0.98 }}
                  transition={{ type: "spring", stiffness: 400, damping: 25 }}
                >
                  <Button
                    variant={activeModule === module.id ? "default" : "ghost"}
                    onClick={() => onModuleChange(module.id)}
                    className={`w-full justify-start text-left h-auto p-3 transition-all duration-200 ${
                      activeModule === module.id 
                        ? "bg-gradient-cyber text-white font-semibold shadow-lg glow-cyan" 
                        : "text-gray-300 hover:text-cyan-400 hover:bg-gray-800/50"
                    }`}
                  >
                    <div className="flex items-center space-x-3">
                      <module.icon className="w-4 h-4" />
                      <span className="text-sm">{module.name}</span>
                    </div>
                    {module.count && (
                      <Badge 
                        variant="outline" 
                        className={`text-xs ml-auto transition-colors duration-200 ${
                          activeModule === module.id 
                            ? "border-cyan-200 text-cyan-100" 
                            : "border-gray-600 text-gray-400"
                        }`}
                      >
                        {module.count}
                      </Badge>
                    )}
                  </Button>
                </motion.div>
              );
            })}

            <div className="pt-4">
               <CollapsibleAdminMenu 
                  title="Developer"
                  icon={Settings}
                  subModules={developerModules}
                  activeModule={activeModule}
                  onModuleChange={onModuleChange}
                  isCollapsed={isCollapsed}
               />
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-cyan-500/20">
          <motion.div
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            transition={{ type: "spring", stiffness: 400, damping: 25 }}
          >
            <Button 
              variant="ghost" 
              onClick={onToggle} 
              className="w-full text-gray-400 hover:text-cyan-400 hover:bg-gray-800/50 justify-center transition-all duration-200"
            >
              {isCollapsed ? <ChevronsRight size={18} /> : <ChevronsLeft size={18} />}
            </Button>
          </motion.div>
          {!isCollapsed && (
            <AnimatePresence>
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: 10 }}
                transition={{ delay: 0.2, duration: 0.2 }}
                className="text-center text-xs text-gray-500 mt-2"
              >
                <p>Disruptors Media</p>
                <p>Admin Panel v2.1</p>
              </motion.div>
            </AnimatePresence>
          )}
        </div>
      </motion.div>
    </TooltipProvider>
  );
}
