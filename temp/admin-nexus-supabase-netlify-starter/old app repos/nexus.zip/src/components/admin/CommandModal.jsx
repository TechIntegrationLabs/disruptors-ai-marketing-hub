import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Command, Terminal, Zap } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

const commands = [
  { cmd: 'admin', desc: 'Main control panel', icon: Command },
  { cmd: 'figma', desc: 'Design system management', icon: Zap },
  { cmd: 'dev', desc: 'Development tools', icon: Terminal },
  { cmd: 'tools', desc: 'Utility functions', icon: Command },
  { cmd: 'scripts', desc: 'Automation scripts', icon: Terminal },
  { cmd: 'matrix', desc: 'System overview matrix', icon: Zap },
  { cmd: 'control', desc: 'Advanced controls', icon: Command },
  { cmd: 'sys', desc: 'System administration', icon: Terminal }
];

export default function CommandModal({ isOpen, onClose, onCommand }) {
  const [input, setInput] = useState('');
  const [filteredCommands, setFilteredCommands] = useState(commands);

  useEffect(() => {
    if (input) {
      setFilteredCommands(
        commands.filter(cmd => 
          cmd.cmd.toLowerCase().includes(input.toLowerCase()) ||
          cmd.desc.toLowerCase().includes(input.toLowerCase())
        )
      );
    } else {
      setFilteredCommands(commands);
    }
  }, [input]);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (input.trim()) {
      onCommand(input.trim().toLowerCase());
      setInput('');
      onClose();
    }
  };

  const handleCommandClick = (command) => {
    onCommand(command);
    setInput('');
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="bg-gray-900 border-cyan-500/30 max-w-2xl">
        <div className="space-y-6">
          {/* Header */}
          <div className="text-center space-y-2">
            <div className="flex items-center justify-center space-x-2">
              <div className="w-8 h-8 bg-gradient-to-r from-cyan-500 to-blue-500 rounded-full flex items-center justify-center">
                <Terminal className="w-4 h-4 text-white" />
              </div>
              <h2 className="text-xl font-bold text-white">SECRET ADMIN ACCESS</h2>
            </div>
            <p className="text-gray-400 text-sm">Enter command to access admin functions</p>
          </div>

          {/* Command Input */}
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="relative">
              <Terminal className="absolute left-3 top-1/2 transform -translate-y-1/2 text-cyan-500 w-4 h-4" />
              <Input
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Type command..."
                className="pl-10 bg-gray-800 border-gray-600 text-white placeholder-gray-500 focus:border-cyan-500"
                autoFocus
              />
            </div>
          </form>

          {/* Command Suggestions */}
          <div className="space-y-3 max-h-96 overflow-y-auto">
            <h3 className="text-sm font-semibold text-gray-300 uppercase tracking-wider">Available Commands</h3>
            <AnimatePresence>
              {filteredCommands.map((command, index) => (
                <motion.div
                  key={command.cmd}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  transition={{ delay: index * 0.05 }}
                  onClick={() => handleCommandClick(command.cmd)}
                  className="flex items-center space-x-3 p-3 bg-gray-800 rounded-lg hover:bg-gray-700 cursor-pointer border border-gray-700 hover:border-cyan-500/50 transition-all duration-200"
                >
                  <command.icon className="w-5 h-5 text-cyan-500" />
                  <div className="flex-1">
                    <Badge variant="outline" className="text-xs text-cyan-400 border-cyan-500/50 mb-1">
                      {command.cmd}
                    </Badge>
                    <p className="text-sm text-gray-300">{command.desc}</p>
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>

          {/* Footer */}
          <div className="text-center">
            <p className="text-xs text-gray-500">
              Press Enter to execute • ESC to close
            </p>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}