import React, { useState, useEffect } from 'react';
import ModuleLayout from './shared/ModuleLayout';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Repository } from "@/api/entities";
import { GitBranch, User, Clock, CheckCircle, XCircle, MoreHorizontal, Upload, GitCommit, Activity } from "lucide-react";
import EmptyState from './shared/EmptyState';

const repoAdminTabs = [
  { id: 'overview', name: 'Overview' },
  { id: 'activity', name: 'Activity' },
  { id: 'settings', name: 'Settings' },
  { id: 'metrics', name: 'Metrics' },
  { id: 'history', name: 'History' },
  { id: 'access', name: 'Access' },
];

const mockBranches = [
    { name: 'main', author: 'base44-ai', commit: 'fix: improve caching logic', checks: 'passing' },
    { name: 'develop', author: 'dev-team', commit: 'feat: add new user profile page', checks: 'passing' },
    { name: 'feat/admin-v2', author: 'base44-ai', commit: 'wip: implement shared module layout', checks: 'running' },
    { name: 'fix/login-bug', author: 'dev-team', commit: 'fix: resolve authentication issue', checks: 'failing' },
];

const OverviewTab = ({ repo }) => (
    <div className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card className="bg-gray-800 border-gray-700">
                <CardHeader><CardTitle className="text-sm font-medium text-gray-400">Current Branch</CardTitle></CardHeader>
                <CardContent><p className="text-xl font-bold text-white flex items-center gap-2"><GitBranch size={20}/>{repo.active_branch}</p></CardContent>
            </Card>
            <Card className="bg-gray-800 border-gray-700">
                <CardHeader><CardTitle className="text-sm font-medium text-gray-400">Last Deploy</CardTitle></CardHeader>
                <CardContent><p className="text-xl font-bold text-white flex items-center gap-2"><Clock size={20}/>2h ago</p></CardContent>
            </Card>
            <Card className="bg-gray-800 border-gray-700">
                <CardHeader><CardTitle className="text-sm font-medium text-gray-400">CI Status</CardTitle></CardHeader>
                <CardContent><p className="text-xl font-bold text-green-400 flex items-center gap-2"><CheckCircle size={20}/> Passing</p></CardContent>
            </Card>
        </div>
        <Card className="bg-gray-800 border-gray-700">
            <CardHeader><CardTitle className="text-white">Branches</CardTitle></CardHeader>
            <CardContent>
                <Table>
                    <TableHeader>
                        <TableRow className="border-gray-700 hover:bg-gray-800">
                            <TableHead className="text-white">Branch</TableHead>
                            <TableHead className="text-white">Last Commit</TableHead>
                            <TableHead className="text-white">Checks</TableHead>
                            <TableHead className="text-right"></TableHead>
                        </TableRow>
                    </TableHeader>
                    <TableBody>
                        {mockBranches.map(branch => (
                            <TableRow key={branch.name} className="border-gray-700">
                                <TableCell className="font-medium text-white flex items-center gap-2">
                                    <GitBranch size={16} /> {branch.name}
                                </TableCell>
                                <TableCell>
                                    <p className="text-gray-300 truncate w-64">{branch.commit}</p>
                                    <p className="text-gray-500 text-xs flex items-center gap-1"><User size={12}/>{branch.author}</p>
                                </TableCell>
                                <TableCell>
                                    <Badge variant="outline" className={`flex items-center gap-1 ${
                                        branch.checks === 'passing' ? 'text-green-400 border-green-500/50' : 
                                        branch.checks === 'failing' ? 'text-red-400 border-red-500/50' : 'text-yellow-400 border-yellow-500/50'
                                    }`}>
                                        {branch.checks === 'passing' && <CheckCircle size={14} />}
                                        {branch.checks === 'failing' && <XCircle size={14} />}
                                        {branch.checks === 'running' && <MoreHorizontal size={14} className="animate-pulse"/>}
                                        {branch.checks}
                                    </Badge>
                                </TableCell>
                                <TableCell className="text-right">
                                    <Button disabled={branch.checks !== 'passing'} className="bg-cyan-600 hover:bg-cyan-700 h-8">Deploy</Button>
                                </TableCell>
                            </TableRow>
                        ))}
                    </TableBody>
                </Table>
            </CardContent>
        </Card>
    </div>
);

export default function RepoAdmin() {
    const [repo, setRepo] = useState(null);
    const [activeTab, setActiveTab] = useState('overview');

    useEffect(() => {
        const loadRepo = async () => {
            const repos = await Repository.list();
            if (repos.length > 0) {
                setRepo(repos[0]); 
            }
        };
        loadRepo();
    }, []);
    
    if (!repo) return <div className="text-white">Loading repository data...</div>;

    const renderContent = () => {
        switch (activeTab) {
            case 'overview':
                return <OverviewTab repo={repo} />;
            default:
                return <EmptyState icon={Activity} title={`${activeTab.charAt(0).toUpperCase() + activeTab.slice(1)} Tab`} description="This section is under construction." />;
        }
    };

    return (
        <ModuleLayout
            title={repo.name}
            status={repo.status}
            statusColor={repo.status === 'healthy' ? 'bg-green-500' : 'bg-yellow-500'}
            lastUpdated={new Date(repo.last_commit_date).toLocaleDateString()}
            primaryAction={<Button className="bg-cyan-600 hover:bg-cyan-700"><Upload size={16} className="mr-2"/> Deploy Main</Button>}
            tabs={repoAdminTabs}
            activeTab={activeTab}
            onTabChange={setActiveTab}
        >
            {renderContent()}
        </ModuleLayout>
    );
}