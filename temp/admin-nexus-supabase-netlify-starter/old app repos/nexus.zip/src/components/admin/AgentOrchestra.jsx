import React, { useState, useEffect } from 'react';
import ModuleLayout from './shared/ModuleLayout';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Input } from "@/components/ui/input";
import { Bot, Plus, Play, Pause, CheckCircle, Clock, AlertCircle, Settings, Activity, Zap } from 'lucide-react';
import EmptyState from './shared/EmptyState';

const orchestraTabs = [
  { id: 'overview', name: 'Overview' },
  { id: 'builder', name: 'Builder' },
  { id: 'runs', name: 'Runs' },
  { id: 'settings', name: 'Settings' },
  { id: 'metrics', name: 'Metrics' },
  { id: 'history', name: 'History' },
  { id: 'access', name: 'Access' },
];

const mockWorkflows = [
  {
    id: 'wf_001',
    name: 'Content Generation Pipeline',
    status: 'running',
    lastRun: '5 minutes ago',
    successRate: 94.2,
    totalRuns: 847,
    description: 'Automated content creation, SEO optimization, and publishing workflow'
  },
  {
    id: 'wf_002', 
    name: 'Customer Support Triage',
    status: 'idle',
    lastRun: '2 hours ago',
    successRate: 98.7,
    totalRuns: 1234,
    description: 'Automatically categorize and route support tickets to appropriate agents'
  },
  {
    id: 'wf_003',
    name: 'Data Analysis & Reporting',
    status: 'error',
    lastRun: '1 day ago',
    successRate: 87.3,
    totalRuns: 456,
    description: 'Weekly data processing and automated report generation'
  }
];

const mockActiveRuns = [
  {
    id: 'run_123',
    workflow: 'Content Generation Pipeline',
    status: 'processing',
    progress: 67,
    startedAt: '2 minutes ago',
    estimatedCompletion: '3 minutes'
  },
  {
    id: 'run_124',
    workflow: 'Customer Support Triage',
    status: 'completed',
    progress: 100,
    startedAt: '15 minutes ago',
    estimatedCompletion: 'Completed'
  }
];

const OverviewTab = () => (
  <div className="space-y-6">
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      <Card className="bg-gray-800 border-gray-700">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium text-gray-400">Active Workflows</CardTitle>
          <Bot className="h-4 w-4 text-cyan-400" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold text-white">10</div>
          <p className="text-xs text-green-400">2 running now</p>
        </CardContent>
      </Card>

      <Card className="bg-gray-800 border-gray-700">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium text-gray-400">Success Rate</CardTitle>
          <CheckCircle className="h-4 w-4 text-green-400" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold text-white">94.8%</div>
          <p className="text-xs text-green-400">+2.1% vs last week</p>
        </CardContent>
      </Card>

      <Card className="bg-gray-800 border-gray-700">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium text-gray-400">Total Runs</CardTitle>
          <Activity className="h-4 w-4 text-purple-400" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold text-white">2,537</div>
          <p className="text-xs text-gray-400">This month</p>
        </CardContent>
      </Card>

      <Card className="bg-gray-800 border-gray-700">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium text-gray-400">Avg Duration</CardTitle>
          <Clock className="h-4 w-4 text-yellow-400" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold text-white">4.2m</div>
          <p className="text-xs text-green-400">-18% vs last week</p>
        </CardContent>
      </Card>
    </div>

    <Card className="bg-gray-800 border-gray-700">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="text-white">Workflows</CardTitle>
          <Button className="bg-cyan-600 hover:bg-cyan-700">
            <Plus size={16} className="mr-2" />
            New Workflow
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <Table>
          <TableHeader>
            <TableRow className="border-gray-700">
              <TableHead className="text-white">Name</TableHead>
              <TableHead className="text-white">Status</TableHead>
              <TableHead className="text-white">Success Rate</TableHead>
              <TableHead className="text-white">Total Runs</TableHead>
              <TableHead className="text-white">Last Run</TableHead>
              <TableHead></TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {mockWorkflows.map(workflow => (
              <TableRow key={workflow.id} className="border-gray-700">
                <TableCell>
                  <div>
                    <div className="font-medium text-white">{workflow.name}</div>
                    <div className="text-xs text-gray-400 mt-1">{workflow.description}</div>
                  </div>
                </TableCell>
                <TableCell>
                  <Badge className={`${
                    workflow.status === 'running' ? 'bg-green-500/20 text-green-400' :
                    workflow.status === 'idle' ? 'bg-gray-500/20 text-gray-400' :
                    'bg-red-500/20 text-red-400'
                  }`}>
                    {workflow.status === 'running' && <Activity size={12} className="mr-1 animate-pulse" />}
                    {workflow.status === 'idle' && <Pause size={12} className="mr-1" />}
                    {workflow.status === 'error' && <AlertCircle size={12} className="mr-1" />}
                    {workflow.status}
                  </Badge>
                </TableCell>
                <TableCell className="text-gray-300">{workflow.successRate}%</TableCell>
                <TableCell className="text-gray-300">{workflow.totalRuns}</TableCell>
                <TableCell className="text-gray-400">{workflow.lastRun}</TableCell>
                <TableCell className="text-right">
                  <div className="flex items-center gap-1">
                    <Button size="sm" variant="ghost" className="text-gray-400 hover:text-white">
                      <Play size={14} />
                    </Button>
                    <Button size="sm" variant="ghost" className="text-gray-400 hover:text-white">
                      <Settings size={14} />
                    </Button>
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  </div>
);

const RunsTab = () => (
  <div className="space-y-6">
    <Card className="bg-gray-800 border-gray-700">
      <CardHeader>
        <CardTitle className="text-white">Active Runs</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {mockActiveRuns.map(run => (
            <div key={run.id} className="p-4 bg-gray-700 rounded-lg">
              <div className="flex items-center justify-between mb-3">
                <div>
                  <h4 className="font-medium text-white">{run.workflow}</h4>
                  <p className="text-sm text-gray-400">Run ID: {run.id}</p>
                </div>
                <Badge className={`${
                  run.status === 'processing' ? 'bg-yellow-500/20 text-yellow-400' :
                  'bg-green-500/20 text-green-400'
                }`}>
                  {run.status}
                </Badge>
              </div>
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-gray-400">Progress</span>
                  <span className="text-white">{run.progress}%</span>
                </div>
                <div className="w-full bg-gray-600 rounded-full h-2">
                  <div 
                    className="bg-cyan-600 h-2 rounded-full transition-all duration-300"
                    style={{ width: `${run.progress}%` }}
                  ></div>
                </div>
                <div className="flex justify-between text-xs text-gray-400">
                  <span>Started: {run.startedAt}</span>
                  <span>ETA: {run.estimatedCompletion}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  </div>
);

const BuilderTab = () => (
  <div className="space-y-6">
    <Card className="bg-gray-800 border-gray-700">
      <CardHeader>
        <CardTitle className="text-white">Workflow Builder</CardTitle>
        <p className="text-gray-400 text-sm">Drag and drop components to build your automation workflow</p>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          <div className="space-y-4">
            <h4 className="font-medium text-white">Components</h4>
            <div className="space-y-2">
              {[
                'Trigger: Webhook',
                'Trigger: Schedule', 
                'Action: AI Generate',
                'Action: Send Email',
                'Action: Update Database',
                'Condition: If/Then',
                'Transformer: Format Data'
              ].map((component, index) => (
                <div key={index} className="p-3 bg-gray-700 rounded-lg border border-gray-600 cursor-grab hover:border-cyan-500 transition-colors">
                  <span className="text-sm text-gray-300">{component}</span>
                </div>
              ))}
            </div>
          </div>
          
          <div className="lg:col-span-3">
            <div className="h-96 bg-gray-700 rounded-lg border-2 border-dashed border-gray-600 flex items-center justify-center">
              <div className="text-center">
                <Bot className="w-12 h-12 text-gray-500 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-white mb-2">Build Your Workflow</h3>
                <p className="text-gray-400">Drag components from the left to create your automation</p>
                <Button className="mt-4 bg-cyan-600 hover:bg-cyan-700">
                  Start with Template
                </Button>
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  </div>
);

export default function AgentOrchestra() {
  const [activeTab, setActiveTab] = useState('overview');

  const renderContent = () => {
    switch (activeTab) {
      case 'overview':
        return <OverviewTab />;
      case 'runs':
        return <RunsTab />;
      case 'builder':
        return <BuilderTab />;
      default:
        return <EmptyState icon={Bot} title={`${activeTab.charAt(0).toUpperCase() + activeTab.slice(1)} Tab`} description="This section is under construction." />;
    }
  };

  return (
    <ModuleLayout
      title="Agent Orchestra"
      status="2 Workflows Running"
      statusColor="bg-green-500"
      lastUpdated="Live"
      primaryAction={
        <div className="flex gap-2">
          <Button variant="outline" size="sm" className="text-gray-300 border-gray-600">
            <Settings size={14} className="mr-2" />
            Settings
          </Button>
          <Button className="bg-cyan-600 hover:bg-cyan-700">
            <Plus size={14} className="mr-2" />
            New Workflow
          </Button>
        </div>
      }
      tabs={orchestraTabs}
      activeTab={activeTab}
      onTabChange={setActiveTab}
    >
      {renderContent()}
    </ModuleLayout>
  );
}