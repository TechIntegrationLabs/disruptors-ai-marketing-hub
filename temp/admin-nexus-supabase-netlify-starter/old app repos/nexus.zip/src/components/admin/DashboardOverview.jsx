
import React, { useState, useEffect } from 'react';
import ModuleLayout from './shared/ModuleLayout';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { TelemetryEvent } from "@/api/entities";
import { ResponsiveContainer, LineChart, Line, XAxis, YAxis, Tooltip, PieChart, Pie, Cell } from 'recharts';
import { Users, Eye, MousePointerClick, AlertCircle, TrendingUp, BarChart3, Download, Zap, FilePlus, Brain, MoreHorizontal, Globe } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { motion } from 'framer-motion';

import AdvancedDashboard from '../shared/charts/AdvancedDashboard';
import InteractiveMetricCard from '../shared/charts/InteractiveMetricCard';

const COLORS = ['#00D4FF', '#3B82F6', '#10B981', '#A78BFA', '#F97316', '#EF4444']; // Updated for cyan/blue/green theme

const dashboardTabs = [
  { id: 'overview', name: 'Overview' },
  { id: 'activity', name: 'Activity Feed' },
  { id: 'actions', name: 'Quick Actions' },
];

const CustomTooltip = ({ active, payload, label }) => {
    if (active && payload && payload.length) {
        return (
            <motion.div
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                className="p-3 bg-gray-800 border border-cyan-500/30 rounded-lg text-white shadow-xl backdrop-blur-sm"
            >
                <p className="font-medium">{`${label}: ${payload[0].value.toLocaleString()}`}</p>
            </motion.div>
        );
    }
    return null;
};

const OverviewTab = ({ stats, chartData, countryData }) => {
  const dashboardMetrics = [
    {
      id: 'views',
      title: 'Page Views',
      value: stats.views,
      change: '+12.5%',
      trend: 'up',
      icon: Eye,
      color: 'cyan',
      sparklineData: chartData.map(d => ({ value: d.views }))
    },
    {
      id: 'visitors', 
      title: 'Unique Visitors',
      value: stats.visitors,
      change: '+8.2%',
      trend: 'up',
      icon: Users,
      color: 'blue',
      sparklineData: chartData.map(d => ({ value: d.views * 0.7 }))
    },
    {
      id: 'conversions',
      title: 'Conversions', 
      value: stats.conversions,
      change: '+23.1%',
      trend: 'up',
      icon: MousePointerClick,
      color: 'green',
      sparklineData: chartData.map(d => ({ value: d.views * 0.1 }))
    },
    {
      id: 'errors',
      title: 'Errors',
      value: stats.errors,
      change: '-15.3%', 
      trend: 'down',
      icon: AlertCircle,
      color: 'red',
      sparklineData: chartData.map(d => ({ value: Math.random() * 10 }))
    }
  ];

  const enhancedChartData = chartData.map(item => ({
    ...item,
    users: Math.floor(item.views * 0.7),
    conversions: Math.floor(item.views * 0.05)
  }));

  return (
    <AdvancedDashboard 
      metrics={dashboardMetrics}
      chartData={enhancedChartData}
    />
  );
};

const ActivityFeedTab = () => {
    const mockActivity = [
        { id: 1, user: 'base44-ai', action: 'published a new page:', target: 'About Us', time: '2m ago', type: 'content' },
        { id: 2, user: 'base44-ai', action: 'ran AI module:', target: 'Content Ideation', time: '15m ago', type: 'ai' },
        { id: 3, user: 'dev-user', action: 'pushed a commit to', target: 'main', time: '45m ago', type: 'system' },
        { id: 4, user: 'base44-ai', action: 'updated Brand DNA:', target: 'Voice & Tone', time: '1h ago', type: 'brand' },
        { id: 5, user: 'base44-ai', action: 'archived a blog post:', target: 'Old Company News', time: '3h ago', type: 'content' },
    ];
    return (
        <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
        >
            <Card className="bg-gray-800 border-cyan-500/30">
                <CardHeader><CardTitle className="text-white">Recent Activity</CardTitle></CardHeader>
                <CardContent>
                    <div className="space-y-4">
                        {mockActivity.map((item, index) => (
                            <motion.div
                                key={item.id}
                                initial={{ opacity: 0, x: -20 }}
                                animate={{ opacity: 1, x: 0 }}
                                transition={{ delay: index * 0.1 + 0.2 }}
                                className="flex items-center justify-between text-sm"
                            >
                                <div className="flex items-center gap-3">
                                <div className="p-2 bg-gray-700 rounded-full"><Users size={14} className="text-cyan-400" /></div>
                                <div>
                                    <span className="font-semibold text-white">{item.user}</span>
                                    <span className="text-gray-400"> {item.action} </span>
                                    <span className="font-semibold text-cyan-400">{item.target}</span>
                                </div>
                                </div>
                                <span className="text-gray-500">{item.time}</span>
                            </motion.div>
                        ))}
                    </div>
                </CardContent>
            </Card>
        </motion.div>
    );
};

const QuickActionsTab = () => (
    <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6"
    >
        <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.1 }}
            whileHover={{ scale: 1.05, y: -5, boxShadow: '0 10px 15px rgba(0, 212, 255, 0.2)' }}
            whileTap={{ scale: 0.95 }}
        >
            <Card className="bg-gray-800 border-gray-700 hover:border-cyan-500/50 transition-colors cursor-pointer h-full">
                <CardContent className="p-6 flex flex-col items-center justify-center text-center h-full">
                    <FilePlus className="w-10 h-10 text-cyan-400 mb-3" />
                    <h3 className="font-semibold text-white">New Page/Post</h3>
                    <p className="text-xs text-gray-400 mt-1">Create new content for your website.</p>
                </CardContent>
            </Card>
        </motion.div>
        <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.2 }}
            whileHover={{ scale: 1.05, y: -5, boxShadow: '0 10px 15px rgba(0, 212, 255, 0.2)' }}
            whileTap={{ scale: 0.95 }}
        >
            <Card className="bg-gray-800 border-gray-700 hover:border-cyan-500/50 transition-colors cursor-pointer h-full">
                <CardContent className="p-6 flex flex-col items-center justify-center text-center h-full">
                    <Zap className="w-10 h-10 text-cyan-400 mb-3" />
                    <h3 className="font-semibold text-white">Generate Ideas</h3>
                    <p className="text-xs text-gray-400 mt-1">Use AI to find new content topics.</p>
                </CardContent>
            </Card>
        </motion.div>
        <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.3 }}
            whileHover={{ scale: 1.05, y: -5, boxShadow: '0 10px 15px rgba(0, 212, 255, 0.2)' }}
            whileTap={{ scale: 0.95 }}
        >
            <Card className="bg-gray-800 border-gray-700 hover:border-cyan-500/50 transition-colors cursor-pointer h-full">
                <CardContent className="p-6 flex flex-col items-center justify-center text-center h-full">
                    <Brain className="w-10 h-10 text-cyan-400 mb-3" />
                    <h3 className="font-semibold text-white">Update Business Brain</h3>
                    <p className="text-xs text-gray-400 mt-1">Add new knowledge about your company.</p>
                </CardContent>
            </Card>
        </motion.div>
        <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.4 }}
            whileHover={{ scale: 1.05, y: -5, boxShadow: '0 10px 15px rgba(0, 212, 255, 0.2)' }}
            whileTap={{ scale: 0.95 }}
        >
            <Card className="bg-gray-800 border-gray-700 hover:border-cyan-500/50 transition-colors cursor-pointer h-full">
                <CardContent className="p-6 flex flex-col items-center justify-center text-center h-full">
                    <BarChart3 className="w-10 h-10 text-cyan-400 mb-3" />
                    <h3 className="font-semibold text-white">View Full Report</h3>
                    <p className="text-xs text-gray-400 mt-1">Dive deep into your analytics.</p>
                </CardContent>
            </Card>
        </motion.div>
    </motion.div>
);

export default function DashboardOverview() {
  const [stats, setStats] = useState({ views: 0, visitors: 0, conversions: 0, errors: 0 });
  const [chartData, setChartData] = useState([]);
  const [countryData, setCountryData] = useState([]);
  const [activeTab, setActiveTab] = useState('overview');

  useEffect(() => {
      loadTelemetryData();
  }, []);

  const loadTelemetryData = async () => {
      const data = await TelemetryEvent.list('-created_date');
      
      const newStats = data.reduce((acc, event) => {
          if(event.event_type === 'page_view') acc.views++;
          if(event.event_type === 'unique_visitor') acc.visitors++;
          if(event.event_type === 'conversion') acc.conversions++;
          if(event.event_type === 'error') acc.errors++;
          return acc;
      }, { views: 0, visitors: 0, conversions: 0, errors: 0 });

      // Mock data for empty results
      if (data.length === 0) {
        newStats.views = 47283;
        newStats.visitors = 12847;
        newStats.conversions = 342;
        newStats.errors = 23;
      }
      setStats(newStats);

      const dailyData = [
        { date: 'Jan 1', views: 1200 }, { date: 'Jan 2', views: 1890 }, { date: 'Jan 3', views: 2100 },
        { date: 'Jan 4', views: 1780 }, { date: 'Jan 5', views: 2340 }, { date: 'Jan 6', views: 2890 },
        { date: 'Jan 7', views: 3200 },
      ];
      setChartData(dailyData);

      const mockCountryData = [
        { name: 'United States', value: 35 }, { name: 'United Kingdom', value: 18 }, { name: 'Canada', value: 15 },
        { name: 'Germany', value: 12 }, { name: 'Australia', value: 10 }, { name: 'Other', value: 10 },
      ];
      setCountryData(mockCountryData);
  };

  const renderContent = () => {
    switch (activeTab) {
      case 'overview':
        return <OverviewTab stats={stats} chartData={chartData} countryData={countryData} />;
      case 'activity':
        return <ActivityFeedTab />;
      case 'actions':
        return <QuickActionsTab />;
      default:
        return null;
    }
  };

  return (
    <ModuleLayout
      title="Dashboard"
      status="Live"
      statusColor="bg-green-500"
      lastUpdated="just now"
      primaryAction={
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="outline" size="sm" className="text-gray-300 border-gray-600 hover:border-cyan-500/50 hover:text-cyan-400 transition-all duration-200">
              <MoreHorizontal size={14} />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent className="bg-gray-800 border-cyan-500/30 shadow-xl">
            <DropdownMenuItem className="text-gray-300 focus:bg-gray-700 focus:text-cyan-400 transition-colors duration-200">
              <Download size={14} className="mr-2" />
              Export Report
            </DropdownMenuItem>
            <DropdownMenuItem className="text-gray-300 focus:bg-gray-700 focus:text-cyan-400 transition-colors duration-200">
              <BarChart3 size={14} className="mr-2" />
              Full Analytics
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      }
      tabs={dashboardTabs}
      activeTab={activeTab}
      onTabChange={setActiveTab}
    >
      {renderContent()}
    </ModuleLayout>
  );
}
