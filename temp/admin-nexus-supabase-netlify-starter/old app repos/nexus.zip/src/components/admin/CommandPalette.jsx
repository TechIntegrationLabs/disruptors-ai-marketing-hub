
import React, { useState, useEffect, useRef } from 'react';
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { motion, AnimatePresence } from "framer-motion";
import { 
  Command, 
  Search, 
  Navigation, 
  Zap, 
  Plus,
  Settings,
  BarChart3,
  FileText,
  Brain,
  Palette,
  Bot,
  Network
} from "lucide-react";

const commandCategories = {
  navigation: {
    icon: Navigation,
    color: 'text-amber-400 border-amber-400/30 bg-amber-400/10'
  },
  actions: {
    icon: Zap,
    color: 'text-blue-400 border-blue-400/30 bg-blue-400/10'
  },
  create: {
    icon: Plus,
    color: 'text-green-400 border-green-400/30 bg-green-400/10'
  },
  settings: {
    icon: Settings,
    color: 'text-orange-400 border-orange-400/30 bg-orange-400/10'
  }
};

const moduleIcons = {
  'Dashboard': BarChart3,
  'WebsiteOS CMS': FileText,
  'Business Brain': Brain,
  'Brand DNA': Palette,
  'AI Modules': Bot,
  'Agent Orchestra': Bot,
  'MCP Servers': Network,
  'Telemetry': BarChart3,
  'Integrations Hub': Zap
};

export default function CommandPalette({ isOpen, onClose, commands = [], onCommandSelect }) {
  const [input, setInput] = useState('');
  const [filteredCommands, setFilteredCommands] = useState([]);
  const [selectedIndex, setSelectedIndex] = useState(0);
  const [showCategories, setShowCategories] = useState(true);
  const inputRef = useRef(null);

  // Enhanced commands with navigation and contextual actions
  const enhancedCommands = React.useMemo(() => {
    const navigationCommands = [
      { verb: 'Go to Dashboard', module: 'Dashboard', category: 'navigation', action: 'navigate' },
      { verb: 'Go to CMS', module: 'WebsiteOS CMS', category: 'navigation', action: 'navigate' },
      { verb: 'Go to Business Brain', module: 'Business Brain', category: 'navigation', action: 'navigate' },
      { verb: 'Go to Brand DNA', module: 'Brand DNA', category: 'navigation', action: 'navigate' },
      { verb: 'Go to AI Modules', module: 'AI Modules', category: 'navigation', action: 'navigate' },
      { verb: 'Go to Analytics', module: 'Telemetry', category: 'navigation', action: 'navigate' },
      { verb: 'Go to Integrations', module: 'Integrations Hub', category: 'navigation', action: 'navigate' }
    ];

    const createCommands = [
      { verb: 'Create new page', module: 'WebsiteOS CMS', category: 'create', action: 'create_page' },
      { verb: 'Create blog post', module: 'WebsiteOS CMS', category: 'create', action: 'create_post' },
      { verb: 'Generate content ideas', module: 'AI Modules', category: 'create', action: 'generate_ideas' },
      { verb: 'Create author persona', module: 'AI Modules', category: 'create', action: 'create_persona' },
      { verb: 'Add brain fact', module: 'Business Brain', category: 'create', action: 'add_fact' },
      { verb: 'Create workflow', module: 'Agent Orchestra', category: 'create', action: 'create_workflow' }
    ];

    const actionCommands = [
      { verb: 'Optimize images', module: 'AI Modules', category: 'actions', action: 'optimize_images' },
      { verb: 'Generate schema', module: 'AI Modules', category: 'actions', action: 'generate_schema' },
      { verb: 'Export analytics', module: 'Telemetry', category: 'actions', action: 'export_data' },
      { verb: 'Deploy to production', module: 'Repo Admin', category: 'actions', action: 'deploy' },
      { verb: 'Refresh business brain', module: 'Business Brain', category: 'actions', action: 'refresh_brain' }
    ];

    const settingsCommands = [
      { verb: 'Update brand colors', module: 'Brand DNA', category: 'settings', action: 'update_colors' },
      { verb: 'Configure integrations', module: 'Integrations Hub', category: 'settings', action: 'configure' },
      { verb: 'Manage API keys', module: 'MCP Servers', category: 'settings', action: 'manage_keys' }
    ];

    return [...navigationCommands, ...createCommands, ...actionCommands, ...settingsCommands, ...commands];
  }, [commands]);

  useEffect(() => {
    if (isOpen) {
      setTimeout(() => inputRef.current?.focus(), 100);
      setFilteredCommands(enhancedCommands);
      setInput('');
      setSelectedIndex(0);
      setShowCategories(true);
    }
  }, [enhancedCommands, isOpen]);
  
  useEffect(() => {
    if (input.trim()) {
      const filtered = enhancedCommands.filter(cmd => 
        cmd.verb.toLowerCase().includes(input.toLowerCase()) ||
        cmd.module.toLowerCase().includes(input.toLowerCase())
      );
      setFilteredCommands(filtered);
      setShowCategories(false);
    } else {
      setFilteredCommands(enhancedCommands);
      setShowCategories(true);
    }
    setSelectedIndex(0);
  }, [input, enhancedCommands]);

  const handleKeyDown = (e) => {
    if (e.key === 'ArrowDown') {
      e.preventDefault();
      setSelectedIndex(prev => (prev + 1) % filteredCommands.length);
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      setSelectedIndex(prev => (prev - 1 + filteredCommands.length) % filteredCommands.length);
    } else if (e.key === 'Enter') {
      e.preventDefault();
      if (filteredCommands.length > 0) {
        handleCommandClick(filteredCommands[selectedIndex]);
      }
    }
  };

  const handleCommandClick = (command) => {
    if (command.action === 'navigate') {
      // Handle navigation
      const moduleMap = {
        'Dashboard': 'dashboard',
        'WebsiteOS CMS': 'website-os',
        'Business Brain': 'business-brain',
        'Brand DNA': 'brand-dna',
        'AI Modules': 'ai-modules',
        'Telemetry': 'telemetry',
        'Integrations Hub': 'integrations'
      };
      
      if (window.onModuleChange && moduleMap[command.module]) {
        window.onModuleChange(moduleMap[command.module]);
      }
    }
    
    onCommandSelect(command);
    onClose();
  };

  const groupedCommands = React.useMemo(() => {
    if (!showCategories) return { all: filteredCommands };
    
    return filteredCommands.reduce((groups, command) => {
      const category = command.category || 'actions';
      if (!groups[category]) groups[category] = [];
      groups[category].push(command);
      return groups;
    }, {});
  }, [filteredCommands, showCategories]);

  const renderCommand = (command, index, globalIndex) => {
    const ModuleIcon = moduleIcons[command.module] || Command;
    const categoryConfig = commandCategories[command.category] || commandCategories.actions;
    const CategoryIcon = categoryConfig.icon;
    
    return (
      <motion.div
        key={`${command.module}-${command.verb}-${index}`}
        initial={{ opacity: 0, x: -20 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ duration: 0.1, delay: index * 0.02 }}
        onClick={() => handleCommandClick(command)}
        className={`flex items-center justify-between p-3 rounded-lg cursor-pointer transition-all ${
          selectedIndex === globalIndex ? 'bg-gray-800 border border-amber-500/30' : 'hover:bg-gray-800/50'
        }`}
        onMouseEnter={() => setSelectedIndex(globalIndex)}
      >
        <div className="flex items-center gap-3">
          <div className="p-1.5 rounded-md bg-gray-700">
            <ModuleIcon size={14} className="text-gray-300" />
          </div>
          <div>
            <span className="text-white font-medium">{command.verb}</span>
            <div className="flex items-center gap-2 mt-1">
              <Badge variant="outline" className={`text-xs ${categoryConfig.color}`}>
                <CategoryIcon size={10} className="mr-1" />
                {command.category || 'action'}
              </Badge>
              <span className="text-xs text-gray-500">{command.module}</span>
            </div>
          </div>
        </div>
        {command.shortcut && (
          <kbd className="px-2 py-1 text-xs bg-gray-700 rounded border border-gray-600 text-gray-300">
            {command.shortcut}
          </kbd>
        )}
      </motion.div>
    );
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="bg-gray-900 border-amber-500/30 max-w-3xl p-0 max-h-[80vh] overflow-hidden">
        <div className="flex items-center border-b border-gray-700 p-4" onKeyDown={handleKeyDown}>
          <Command className="text-gray-400 mr-3" size={20} />
          <Input
            ref={inputRef}
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Search commands, navigate modules, or perform actions..."
            className="w-full bg-transparent border-none text-white placeholder-gray-500 focus:ring-0 text-lg p-0 h-auto"
          />
        </div>

        <div className="p-4 max-h-[60vh] overflow-y-auto">
          {!input && (
            <div className="flex gap-2 mb-4">
              <Button variant="ghost" size="sm" className="text-gray-400">
                <Navigation size={14} className="mr-1" />
                Navigate
              </Button>
              <Button variant="ghost" size="sm" className="text-gray-400">
                <Plus size={14} className="mr-1" />
                Create
              </Button>
              <Button variant="ghost" size="sm" className="text-gray-400">
                <Zap size={14} className="mr-1" />
                Actions
              </Button>
            </div>
          )}

          <div className="space-y-4">
            <AnimatePresence>
              {Object.entries(groupedCommands).map(([category, categoryCommands]) => {
                let globalIndex = 0;
                Object.entries(groupedCommands).forEach(([cat, cmds]) => {
                  if (cat === category) return;
                  globalIndex += cmds.length;
                });

                const CategoryIcon = commandCategories[category]?.icon || Settings;

                return (
                  <div key={category}>
                    {showCategories && (
                      <h3 className="text-sm font-medium text-gray-400 mb-2 capitalize flex items-center gap-2">
                        <CategoryIcon size={14} />
                        {category}
                      </h3>
                    )}
                    <div className="space-y-1">
                      {categoryCommands.map((command, index) => 
                        renderCommand(command, index, globalIndex + index)
                      )}
                    </div>
                  </div>
                );
              })}
            </AnimatePresence>
          </div>

          {filteredCommands.length === 0 && (
            <div className="text-center text-gray-500 py-8">
              <Search className="w-8 h-8 mx-auto mb-2 opacity-50" />
              <p>No commands found for "{input}"</p>
              <p className="text-sm mt-1">Try searching for modules, actions, or features</p>
            </div>
          )}
        </div>

        <div className="border-t border-gray-700 p-3 flex justify-between text-xs text-gray-500">
          <div className="flex items-center gap-4">
            <span className="flex items-center gap-1">
              <kbd className="px-1.5 py-0.5 bg-gray-800 rounded text-xs">↑↓</kbd>
              Navigate
            </span>
            <span className="flex items-center gap-1">
              <kbd className="px-1.5 py-0.5 bg-gray-800 rounded text-xs">↵</kbd>
              Execute
            </span>
            <span className="flex items-center gap-1">
              <kbd className="px-1.5 py-0.5 bg-gray-800 rounded text-xs">esc</kbd>
              Close
            </span>
          </div>
          <div className="text-amber-400">
            {filteredCommands.length} command{filteredCommands.length !== 1 ? 's' : ''}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
