import React, { useState, useEffect } from 'react';
import ModuleLayout from './shared/ModuleLayout';
import EmptyState from './shared/EmptyState';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { MCPServer } from "@/api/entities";
import { 
  Network, 
  CheckCircle, 
  XCircle, 
  AlertTriangle, 
  RefreshCw,
  Settings,
  Activity,
  Zap
} from "lucide-react";
import { motion } from "framer-motion";

const mcpServerTabs = [
  { id: 'overview', name: 'Overview' },
  { id: 'activity', name: 'Activity' },
  { id: 'settings', name: 'Settings' },
  { id: 'metrics', name: 'Metrics' },
  { id: 'history', name: 'History' },
  { id: 'access', name: 'Access' },
];

const serverTypeColors = {
//... existing serverTypeColors
};

const statusIcons = {
//... existing statusIcons
};

const statusColors = {
//... existing statusColors
};

const OverviewTab = () => {
  const [servers, setServers] = useState([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const loadServers = async () => {
      try {
        const data = await MCPServer.list('-uptime_percentage');
        setServers(data);
      } catch (error) {
        console.error('Error loading MCP servers:', error);
      } finally {
        setIsLoading(false);
      }
    };
    loadServers();
  }, []);

  const testServer = async (serverId) => {
    // In a real implementation, this would test server connectivity
    console.log(`Testing server ${serverId}`);
  };

  const restartServer = async (serverId) => {
    // In a real implementation, this would restart the server
    console.log(`Restarting server ${serverId}`);
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
        {servers.map((server, index) => {
          const StatusIcon = statusIcons[server.status];
          
          return (
            <motion.div
              key={server.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.05 }}
            >
              <Card className="bg-gray-800 border-gray-700 hover:border-cyan-500/50 transition-all duration-300">
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between">
                    <div className="flex items-center space-x-3">
                      <div className="p-2 bg-gray-700 rounded-lg">
                        <Network className="w-4 h-4 text-cyan-500" />
                      </div>
                      <div>
                        <CardTitle className="text-white text-sm">
                          {server.server_name}
                        </CardTitle>
                        <Badge 
                          className={`text-xs mt-1 ${serverTypeColors[server.server_type] || serverTypeColors.specialized}`}
                        >
                          {server.server_type.replace('_', ' ')}
                        </Badge>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      <StatusIcon className={`w-4 h-4 ${statusColors[server.status]}`} />
                      <div className="flex space-x-1">
                        <Button 
                          size="sm" 
                          variant="ghost" 
                          className="text-gray-400 hover:text-white p-1"
                          onClick={() => testServer(server.id)}
                        >
                          <Zap className="w-3 h-3" />
                        </Button>
                        <Button 
                          size="sm" 
                          variant="ghost" 
                          className="text-gray-400 hover:text-white p-1"
                          onClick={() => restartServer(server.id)}
                        >
                          <RefreshCw className="w-3 h-3" />
                        </Button>
                      </div>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="pt-0">
                  <p className="text-gray-400 text-xs mb-4 line-clamp-2">
                    {server.description}
                  </p>
                  
                  <div className="space-y-3">
                    <div className="flex items-center justify-between text-xs">
                      <span className="text-gray-400">Status</span>
                      <span className={`font-semibold uppercase ${statusColors[server.status]}`}>
                        {server.status}
                      </span>
                    </div>

                    <div className="grid grid-cols-2 gap-3 text-xs">
                      <div className="bg-gray-700 p-2 rounded">
                        <div className="text-gray-400">Uptime</div>
                        <div className="text-white font-semibold">
                          {(server.uptime_percentage || 0).toFixed(1)}%
                        </div>
                      </div>
                      <div className="bg-gray-700 p-2 rounded">
                        <div className="text-gray-400">Ping</div>
                        <div className="text-white font-semibold">
                          {server.last_ping || 0}ms
                        </div>
                      </div>
                    </div>

                    {server.endpoint_url && (
                      <div className="text-xs">
                        <div className="text-gray-400 mb-1">Endpoint</div>
                        <div className="text-cyan-400 font-mono truncate">
                          {server.endpoint_url}
                        </div>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          );
        })}
      </div>
      {servers.length === 0 && !isLoading && (
        <div className="text-center py-12">
          <Network className="w-12 h-12 text-gray-600 mx-auto mb-4" />
          <h3 className="text-xl font-semibold text-gray-400 mb-2">No servers configured</h3>
          <p className="text-gray-500">Add MCP servers to start managing your integrations</p>
        </div>
      )}
    </div>
  )
};

export default function MCPServerManager() {
  const [activeTab, setActiveTab] = useState('overview');

  const renderContent = () => {
    switch (activeTab) {
        case 'overview':
            return <OverviewTab />;
        default:
            return <EmptyState icon={Activity} title={`${activeTab.charAt(0).toUpperCase() + activeTab.slice(1)} Tab`} description="This section is under construction." />;
    }
  };

  return (
    <ModuleLayout
      title="MCP Server Management"
      status="20 Servers Online"
      statusColor="bg-green-500"
      lastUpdated="<1m ago"
      primaryAction={<Button className="bg-cyan-600 hover:bg-cyan-700"><Zap size={16} className="mr-2" /> New Server</Button>}
      tabs={mcpServerTabs}
      activeTab={activeTab}
      onTabChange={setActiveTab}
    >
      {renderContent()}
    </ModuleLayout>
  );
}