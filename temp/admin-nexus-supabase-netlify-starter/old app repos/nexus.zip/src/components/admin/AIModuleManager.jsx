import React, { useState } from 'react';
import ModuleLayout from './shared/ModuleLayout';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { motion, AnimatePresence } from 'framer-motion';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Search, Zap, ArrowRight, Workflow, Database, Cpu, FileOutput, BarChart3, Shield, Settings, PlayCircle } from "lucide-react";

// Import all existing custom module interfaces
import AuthorPersonas from './ai-modules/AuthorPersonas';
import ContentIdeation from './ai-modules/ContentIdeation';
import LongTailPageFactory from './ai-modules/LongTailPageFactory';
import SchemaWizard from './ai-modules/SchemaWizard';
import PillarPageGenerator from './ai-modules/PillarPageGenerator';
import ImageOptimizer from './ai-modules/ImageOptimizer';
import InternalLinkingArchitect from './ai-modules/InternalLinkingArchitect';
import StaggeredPublisher from './ai-modules/StaggeredPublisher';
import SemanticSearch from './ai-modules/SemanticSearch';
import LandingPageBuilder from './ai-modules/LandingPageBuilder';
import EditorialCalendar from './ai-modules/EditorialCalendar';
import ClientIntake from './ai-modules/ClientIntake';
import DocumentImporter from './ai-modules/DocumentImporter';
import ComingSoonModule from './ai-modules/ComingSoonModule';

// Organized modules by workflow category with custom interfaces
const moduleCategories = {
  inputs: {
    name: 'Data Inputs & Sources',
    icon: Database,
    description: 'Data ingestion, client onboarding, and knowledge building',
    color: 'bg-blue-500/20 text-blue-400 border-blue-500/50',
    modules: [
      { 
        id: 'client-intake', 
        title: "Client Intake & Onboarding", 
        purpose: "Streamlined client onboarding with smart forms, requirement gathering, and project setup automation.",
        phase: 1,
        component: ClientIntake,
        hasInterface: true
      },
      { 
        id: 'document-importer', 
        title: "Document Importer & Master Brain Updater", 
        purpose: "Intelligent document processing that extracts knowledge, updates the Business Brain, and maintains data freshness.",
        phase: 1,
        component: DocumentImporter,
        hasInterface: true
      },
      { 
        id: 'business-brain-builder', 
        title: "Business Brain Builder", 
        purpose: "Central knowledge repository that ingests content from all sources to create a living business intelligence system.",
        phase: 1,
        component: ComingSoonModule,
        hasInterface: false
      },
      { 
        id: 'brand-dna-builder', 
        title: "Brand DNA Builder", 
        purpose: "Consolidates brand voice, visual identity, competitive positioning, and messaging guidelines into a portable specification.",
        phase: 1,
        component: ComingSoonModule,
        hasInterface: false
      },
    ]
  },
  generators: {
    name: 'Content Generators',
    icon: FileOutput,
    description: 'AI-powered content creation and generation tools',
    color: 'bg-green-500/20 text-green-400 border-green-500/50',
    modules: [
      { 
        id: 'author-personas', 
        title: "Author Personas & Style Library", 
        purpose: "Create and manage multiple author voices with distinct personalities, writing styles, and expertise areas for diverse content creation.",
        phase: 1,
        component: AuthorPersonas,
        hasInterface: true
      },
      { 
        id: 'content-ideation', 
        title: "Content Ideation & Keyword Mapper", 
        purpose: "AI-driven topic discovery that finds content gaps, maps keywords to user intent, and generates detailed content briefs.",
        phase: 1,
        component: ContentIdeation,
        hasInterface: true
      },
      { 
        id: 'long-tail-factory', 
        title: "Long-Tail Landing Page Factory", 
        purpose: "Programmatically generate hundreds of targeted landing pages for long-tail keywords with dynamic CTAs and local variations.",
        phase: 1,
        component: LongTailPageFactory,
        hasInterface: true
      },
      { 
        id: 'pillar-generator', 
        title: "Pillar & Cluster Page Generator", 
        purpose: "Build comprehensive topic clusters with authoritative pillar pages and supporting content, complete with internal linking strategies.",
        phase: 1,
        component: PillarPageGenerator,
        hasInterface: true
      },
      { 
        id: 'landing-builder', 
        title: "Landing Page Builder", 
        purpose: "Conversion-optimized landing page creation with A/B testing variants, smart CTA placement, and form integration.",
        phase: 1,
        component: LandingPageBuilder,
        hasInterface: true
      },
      { 
        id: 'brand-image-generator', 
        title: "Brand-Aligned Image Generator", 
        purpose: "Generate on-brand visual content including hero images, illustrations, and icons that align with your brand DNA and page context.",
        phase: 2,
        component: ComingSoonModule,
        hasInterface: false
      },
      { 
        id: 'ai-readiness-quiz', 
        title: "AI Readiness Quiz Builder", 
        purpose: "No-code interactive assessments that generate personalized recommendations and capture qualified leads through valuable insights.",
        phase: 2,
        component: ComingSoonModule,
        hasInterface: false
      },
    ]
  },
  enhancers: {
    name: 'Content Enhancers',
    icon: Zap,
    description: 'SEO optimization, content improvement, and performance tools',
    color: 'bg-cyan-500/20 text-cyan-400 border-cyan-500/50',
    modules: [
      { 
        id: 'schema-wizard', 
        title: "Schema Wizard & Rich Results Manager", 
        purpose: "Automated structured data generation and optimization to maximize rich snippet eligibility and search visibility.",
        phase: 1,
        component: SchemaWizard,
        hasInterface: true
      },
      { 
        id: 'image-optimizer', 
        title: "Image Optimizer & Metadata Tagger", 
        purpose: "Intelligent image compression, alt text generation, and SEO-optimized metadata creation for all visual assets.",
        phase: 1,
        component: ImageOptimizer,
        hasInterface: true
      },
      { 
        id: 'internal-linking', 
        title: "Internal Linking & Topical Authority Architect", 
        purpose: "Strategic internal link building that reinforces topic clusters, distributes page authority, and enhances user navigation.",
        phase: 1,
        component: InternalLinkingArchitect,
        hasInterface: true
      },
      { 
        id: 'semantic-search', 
        title: "Semantic Site Search & Recommender", 
        purpose: "Advanced site search with natural language understanding, personalized content recommendations, and user behavior tracking.",
        phase: 1,
        component: SemanticSearch,
        hasInterface: true
      },
      { 
        id: 'adaptive-cta', 
        title: "Adaptive CTA Orchestrator", 
        purpose: "Dynamic call-to-action optimization that adapts based on user behavior, page context, and conversion probability.",
        phase: 2,
        component: ComingSoonModule,
        hasInterface: false
      },
      { 
        id: 'enrichment-pipeline', 
        title: "Content Enrichment Pipeline", 
        purpose: "Automated content enhancement with related topics, internal links, schema markup, and SEO improvements.",
        phase: 2,
        component: ComingSoonModule,
        hasInterface: false
      },
    ]
  },
  publishers: {
    name: 'Publishing & Distribution',
    icon: ArrowRight,
    description: 'Content publishing, scheduling, and distribution automation',
    color: 'bg-orange-500/20 text-orange-400 border-orange-500/50',
    modules: [
      { 
        id: 'staggered-publisher', 
        title: "Staggered Publisher & Index Monitor", 
        purpose: "Intelligent content publishing with natural timing patterns, sitemap management, and Google indexing monitoring.",
        phase: 1,
        component: StaggeredPublisher,
        hasInterface: true
      },
      { 
        id: 'editorial-calendar', 
        title: "Editorial Calendar & Wave Scheduler", 
        purpose: "Strategic content planning with dependency management, team assignments, and automated publishing workflows.",
        phase: 1,
        component: EditorialCalendar,
        hasInterface: true
      },
      { 
        id: 'webinar-engine', 
        title: "Webinar & Demo Automation Engine", 
        purpose: "End-to-end webinar management including registration pages, automated follow-up sequences, and replay distribution.",
        phase: 2,
        component: ComingSoonModule,
        hasInterface: false
      },
      { 
        id: 'email-automation', 
        title: "Email Automation Layer", 
        purpose: "Sophisticated email marketing with behavioral triggers, segmentation, and multi-channel campaign orchestration.",
        phase: 2,
        component: ComingSoonModule,
        hasInterface: false
      },
      { 
        id: 'retargeting-sync', 
        title: "Retargeting & Audience Sync Connector", 
        purpose: "Automated audience synchronization across advertising platforms with privacy compliance and suppression list management.",
        phase: 2,
        component: ComingSoonModule,
        hasInterface: false
      },
    ]
  },
  analytics: {
    name: 'Analytics & Insights',
    icon: BarChart3,
    description: 'Performance monitoring, analytics, and business intelligence',
    color: 'bg-red-500/20 text-red-400 border-red-500/50',
    modules: [
      { 
        id: 'client-tracker', 
        title: "Client Tracker & Deduplication Agent", 
        purpose: "Maintain clean client records across systems with intelligent duplicate detection, data enrichment, and relationship mapping.",
        phase: 2,
        component: ComingSoonModule,
        hasInterface: false
      },
      { 
        id: 'experiments-hub', 
        title: "Experiments & A/B Testing Hub", 
        purpose: "Comprehensive testing framework for content, design, and conversion optimization with statistical analysis and reporting.",
        phase: 2,
        component: ComingSoonModule,
        hasInterface: false
      },
      { 
        id: 'unified-analytics', 
        title: "Unified Analytics & Attribution Layer", 
        purpose: "Centralized analytics that connects traffic, engagement, and revenue data with advanced attribution modeling.",
        phase: 3,
        component: ComingSoonModule,
        hasInterface: false
      },
    ]
  },
  infrastructure: {
    name: 'System Infrastructure',
    icon: Shield,
    description: 'Platform management, integrations, and administrative tools',
    color: 'bg-gray-500/20 text-gray-400 border-gray-500/50',
    modules: [
      { 
        id: 'repo-admin', 
        title: "Repository Admin & GitOps Controller", 
        purpose: "Comprehensive code management with automated deployments, testing pipelines, and rollback capabilities.",
        phase: 1,
        component: ComingSoonModule,
        hasInterface: false
      },
      { 
        id: 'integrations-hub', 
        title: "Integrations Hub & Connector Registry", 
        purpose: "Centralized integration management for CRMs, email platforms, advertising networks, and third-party tools.",
        phase: 2,
        component: ComingSoonModule,
        hasInterface: false
      },
      { 
        id: 'workflow-builder', 
        title: "Visual Workflow & Automation Builder", 
        purpose: "Drag-and-drop workflow creation for complex multi-step automations with conditional logic and error handling.",
        phase: 2,
        component: ComingSoonModule,
        hasInterface: false
      },
      { 
        id: 'team-permissions', 
        title: "Team & Permissions Layer", 
        purpose: "Advanced role-based access control with approval workflows, audit trails, and team collaboration features.",
        phase: 3,
        component: ComingSoonModule,
        hasInterface: false
      },
    ]
  }
};

const CategoryCard = ({ category, categoryKey, onModuleClick, searchTerm }) => {
  const filteredModules = category.modules.filter(module =>
    module.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    module.purpose.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (filteredModules.length === 0) return null;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-4"
    >
      <div className="flex items-center gap-3 mb-6">
        <div className={`p-2 rounded-lg ${category.color}`}>
          <category.icon className="w-5 h-5" />
        </div>
        <div>
          <h3 className="text-lg font-semibold text-white">{category.name}</h3>
          <p className="text-sm text-gray-400">{category.description}</p>
        </div>
        <Badge variant="outline" className={`${category.color} ml-auto`}>
          {filteredModules.length} modules
        </Badge>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filteredModules.map((module, index) => (
          <motion.div
            key={module.id}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: index * 0.05 }}
            onClick={() => onModuleClick(module)}
            className="cursor-pointer group"
          >
            <Card className="bg-gray-800 border-gray-700 hover:border-cyan-500/50 transition-all duration-300 h-full group-hover:shadow-lg group-hover:shadow-cyan-500/10">
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <CardTitle className="text-white text-sm group-hover:text-cyan-400 transition-colors duration-200 line-clamp-2 mb-2">
                      {module.title}
                    </CardTitle>
                    <div className="flex items-center gap-2">
                      <Badge 
                        variant="outline" 
                        className={`text-xs ${
                          module.phase === 1 ? 'border-green-500/50 text-green-400' :
                          module.phase === 2 ? 'border-yellow-500/50 text-yellow-400' :
                          'border-red-500/50 text-red-400'
                        }`}
                      >
                        Phase {module.phase}
                      </Badge>
                      {module.hasInterface && (
                        <Badge variant="outline" className="text-xs border-cyan-500/50 text-cyan-400">
                          <PlayCircle size={10} className="mr-1" />
                          Interactive
                        </Badge>
                      )}
                    </div>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="pt-0">
                <p className="text-gray-400 text-xs line-clamp-3 group-hover:text-gray-300 transition-colors duration-200">
                  {module.purpose}
                </p>
                <div className="mt-3 flex items-center text-cyan-400 opacity-0 group-hover:opacity-100 transition-opacity duration-200">
                  {module.hasInterface ? (
                    <>
                      <PlayCircle size={12} className="mr-1" />
                      <span className="text-xs">Launch Interface</span>
                    </>
                  ) : (
                    <>
                      <Settings size={12} className="mr-1" />
                      <span className="text-xs">View Details</span>
                    </>
                  )}
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>
    </motion.div>
  );
};

export default function AIModuleManager() {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedModule, setSelectedModule] = useState(null);
  const [activeCategory, setActiveCategory] = useState('all');

  const handleModuleClick = (module) => {
    setSelectedModule(module);
  };

  const handleCloseModule = () => {
    setSelectedModule(null);
  };

  const totalModules = Object.values(moduleCategories).reduce((acc, cat) => acc + cat.modules.length, 0);
  const phase1Modules = Object.values(moduleCategories).reduce((acc, cat) => 
    acc + cat.modules.filter(m => m.phase === 1).length, 0);
  const interactiveModules = Object.values(moduleCategories).reduce((acc, cat) => 
    acc + cat.modules.filter(m => m.hasInterface).length, 0);

  const categoryTabs = [
    { id: 'all', name: 'All Modules', count: totalModules },
    ...Object.entries(moduleCategories).map(([key, category]) => ({
      id: key,
      name: category.name.split(' ')[0], // Shortened names for tabs
      count: category.modules.length
    }))
  ];

  return (
    <>
      <ModuleLayout
        title="AI Module Catalog"
        status={`${interactiveModules} Interactive • ${phase1Modules} Phase 1 Ready`}
        statusColor="bg-green-500"
        lastUpdated="Live"
        primaryAction={
          <Button className="bg-gradient-to-r from-cyan-600 to-blue-600 text-white shadow-lg hover:shadow-cyan-500/20">
            <Workflow size={16} className="mr-2" />
            Build Workflow
          </Button>
        }
        tabs={categoryTabs}
        activeTab={activeCategory}
        onTabChange={setActiveCategory}
      >
        <div className="space-y-6">
          {/* Search Bar */}
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <Card className="bg-gray-800 border-gray-700">
              <CardContent className="p-6">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                  <Input
                    placeholder="Search modules by name, purpose, or functionality..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10 bg-gray-700 border-gray-600 text-white placeholder-gray-500 focus:border-cyan-500"
                  />
                </div>
              </CardContent>
            </Card>
          </motion.div>

          {/* Module Categories */}
          <div className="space-y-12">
            {activeCategory === 'all' ? (
              // Show all categories
              Object.entries(moduleCategories).map(([categoryKey, category], index) => (
                <motion.div
                  key={categoryKey}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: index * 0.1 }}
                >
                  <CategoryCard
                    category={category}
                    categoryKey={categoryKey}
                    onModuleClick={handleModuleClick}
                    searchTerm={searchTerm}
                  />
                </motion.div>
              ))
            ) : (
              // Show specific category
              <CategoryCard
                category={moduleCategories[activeCategory]}
                categoryKey={activeCategory}
                onModuleClick={handleModuleClick}
                searchTerm={searchTerm}
              />
            )}
          </div>
        </div>
      </ModuleLayout>

      {/* Module Interface Dialog */}
      <Dialog open={!!selectedModule} onOpenChange={handleCloseModule}>
        <DialogContent className="max-w-7xl max-h-[90vh] bg-gray-900 border-cyan-500/30 p-0">
          {selectedModule && (
            <>
              {selectedModule.hasInterface ? (
                // Render the custom module interface
                <selectedModule.component onClose={handleCloseModule} />
              ) : (
                // Show coming soon or details view
                <div className="p-6">
                  <DialogHeader>
                    <motion.div
                      initial={{ opacity: 0, y: -10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="space-y-4"
                    >
                      <div className="flex items-start justify-between">
                        <DialogTitle className="text-white text-xl pr-8">
                          {selectedModule.title}
                        </DialogTitle>
                        <Badge className={`${
                          selectedModule.phase === 1 ? 'bg-green-500/20 text-green-400' :
                          selectedModule.phase === 2 ? 'bg-yellow-500/20 text-yellow-400' :
                          'bg-red-500/20 text-red-400'
                        }`}>
                          Phase {selectedModule.phase}
                        </Badge>
                      </div>
                      <DialogDescription className="text-gray-400 text-base leading-relaxed">
                        {selectedModule.purpose}
                      </DialogDescription>

                      <div className="bg-gradient-to-r from-cyan-500/10 to-blue-500/10 border border-cyan-500/20 rounded-lg p-6 text-center">
                        <Workflow className="w-12 h-12 text-cyan-400 mx-auto mb-4" />
                        <h3 className="text-lg font-semibold text-white mb-2">Module Interface Coming Soon</h3>
                        <p className="text-gray-400 mb-4">
                          This AI module is being developed with a full interactive interface. 
                          Soon you'll be able to configure, run, and chain it with other modules.
                        </p>
                        <Button className="bg-gradient-to-r from-cyan-600 to-blue-600">
                          <Zap size={16} className="mr-2" />
                          Request Early Access
                        </Button>
                      </div>
                    </motion.div>
                  </DialogHeader>
                </div>
              )}
            </>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
}