import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { DevService } from "@/api/entities";
import { Toggle } from "@/components/ui/toggle";
import { motion } from "framer-motion";
import { Play, Square, RefreshCw, Terminal, Cpu, HardDrive } from "lucide-react";

const statusColors = {
  running: 'bg-green-500',
  stopped: 'bg-gray-500',
  error: 'bg-red-500'
};

export default function DevServicesControl() {
  const [services, setServices] = useState([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadServices();
  }, []);

  const loadServices = async () => {
    try {
      const data = await DevService.list();
      setServices(data);
    } catch (error) {
      console.error("Error loading dev services:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const toggleService = async (service) => {
    const newStatus = service.status === 'running' ? 'stopped' : 'running';
    await DevService.update(service.id, { status: newStatus });
    loadServices();
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-white">Development Services</h1>
          <p className="text-gray-400 mt-1">Manage and monitor local development processes</p>
        </div>
      </div>
      <Card className="bg-gray-800 border-gray-700">
        <CardHeader>
          <CardTitle className="text-white">Service Control</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {services.map((service, index) => (
              <motion.div
                key={service.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.1 }}
              >
                <Card className="bg-gray-700 p-4 border-gray-600">
                  <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
                    <div className="flex-1">
                      <div className="flex items-center gap-3">
                        <div className={`w-3 h-3 rounded-full ${statusColors[service.status]} ${service.status === 'running' ? 'animate-pulse' : ''}`}></div>
                        <h3 className="text-white font-semibold">{service.name}</h3>
                        <Badge variant="outline" className="text-cyan-400 border-cyan-500/50 font-mono text-xs">{service.command}</Badge>
                      </div>
                      <p className="text-gray-400 text-sm mt-1">{service.description}</p>
                    </div>
                    <div className="flex items-center gap-4 text-sm">
                        <div className="flex items-center gap-2 text-gray-400">
                            <Cpu size={16} /> <span>{service.cpu_usage || 0}%</span>
                        </div>
                        <div className="flex items-center gap-2 text-gray-400">
                            <HardDrive size={16} /> <span>{service.memory_usage || 0}MB</span>
                        </div>
                    </div>
                    <div className="flex items-center gap-2">
                        <Toggle 
                            pressed={service.status === 'running'}
                            onPressedChange={() => toggleService(service)}
                            className="data-[state=on]:bg-green-600 data-[state=off]:bg-gray-600"
                        >
                            {service.status === 'running' ? <Square size={16} /> : <Play size={16} />}
                        </Toggle>
                      <Button variant="ghost" size="icon"><Terminal size={16} className="text-gray-400" /></Button>
                      <Button variant="ghost" size="icon"><RefreshCw size={16} className="text-gray-400" /></Button>
                    </div>
                  </div>
                </Card>
              </motion.div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}