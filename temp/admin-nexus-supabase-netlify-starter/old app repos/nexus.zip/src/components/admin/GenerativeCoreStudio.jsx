import React, { useState } from 'react';
import ModuleLayout from './shared/ModuleLayout';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Sparkles, Settings, Image as ImageIcon, Wand2, Bot, Zap } from 'lucide-react';
import ModelSettings from './generative-core/ModelSettings';
import ImagePlayground from './generative-core/ImagePlayground';
import ModuleImageGenerator from './generative-core/ModuleImageGenerator';

const generativeTabs = [
  { id: 'overview', name: 'Overview' },
  { id: 'models', name: 'Models' },
  { id: 'image-playground', name: 'Image Playground' },
  { id: 'module-images', name: 'Module Images' },
  { id: 'content-studio', name: 'Content Studio' },
  { id: 'analytics', name: 'Analytics' },
];

const OverviewTab = () => (
  <div className="space-y-6">
    <Card className="bg-gray-800 border-gray-700">
      <CardHeader>
        <CardTitle className="text-white flex items-center gap-2">
          <Sparkles className="text-cyan-400" />
          Welcome to the Generative Core Studio
        </CardTitle>
      </CardHeader>
      <CardContent>
        <p className="text-gray-400 mb-6">
          The central hub for all AI-powered generation tasks in WebsiteOS. Access cutting-edge models, 
          create custom content, and automate your creative workflows.
        </p>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <Card className="bg-gray-700/50 border-gray-600 hover:border-cyan-500/50 transition-colors">
            <CardHeader>
              <CardTitle className="text-white text-base flex items-center gap-2">
                <ImageIcon className="text-green-400" />
                Image Generation
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-400 text-sm mb-4">
                Generate custom images, logos, and visual content using DALL-E 3 and other advanced models.
              </p>
              <Button variant="outline" size="sm" className="border-gray-600 text-gray-300">
                Open Playground
              </Button>
            </CardContent>
          </Card>

          <Card className="bg-gray-700/50 border-gray-600 hover:border-purple-500/50 transition-colors">
            <CardHeader>
              <CardTitle className="text-white text-base flex items-center gap-2">
                <Bot className="text-purple-400" />
                Content Generation
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-400 text-sm mb-4">
                Create blog posts, landing pages, and marketing copy using GPT-4o and Gemini 1.5 Pro.
              </p>
              <Button variant="outline" size="sm" className="border-gray-600 text-gray-300">
                Coming Soon
              </Button>
            </CardContent>
          </Card>

          <Card className="bg-gray-700/50 border-gray-600 hover:border-blue-500/50 transition-colors">
            <CardHeader>
              <CardTitle className="text-white text-base flex items-center gap-2">
                <Wand2 className="text-blue-400" />
                AI Module Images
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-400 text-sm mb-4">
                Auto-generate feature images for all AI modules with consistent branding and style.
              </p>
              <Button variant="outline" size="sm" className="border-gray-600 text-gray-300">
                Generate All
              </Button>
            </CardContent>
          </Card>
        </div>
      </CardContent>
    </Card>

    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      <Card className="bg-gray-800 border-gray-700">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium text-gray-400">Images Generated</CardTitle>
          <ImageIcon className="h-4 w-4 text-green-400" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold text-white">142</div>
          <p className="text-xs text-green-400">+23% this month</p>
        </CardContent>
      </Card>

      <Card className="bg-gray-800 border-gray-700">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium text-gray-400">Content Pieces</CardTitle>
          <Bot className="h-4 w-4 text-purple-400" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold text-white">1,247</div>
          <p className="text-xs text-green-400">+18% this month</p>
        </CardContent>
      </Card>

      <Card className="bg-gray-800 border-gray-700">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium text-gray-400">API Calls</CardTitle>
          <Zap className="h-4 w-4 text-cyan-400" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold text-white">8,934</div>
          <p className="text-xs text-gray-400">This month</p>
        </CardContent>
      </Card>

      <Card className="bg-gray-800 border-gray-700">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium text-gray-400">Cost Saved</CardTitle>
          <Sparkles className="h-4 w-4 text-yellow-400" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold text-white">$2,847</div>
          <p className="text-xs text-green-400">vs manual creation</p>
        </CardContent>
      </Card>
    </div>
  </div>
);

export default function GenerativeCoreStudio() {
  const [activeTab, setActiveTab] = useState('overview');

  const renderContent = () => {
    switch (activeTab) {
      case 'overview':
        return <OverviewTab />;
      case 'models':
        return <ModelSettings />;
      case 'image-playground':
        return <ImagePlayground />;
      case 'module-images':
        return <ModuleImageGenerator />;
      default:
        return (
          <Card className="bg-gray-800 border-gray-700">
            <CardContent className="p-12 text-center">
              <div className="text-gray-400 mb-4">
                <Bot className="w-16 h-16 mx-auto" />
              </div>
              <h3 className="text-lg font-medium text-gray-900 mb-2 text-white">Coming Soon</h3>
              <p className="text-gray-500">The {activeTab.replace('-', ' ')} section is being built.</p>
            </CardContent>
          </Card>
        );
    }
  };

  return (
    <ModuleLayout
      title="Generative Core Studio"
      status="GPT-4o • DALL-E 3 • Gemini 1.5 Pro"
      statusColor="bg-purple-500"
      lastUpdated="Live"
      primaryAction={
        <div className="flex gap-2">
          <Button variant="outline" size="sm" className="text-gray-300 border-gray-600">
            <Settings size={14} className="mr-2" />
            Settings
          </Button>
          <Button className="bg-gradient-to-r from-purple-600 to-pink-600 text-white">
            <Sparkles size={14} className="mr-2" />
            Generate Content
          </Button>
        </div>
      }
      tabs={generativeTabs}
      activeTab={activeTab}
      onTabChange={setActiveTab}
    >
      {renderContent()}
    </ModuleLayout>
  );
}