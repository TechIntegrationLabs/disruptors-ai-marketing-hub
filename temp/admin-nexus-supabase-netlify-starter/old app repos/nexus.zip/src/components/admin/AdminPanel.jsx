
import React, { useState, useEffect, useCallback } from 'react';
import AdminSidebar from "./AdminSidebar";
import DashboardOverview from "./DashboardOverview";
import AIModuleManager from "./AIModuleManager";
import MCPServerManager from "./MCPServerManager";
import DevServicesControl from "./DevServicesControl";
import RepoAdmin from "./RepoAdmin";
import TelemetryDashboard from "./TelemetryDashboard";
import ReplicateAiPanel from "./ReplicateAiPanel";
import BusinessBrainBuilder from './BusinessBrainBuilder';
import BrandDNABuilder from './BrandDNABuilder';
import WebsiteOSCMS from './WebsiteOSCMS';
import AgentOrchestra from './AgentOrchestra';
import SubAgentManagement from './SubAgentManagement';
import IntegrationsHub from './IntegrationsHub';
import CommandPalette from './CommandPalette';
import GenerativeCoreStudio from './GenerativeCoreStudio'; // Added GenerativeCoreStudio import

const moduleCommands = {
  dashboard: [
    { verb: 'View metrics', module: 'Dashboard' },
    { verb: 'Export report', module: 'Dashboard' },
    { verb: 'Refresh data', module: 'Dashboard' }
  ],
  'website-os': [
    { verb: 'Create new page', module: 'WebsiteOS CMS' },
    { verb: 'Edit content', module: 'WebsiteOS CMS' },
    { verb: 'Manage media', module: 'WebsiteOS CMS' }
  ],
  'business-brain': [
    { verb: 'Add new fact', module: 'Business Brain' },
    { verb: 'Update knowledge', module: 'Business Brain' },
    { verb: 'Export brain data', module: 'Business Brain' }
  ],
  'brand-dna': [
    { verb: 'Update voice', module: 'Brand DNA' },
    { verb: 'Set new colors', module: 'Brand DNA' },
    { verb: 'Upload logo', module: 'Brand DNA' }
  ],
  'ai-modules': [
    { verb: 'Generate content', module: 'AI Modules' },
    { verb: 'Create personas', module: 'AI Modules' },
    { verb: 'Optimize images', module: 'AI Modules' }
  ],
  'telemetry': [
    { verb: 'View analytics', module: 'Telemetry' },
    { verb: 'Export data', module: 'Telemetry' },
    { verb: 'Set alerts', module: 'Telemetry' }
  ],
  'integrations': [
    { verb: 'Connect new service', module: 'Integrations Hub' },
    { verb: 'Review connections', module: 'Integrations Hub' },
    { verb: 'Test webhook', module: 'Integrations Hub' },
  ],
  'agent-orchestra': [
    { verb: 'New workflow', module: 'Agent Orchestra' },
    { verb: 'View active runs', module: 'Agent Orchestra' },
  ],
  'repo-admin': [
    { verb: 'Deploy to production', module: 'Repo Admin' },
    { verb: 'Create new branch', module: 'Repo Admin' },
    { verb: 'View commit history', module: 'Repo Admin' }
  ],
  'mcp-servers': [
    { verb: 'Start server', module: 'MCP Servers' },
    { verb: 'Check status', module: 'MCP Servers' },
    { verb: 'View logs', module: 'MCP Servers' }
  ],
  'sub-agents': [
    { verb: 'Evaluate agent', module: 'Sub-Agents' },
    { verb: 'Set new guardrail', module: 'Sub-Agents' },
  ],
};

const moduleComponents = {
  'dashboard': DashboardOverview,
  'repo-admin': RepoAdmin,
  'business-brain': BusinessBrainBuilder,
  'brand-dna': BrandDNABuilder,
  'website-os': WebsiteOSCMS,
  'telemetry': TelemetryDashboard,
  'ai-modules': AIModuleManager,
  'mcp-servers': MCPServerManager,
  'agent-orchestra': AgentOrchestra,
  'dev-services': DevServicesControl,
  'replicate-ai': ReplicateAiPanel,
  'sub-agents': SubAgentManagement,
  'integrations': IntegrationsHub,
  'generative-core': GenerativeCoreStudio // Added this line
};

export default function AdminPanel() {
  const [activeModule, setActiveModule] = useState('dashboard');
  const [isCommandPaletteOpen, setCommandPaletteOpen] = useState(false);
  const [isSidebarCollapsed, setSidebarCollapsed] = useState(false);

  // Expose module navigation to the command palette
  useEffect(() => {
    window.onModuleChange = setActiveModule;
    return () => {
      window.onModuleChange = null;
    };
  }, []);

  const handleKeyDown = useCallback((event) => {
    if ((event.metaKey || event.ctrlKey) && event.key === 'k') {
      event.preventDefault();
      setCommandPaletteOpen(open => !open);
    }
  }, []);

  useEffect(() => {
    document.addEventListener('keydown', handleKeyDown);
    return () => {
      document.removeEventListener('keydown', handleKeyDown);
    };
  }, [handleKeyDown]);

  const ActiveComponent = moduleComponents[activeModule] || DashboardOverview;
  const allCommands = Object.values(moduleCommands).flat();

  return (
    <div className="min-h-screen bg-gray-900 flex">
      <AdminSidebar 
        activeModule={activeModule} 
        onModuleChange={setActiveModule}
        isCollapsed={isSidebarCollapsed}
        onToggle={() => setSidebarCollapsed(!isSidebarCollapsed)}
      />
      <main className="flex-1 overflow-auto">
        <div className="p-6">
          <ActiveComponent />
        </div>
      </main>
      <CommandPalette 
        isOpen={isCommandPaletteOpen}
        onClose={() => setCommandPaletteOpen(false)}
        commands={allCommands}
        onCommandSelect={(cmd) => {
            const targetModule = Object.keys(moduleCommands).find(key => 
                moduleCommands[key].some(c => c.verb === cmd.verb)
            );
            if(targetModule) setActiveModule(targetModule);
            console.log('Command selected:', cmd);
        }}
      />
    </div>
  );
}
