import React from 'react';
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { motion, AnimatePresence } from 'framer-motion';
import { Clock, Zap } from 'lucide-react';

const ModuleLayout = ({ 
  title, 
  status, 
  statusColor = "bg-cyan-500", 
  lastUpdated, 
  primaryAction, 
  secondaryActions = [], 
  tabs = [], 
  activeTab, 
  onTabChange,
  children 
}) => {
  return (
    <div className="min-h-screen bg-gray-900">
      {/* Header */}
      <motion.div 
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, ease: "easeOut" }}
        className="border-b border-cyan-500/20 bg-gray-900/95 backdrop-blur-sm sticky top-0 z-40"
      >
        <div className="px-6 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <motion.div
                whileHover={{ scale: 1.02 }}
                transition={{ type: "spring", stiffness: 400, damping: 25 }}
              >
                <h1 className="text-2xl font-bold text-white">{title}</h1>
              </motion.div>
              <div className="flex items-center space-x-3">
                {status && (
                  <motion.div
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    transition={{ delay: 0.2, type: "spring", stiffness: 400, damping: 25 }}
                  >
                    <Badge className={`${statusColor} text-white border-0 shadow-lg`}>
                      <motion.div 
                        animate={{ scale: [1, 1.1, 1] }}
                        transition={{ duration: 2, repeat: Infinity }}
                        className="w-2 h-2 bg-white rounded-full mr-2"
                      ></motion.div>
                      {status}
                    </Badge>
                  </motion.div>
                )}
                {lastUpdated && (
                  <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ delay: 0.3 }}
                    className="flex items-center text-gray-400 text-sm"
                  >
                    <Clock className="w-3 h-3 mr-1" />
                    {lastUpdated}
                  </motion.div>
                )}
              </div>
            </div>
            
            <div className="flex items-center space-x-3">
              {secondaryActions.map((action, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.4 + index * 0.1 }}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  {action}
                </motion.div>
              ))}
              {primaryAction && (
                <motion.div
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.5 }}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  {primaryAction}
                </motion.div>
              )}
            </div>
          </div>
        </div>
      </motion.div>

      {/* Tabs */}
      {tabs.length > 0 && (
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3, duration: 0.5 }}
          className="border-b border-gray-700 bg-gray-900/50 backdrop-blur-sm"
        >
          <div className="px-6">
            <Tabs value={activeTab} onValueChange={onTabChange}>
              <TabsList className="bg-transparent border-0 p-0 h-auto">
                <div className="flex space-x-1">
                  {tabs.map((tab, index) => (
                    <motion.div
                      key={tab.id}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: 0.4 + index * 0.1 }}
                      whileHover={{ y: -2 }}
                      whileTap={{ y: 0 }}
                    >
                      <TabsTrigger
                        value={tab.id}
                        className={`px-4 py-3 text-sm font-medium transition-all duration-200 border-b-2 border-transparent rounded-t-lg ${
                          activeTab === tab.id
                            ? 'text-cyan-400 border-cyan-400 bg-gray-800/50 shadow-lg'
                            : 'text-gray-400 hover:text-cyan-300 hover:bg-gray-800/30'
                        }`}
                      >
                        {tab.name}
                      </TabsTrigger>
                    </motion.div>
                  ))}
                </div>
              </TabsList>
            </Tabs>
          </div>
        </motion.div>
      )}

      {/* Content */}
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.6, duration: 0.5 }}
        className="flex-1 p-6"
      >
        <AnimatePresence mode="wait">
          <motion.div
            key={activeTab || 'content'}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.3, ease: "easeInOut" }}
          >
            {children}
          </motion.div>
        </AnimatePresence>
      </motion.div>
    </div>
  );
};

export default ModuleLayout;