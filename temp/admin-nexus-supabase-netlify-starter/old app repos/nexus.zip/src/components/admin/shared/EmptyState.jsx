import React from 'react';
import { Button } from '@/components/ui/button';

export default function EmptyState({ icon: Icon, title, description, actionText, onAction, docsLink }) {
  return (
    <div className="text-center bg-gray-800 border-2 border-dashed border-gray-700 rounded-lg p-12">
      {Icon && <Icon className="mx-auto h-12 w-12 text-gray-500" />}
      <h3 className="mt-4 text-lg font-medium text-white">{title}</h3>
      <p className="mt-2 text-sm text-gray-400">{description}</p>
      <div className="mt-6 flex items-center justify-center gap-4">
        {onAction && <Button onClick={onAction} className="bg-cyan-600 hover:bg-cyan-700">{actionText}</Button>}
        {docsLink && <Button variant="link" className="text-cyan-400">Read Docs</Button>}
      </div>
    </div>
  );
}