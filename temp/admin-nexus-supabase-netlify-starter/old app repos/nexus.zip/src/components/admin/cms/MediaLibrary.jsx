
import React, { useState, useEffect, useCallback } from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { 
  Upload,
  Search,
  Grid3X3,
  List,
  Image,
  FileText,
  Video,
  Music,
  File,
  MoreHorizontal,
  Copy,
  Edit,
  Trash2
} from "lucide-react";
import { MediaAsset } from '@/api/entities';

const getFileIcon = (fileType, mimeType) => {
  switch (fileType) {
    case 'image':
      return Image;
    case 'video':
      return Video;
    case 'audio':
      return Music;
    case 'document':
      return FileText;
    default:
      return File;
  }
};

const formatFileSize = (bytes) => {
  if (bytes === 0) return '0 Bytes';
  const k = 1024;
  const sizes = ['Bytes', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
};

export default function MediaLibrary({ onItemClick }) {
  const [assets, setAssets] = useState([]);
  const [viewMode, setViewMode] = useState('grid');
  const [searchTerm, setSearchTerm] = useState('');
  const [typeFilter, setTypeFilter] = useState('all');
  const [isDragOver, setIsDragOver] = useState(false);

  const loadAssets = useCallback(async () => {
    try {
      const data = await MediaAsset.list('-created_date');
      let filtered = data;

      if (searchTerm) {
        filtered = filtered.filter(asset =>
          asset.filename.toLowerCase().includes(searchTerm.toLowerCase()) ||
          asset.alt_text?.toLowerCase().includes(searchTerm.toLowerCase())
        );
      }

      if (typeFilter !== 'all') {
        filtered = filtered.filter(asset => asset.file_type === typeFilter);
      }

      setAssets(filtered);
    } catch (error) {
      console.error('Error loading media assets:', error);
    }
  }, [searchTerm, typeFilter]);

  useEffect(() => {
    loadAssets();
  }, [loadAssets]);

  const handleDragOver = (e) => {
    e.preventDefault();
    setIsDragOver(true);
  };

  const handleDragLeave = (e) => {
    e.preventDefault();
    setIsDragOver(false);
  };

  const handleDrop = (e) => {
    e.preventDefault();
    setIsDragOver(false);
    // Handle file drop logic here
  };

  return (
    <Card className="bg-white border-gray-200">
      {/* Toolbar */}
      <div className="border-b border-gray-200 p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <Button className="bg-blue-600 hover:bg-blue-700 text-white">
              <Upload className="w-4 h-4 mr-2" />
              Upload Files
            </Button>
          </div>

          <div className="flex items-center space-x-3">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Input
                placeholder="Search media..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 w-64 border-gray-300"
              />
            </div>
            
            <Select value={typeFilter} onValueChange={setTypeFilter}>
              <SelectTrigger className="w-32">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Types</SelectItem>
                <SelectItem value="image">Images</SelectItem>
                <SelectItem value="video">Videos</SelectItem>
                <SelectItem value="audio">Audio</SelectItem>
                <SelectItem value="document">Documents</SelectItem>
              </SelectContent>
            </Select>

            <div className="flex items-center border border-gray-300 rounded-md">
              <Button
                variant={viewMode === 'grid' ? 'default' : 'ghost'}
                size="sm"
                onClick={() => setViewMode('grid')}
                className="rounded-r-none border-0"
              >
                <Grid3X3 className="w-4 h-4" />
              </Button>
              <Button
                variant={viewMode === 'list' ? 'default' : 'ghost'}
                size="sm"
                onClick={() => setViewMode('list')}
                className="rounded-l-none border-0"
              >
                <List className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Media Grid/List */}
      <CardContent 
        className={`p-0 ${isDragOver ? 'bg-blue-50' : ''}`}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
      >
        {viewMode === 'grid' ? (
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 xl:grid-cols-8 gap-4 p-6">
            {assets.map((asset) => {
              const FileIcon = getFileIcon(asset.file_type, asset.mime_type);
              return (
                <div
                  key={asset.id}
                  onClick={() => onItemClick(asset)}
                  className="group relative bg-white border border-gray-200 rounded-lg p-3 hover:shadow-md transition-shadow cursor-pointer"
                >
                  <div className="aspect-square flex items-center justify-center bg-gray-50 rounded-md mb-2">
                    {asset.file_type === 'image' && asset.file_url ? (
                      <img
                        src={asset.file_url}
                        alt={asset.alt_text || asset.filename}
                        className="w-full h-full object-cover rounded-md"
                      />
                    ) : (
                      <FileIcon className="w-8 h-8 text-gray-400" />
                    )}
                  </div>
                  
                  <div className="space-y-1">
                    <p className="text-xs font-medium text-gray-900 truncate">
                      {asset.filename}
                    </p>
                    <p className="text-xs text-gray-500">
                      {formatFileSize(asset.file_size)}
                    </p>
                    {asset.dimensions && (
                      <p className="text-xs text-gray-500">
                        {asset.dimensions.width} × {asset.dimensions.height}
                      </p>
                    )}
                  </div>

                  <Badge
                    variant="secondary"
                    className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity text-xs"
                  >
                    {asset.file_type}
                  </Badge>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="divide-y divide-gray-200">
            {assets.map((asset) => {
              const FileIcon = getFileIcon(asset.file_type, asset.mime_type);
              return (
                <div
                  key={asset.id}
                  onClick={() => onItemClick(asset)}
                  className="flex items-center px-6 py-4 hover:bg-gray-50 cursor-pointer"
                >
                  <div className="flex-shrink-0 mr-4">
                    {asset.file_type === 'image' && asset.file_url ? (
                      <img
                        src={asset.file_url}
                        alt={asset.alt_text || asset.filename}
                        className="w-12 h-12 object-cover rounded-md"
                      />
                    ) : (
                      <div className="w-12 h-12 flex items-center justify-center bg-gray-100 rounded-md">
                        <FileIcon className="w-6 h-6 text-gray-400" />
                      </div>
                    )}
                  </div>
                  
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-gray-900 truncate">
                      {asset.filename}
                    </p>
                    <div className="flex items-center space-x-4 text-sm text-gray-500">
                      <span>{asset.file_type}</span>
                      <span>{formatFileSize(asset.file_size)}</span>
                      {asset.dimensions && (
                        <span>{asset.dimensions.width} × {asset.dimensions.height}</span>
                      )}
                      <span>Used in {asset.used_in_count || 0} items</span>
                    </div>
                  </div>
                  
                  <Button variant="ghost" size="sm">
                    <MoreHorizontal className="w-4 h-4" />
                  </Button>
                </div>
              );
            })}
          </div>
        )}

        {/* Empty State */}
        {assets.length === 0 && (
          <div className="text-center py-12">
            <Upload className="w-12 h-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">No media files yet</h3>
            <p className="text-gray-500 mb-4">Upload your first media file to get started</p>
            <Button className="bg-blue-600 hover:bg-blue-700 text-white">
              <Upload className="w-4 h-4 mr-2" />
              Upload Files
            </Button>
          </div>
        )}

        {/* Drag & Drop Overlay */}
        {isDragOver && (
          <div className="absolute inset-0 bg-blue-50 border-2 border-dashed border-blue-300 rounded-lg flex items-center justify-center">
            <div className="text-center">
              <Upload className="w-12 h-12 text-blue-500 mx-auto mb-4" />
              <p className="text-lg font-medium text-blue-700">Drop files here to upload</p>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
