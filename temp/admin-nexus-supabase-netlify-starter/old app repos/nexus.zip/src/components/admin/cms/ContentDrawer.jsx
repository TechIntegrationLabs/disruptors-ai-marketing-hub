import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { 
  X, 
  Edit, 
  Eye, 
  Clock, 
  User, 
  Calendar,
  Search,
  BarChart3,
  History,
  Image as ImageIcon
} from "lucide-react";

const statusColors = {
  draft: 'bg-gray-100 text-gray-800',
  in_review: 'bg-yellow-100 text-yellow-800',
  scheduled: 'bg-blue-100 text-blue-800',
  published: 'bg-green-100 text-green-800',
  archived: 'bg-red-100 text-red-800'
};

export default function ContentDrawer({ isOpen, onClose, item, contentType }) {
  const [activeTab, setActiveTab] = useState('summary');

  if (!isOpen || !item) return null;

  const isMediaAsset = contentType?.id === 'media' || item.file_url;

  return (
    <div className={`fixed inset-y-0 right-0 w-96 bg-white border-l border-gray-200 shadow-lg transform transition-transform duration-300 ease-in-out z-50 ${
      isOpen ? 'translate-x-0' : 'translate-x-full'
    }`}>
      {/* Header */}
      <div className="border-b border-gray-200 p-4">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-semibold text-gray-900 truncate">
            {item.title || item.filename || 'Untitled'}
          </h2>
          <Button variant="ghost" size="sm" onClick={onClose}>
            <X className="w-4 h-4" />
          </Button>
        </div>
        <div className="flex items-center space-x-3 mt-2">
          {item.status && (
            <Badge className={statusColors[item.status] || statusColors.draft}>
              {item.status}
            </Badge>
          )}
          {item.file_type && (
            <Badge variant="outline" className="text-gray-600 border-gray-300">
              {item.file_type}
            </Badge>
          )}
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-auto">
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="w-full justify-start p-0 h-auto bg-white border-b border-gray-200">
            <TabsTrigger 
              value="summary" 
              className="data-[state=active]:bg-white data-[state=active]:text-blue-600 data-[state=active]:border-b-2 data-[state=active]:border-blue-600 rounded-none px-4 py-3"
            >
              Summary
            </TabsTrigger>
            <TabsTrigger 
              value="seo" 
              className="data-[state=active]:bg-white data-[state=active]:text-blue-600 data-[state=active]:border-b-2 data-[state=active]:border-blue-600 rounded-none px-4 py-3"
            >
              SEO
            </TabsTrigger>
            <TabsTrigger 
              value="history" 
              className="data-[state=active]:bg-white data-[state=active]:text-blue-600 data-[state=active]:border-b-2 data-[state=active]:border-blue-600 rounded-none px-4 py-3"
            >
              History
            </TabsTrigger>
          </TabsList>

          <TabsContent value="summary" className="p-4 space-y-4">
            {isMediaAsset ? (
              // Media Asset Summary
              <>
                {item.file_type === 'image' && item.file_url && (
                  <div className="aspect-video bg-gray-100 rounded-lg overflow-hidden">
                    <img 
                      src={item.file_url} 
                      alt={item.alt_text || item.filename}
                      className="w-full h-full object-contain"
                    />
                  </div>
                )}

                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-sm">File Details</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div>
                      <p className="text-xs font-medium text-gray-500 uppercase tracking-wide">Filename</p>
                      <p className="text-sm text-gray-900">{item.filename}</p>
                    </div>
                    
                    {item.dimensions && (
                      <div>
                        <p className="text-xs font-medium text-gray-500 uppercase tracking-wide">Dimensions</p>
                        <p className="text-sm text-gray-900">
                          {item.dimensions.width} × {item.dimensions.height} pixels
                        </p>
                      </div>
                    )}
                    
                    <div>
                      <p className="text-xs font-medium text-gray-500 uppercase tracking-wide">File Size</p>
                      <p className="text-sm text-gray-900">
                        {item.file_size ? `${(item.file_size / 1024).toFixed(1)} KB` : 'Unknown'}
                      </p>
                    </div>

                    <div>
                      <p className="text-xs font-medium text-gray-500 uppercase tracking-wide">Alt Text</p>
                      <p className="text-sm text-gray-900">{item.alt_text || 'Not set'}</p>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-sm">Usage</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-gray-600">
                      Used in {item.used_in_count || 0} content items
                    </p>
                  </CardContent>
                </Card>
              </>
            ) : (
              // Content Summary
              <>
                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-sm">Content Details</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div>
                      <p className="text-xs font-medium text-gray-500 uppercase tracking-wide">Status</p>
                      <Badge className={statusColors[item.status] || statusColors.draft}>
                        {item.status || 'draft'}
                      </Badge>
                    </div>
                    
                    <div>
                      <p className="text-xs font-medium text-gray-500 uppercase tracking-wide">Author</p>
                      <div className="flex items-center space-x-2">
                        <User className="w-4 h-4 text-gray-400" />
                        <p className="text-sm text-gray-900">{item.author || item.created_by || 'Unknown'}</p>
                      </div>
                    </div>

                    <div>
                      <p className="text-xs font-medium text-gray-500 uppercase tracking-wide">Created</p>
                      <div className="flex items-center space-x-2">
                        <Calendar className="w-4 h-4 text-gray-400" />
                        <p className="text-sm text-gray-900">
                          {new Date(item.created_date).toLocaleDateString()}
                        </p>
                      </div>
                    </div>

                    <div>
                      <p className="text-xs font-medium text-gray-500 uppercase tracking-wide">Last Updated</p>
                      <div className="flex items-center space-x-2">
                        <Clock className="w-4 h-4 text-gray-400" />
                        <p className="text-sm text-gray-900">
                          {new Date(item.updated_date).toLocaleDateString()}
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {item.content && (
                  <Card>
                    <CardHeader className="pb-3">
                      <CardTitle className="text-sm">Content Preview</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-sm text-gray-600 line-clamp-6">
                        {item.content.length > 200 
                          ? item.content.substring(0, 200) + '...'
                          : item.content
                        }
                      </p>
                    </CardContent>
                  </Card>
                )}
              </>
            )}
          </TabsContent>

          <TabsContent value="seo" className="p-4 space-y-4">
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm flex items-center">
                  <Search className="w-4 h-4 mr-2" />
                  SEO Details
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div>
                  <p className="text-xs font-medium text-gray-500 uppercase tracking-wide">SEO Title</p>
                  <p className="text-sm text-gray-900">{item.seo_title || item.title || 'Not set'}</p>
                </div>
                
                <div>
                  <p className="text-xs font-medium text-gray-500 uppercase tracking-wide">Meta Description</p>
                  <p className="text-sm text-gray-900">{item.seo_description || 'Not set'}</p>
                </div>

                <div>
                  <p className="text-xs font-medium text-gray-500 uppercase tracking-wide">URL Slug</p>
                  <p className="text-sm text-gray-900 font-mono">{item.slug || 'Auto-generated'}</p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="history" className="p-4 space-y-4">
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm flex items-center">
                  <History className="w-4 h-4 mr-2" />
                  Recent Changes
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-center space-x-3 text-sm">
                    <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                    <div className="flex-1">
                      <p className="text-gray-900">Content updated</p>
                      <p className="text-gray-500">{new Date(item.updated_date).toLocaleString()}</p>
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-3 text-sm">
                    <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                    <div className="flex-1">
                      <p className="text-gray-900">Created</p>
                      <p className="text-gray-500">{new Date(item.created_date).toLocaleString()}</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>

      {/* Footer Actions */}
      <div className="border-t border-gray-200 p-4">
        <div className="flex space-x-3">
          <Button className="flex-1 bg-blue-600 hover:bg-blue-700 text-white">
            <Edit className="w-4 h-4 mr-2" />
            {isMediaAsset ? 'Edit Media' : 'Edit Full Page'}
          </Button>
          <Button variant="outline" className="border-gray-300 text-gray-600">
            <Eye className="w-4 h-4 mr-2" />
            Preview
          </Button>
        </div>
      </div>
    </div>
  );
}