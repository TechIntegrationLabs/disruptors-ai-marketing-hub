import React, { useState, useEffect } from 'react';
import ModuleLayout from './shared/ModuleLayout';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { 
  Plus, 
  Settings, 
  CheckCircle, 
  AlertCircle, 
  RefreshCw,
  Search,
  Zap,
  BarChart3,
  Globe,
  Smartphone,
  Link,
  FileText,
  Database,
  Workflow
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { Integration } from "@/api/entities";
import GoogleAnalyticsConfig from '@/api/integrations/GoogleAnalyticsConfig';
import GoogleSearchConsoleConfig from '@/api/integrations/GoogleSearchConsoleConfig';
import GoogleAdsConfig from '@/api/integrations/GoogleAdsConfig';
import MetaAdsConfig from '@/api/integrations/MetaAdsConfig';
import DataForSEOConfig from '@/api/integrations/DataForSEOConfig';
import GoogleSheetsConfig from '@/api/integrations/GoogleSheetsConfig';
import AirtableConfig from '@/api/integrations/AirtableConfig';
import ZapierConfig from '@/api/integrations/ZapierConfig';
import GoogleBusinessConfig from '@/api/integrations/GoogleBusinessConfig';

const integrationTabs = [
  { id: 'all', name: 'All Integrations' },
  { id: 'analytics', name: 'Analytics' },
  { id: 'advertising', name: 'Advertising' },
  { id: 'seo', name: 'SEO Tools' },
  { id: 'data', name: 'Data Sources' },
  { id: 'automation', name: 'Automation' },
];

const integrationsData = [
  // Analytics Category
  {
    id: 'google-analytics',
    name: 'Google Analytics 4',
    category: 'analytics',
    description: 'Website traffic, user behavior, and conversion tracking',
    logo: '🔍',
    status: 'disconnected',
    featured: true,
    component: GoogleAnalyticsConfig,
    dataFeeds: ['Telemetry Dashboard', 'Business Brain', 'Content Ideation', 'Landing Page Builder'],
    capabilities: ['Page views', 'User sessions', 'Conversion events', 'Traffic sources', 'Audience insights']
  },
  {
    id: 'google-search-console',
    name: 'Google Search Console',
    category: 'seo',
    description: 'Organic search performance and technical SEO monitoring',
    logo: '🔎',
    status: 'disconnected',
    featured: true,
    component: GoogleSearchConsoleConfig,
    dataFeeds: ['Business Brain', 'Content Ideation', 'Internal Linking', 'Schema Wizard'],
    capabilities: ['Search queries', 'Click-through rates', 'Index status', 'Core Web Vitals', 'Crawl errors']
  },
  {
    id: 'google-business',
    name: 'Google Business Profile',
    category: 'analytics',
    description: 'Local business presence and review management',
    logo: '🏪',
    status: 'disconnected',
    featured: false,
    component: GoogleBusinessConfig,
    dataFeeds: ['Business Brain', 'Brand DNA', 'Telemetry Dashboard'],
    capabilities: ['Reviews', 'Local search actions', 'Business insights', 'Q&A management']
  },
  
  // Advertising Category
  {
    id: 'google-ads',
    name: 'Google Ads',
    category: 'advertising',
    description: 'Paid search campaign performance and optimization',
    logo: '💰',
    status: 'disconnected',
    featured: true,
    component: GoogleAdsConfig,
    dataFeeds: ['Telemetry Dashboard', 'Business Brain', 'Long-Tail Page Factory', 'Brand DNA'],
    capabilities: ['Campaign performance', 'Ad spend tracking', 'Keyword data', 'Conversion tracking']
  },
  {
    id: 'meta-ads',
    name: 'Meta Ads',
    category: 'advertising', 
    description: 'Facebook and Instagram advertising performance',
    logo: '📱',
    status: 'disconnected',
    featured: true,
    component: MetaAdsConfig,
    dataFeeds: ['Telemetry Dashboard', 'Brand DNA', 'Image Optimizer', 'Author Personas'],
    capabilities: ['Social ad performance', 'Audience insights', 'Creative analysis', 'Attribution tracking']
  },
  
  // SEO Tools Category
  {
    id: 'dataforseo',
    name: 'DataForSEO',
    category: 'seo',
    description: 'Comprehensive SEO data, keyword research, and competitor analysis',
    logo: '🎯',
    status: 'disconnected',
    featured: true,
    component: DataForSEOConfig,
    dataFeeds: ['Business Brain', 'Content Ideation', 'Pillar Page Generator', 'Internal Linking'],
    capabilities: ['Keyword research', 'SERP analysis', 'Competitor tracking', 'Backlink analysis']
  },
  
  // Data Sources Category
  {
    id: 'google-sheets',
    name: 'Google Sheets',
    category: 'data',
    description: 'Sync data to and from spreadsheets for bulk operations',
    logo: '📊',
    status: 'disconnected',
    featured: false,
    component: GoogleSheetsConfig,
    dataFeeds: ['Business Brain', 'Client Intake', 'Editorial Calendar', 'Long-Tail Page Factory'],
    capabilities: ['Bulk data import', 'Content scheduling', 'Data export', 'Custom reports']
  },
  {
    id: 'airtable',
    name: 'Airtable',
    category: 'data',
    description: 'Connect your powerful Airtable bases to WebsiteOS',
    logo: '🖇️',
    status: 'disconnected',
    featured: false,
    component: AirtableConfig,
    dataFeeds: ['Business Brain', 'Client Intake', 'Editorial Calendar', 'All AI Modules'],
    capabilities: ['Structured data sync', 'Content databases', 'Project management', 'CRM integration']
  },
  
  // Automation Category
  {
    id: 'zapier',
    name: 'Zapier',
    category: 'automation',
    description: 'Connect WebsiteOS to thousands of other apps',
    logo: '⚡',
    status: 'disconnected',
    featured: false,
    component: ZapierConfig,
    dataFeeds: ['Agent Orchestra', 'Client Intake', 'Staggered Publisher'],
    capabilities: ['Workflow automation', 'Multi-app connections', 'Event-based triggers']
  }
];

export default function IntegrationsHub() {
  const [integrations, setIntegrations] = useState(integrationsData);
  const [activeTab, setActiveTab] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedIntegration, setSelectedIntegration] = useState(null);

  useEffect(() => {
    // In a real app, you'd fetch integration statuses from the backend
    // For now, we'll just use the initial state
  }, []);

  const handleUpdateIntegration = (id, newStatus, newConfig) => {
    setIntegrations(prev =>
      prev.map(int => (int.id === id ? { ...int, status: newStatus, config: newConfig } : int))
    );
    setSelectedIntegration(null);
  };

  const filteredIntegrations = integrations.filter(
    int =>
      (activeTab === 'all' || int.category === activeTab) &&
      (int.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        int.description.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  const IntegrationCard = ({ integration }) => (
    <motion.div
      layout
      initial={{ opacity: 0, scale: 0.8 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.8 }}
      transition={{ type: 'spring', stiffness: 260, damping: 20 }}
      className="cursor-pointer"
      onClick={() => setSelectedIntegration(integration)}
    >
      <Card className="bg-gray-800 border-gray-700 hover:border-cyan-500/50 transition-colors h-full flex flex-col">
        <CardHeader>
          <div className="flex justify-between items-start">
            <div className="text-3xl">{integration.logo}</div>
            <Badge
              variant={integration.status === 'connected' ? 'default' : 'outline'}
              className={
                integration.status === 'connected'
                  ? 'bg-green-500/20 text-green-400 border-green-500/30'
                  : 'text-gray-400 border-gray-600'
              }
            >
              <div
                className={`w-2 h-2 rounded-full mr-2 ${
                  integration.status === 'connected' ? 'bg-green-500' : 'bg-gray-500'
                }`}
              ></div>
              {integration.status.charAt(0).toUpperCase() + integration.status.slice(1)}
            </Badge>
          </div>
        </CardHeader>
        <CardContent className="flex-grow flex flex-col">
          <h3 className="font-semibold text-white mb-2">{integration.name}</h3>
          <p className="text-sm text-gray-400 flex-grow">{integration.description}</p>
          {integration.featured && (
            <Badge className="mt-4 bg-purple-500/20 text-purple-400 border-purple-500/30 w-fit">
              Featured
            </Badge>
          )}
        </CardContent>
      </Card>
    </motion.div>
  );

  const SelectedComponent = selectedIntegration ? selectedIntegration.component : null;

  return (
    <>
      <ModuleLayout
        title="Integrations Hub"
        status={`${integrations.filter(i => i.status === 'connected').length} of ${integrations.length} Connected`}
        statusColor="bg-blue-500"
        lastUpdated="Live"
        primaryAction={
          <Button className="bg-cyan-600 hover:bg-cyan-700">
            <Plus size={16} className="mr-2" /> Request Integration
          </Button>
        }
        tabs={integrationTabs}
        activeTab={activeTab}
        onTabChange={setActiveTab}
      >
        <div className="space-y-6">
          <Card className="bg-gray-800 border-gray-700">
            <CardContent className="p-6">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <Input
                  placeholder="Search integrations..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 bg-gray-700 border-gray-600 text-white placeholder-gray-500"
                />
              </div>
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            <AnimatePresence>
              {filteredIntegrations.map(integration => (
                <IntegrationCard key={integration.id} integration={integration} />
              ))}
            </AnimatePresence>
          </div>

          {filteredIntegrations.length === 0 && (
            <div className="text-center py-12 text-gray-500">
              <Search className="mx-auto h-12 w-12 text-gray-600" />
              <h3 className="mt-2 text-lg font-medium text-gray-400">No Integrations Found</h3>
              <p className="mt-1 text-sm">Try adjusting your search or filter.</p>
            </div>
          )}
        </div>
      </ModuleLayout>

      <Dialog open={!!selectedIntegration} onOpenChange={() => setSelectedIntegration(null)}>
        <DialogContent className="max-w-4xl max-h-[90vh] bg-gray-900 border-cyan-500/30 p-0 overflow-hidden flex flex-col">
          {selectedIntegration && (
            <>
              <DialogHeader className="p-6 pb-0">
                <DialogTitle className="text-white text-2xl flex items-center gap-4">
                  <span className="text-4xl">{selectedIntegration.logo}</span>
                  <div>
                    Configure {selectedIntegration.name}
                    <p className="text-sm text-gray-400 font-normal mt-1">{selectedIntegration.description}</p>
                  </div>
                </DialogTitle>
              </DialogHeader>
              <div className="flex-grow overflow-y-auto">
                {SelectedComponent && (
                  <SelectedComponent
                    integration={selectedIntegration}
                    onUpdate={handleUpdateIntegration}
                    onCancel={() => setSelectedIntegration(null)}
                  />
                )}
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
}