import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Plus, 
  Settings, 
  ExternalLink,
  Search,
  Filter,
  MoreHorizontal,
  Edit,
  Eye,
  Copy,
  Archive,
  Upload,
  Grid3X3,
  List,
  Image,
  FileText
} from "lucide-react";
import ContentTable from './cms/ContentTable';
import MediaLibrary from './cms/MediaLibrary';
import ContentDrawer from './cms/ContentDrawer';
import { Page } from '@/api/entities';
import { BlogPost } from '@/api/entities';
import { MediaAsset } from '@/api/entities';

const contentTypes = [
  { id: 'pages', label: 'Pages', entity: Page, icon: FileText },
  { id: 'blog-posts', label: 'Blog Posts', entity: BlogPost, icon: FileText },
  { id: 'portfolio', label: 'Portfolio', entity: null, icon: Image },
  { id: 'testimonials', label: 'Testimonials', entity: null, icon: FileText },
  { id: 'team', label: 'Team', entity: null, icon: FileText },
  { id: 'faqs', label: 'FAQs', entity: null, icon: FileText },
  { id: 'resources', label: 'Resources', entity: null, icon: FileText },
];

export default function WebsiteOSCMS() {
  const [activeTab, setActiveTab] = useState('pages');
  const [selectedItem, setSelectedItem] = useState(null);
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');

  const handleItemClick = (item) => {
    setSelectedItem(item);
    setIsDrawerOpen(true);
  };

  const handleCloseDrawer = () => {
    setIsDrawerOpen(false);
    setSelectedItem(null);
  };

  const getContentTypeConfig = () => {
    return contentTypes.find(type => type.id === activeTab);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header - WordPress style admin bar */}
      <header className="bg-white border-b border-gray-200 sticky top-0 z-50">
        <div className="px-6 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-semibold text-gray-900">WebsiteOS CMS</h1>
              <p className="text-sm text-gray-600">Content management · Last updated 2 minutes ago</p>
            </div>
            <div className="flex items-center space-x-3">
              <Button variant="outline" size="sm" className="text-gray-600 border-gray-300">
                <ExternalLink className="w-4 h-4 mr-2" />
                View Site
              </Button>
              <Button variant="outline" size="sm" className="text-gray-600 border-gray-300">
                <Settings className="w-4 h-4 mr-2" />
                Settings
              </Button>
              <Button className="bg-blue-600 hover:bg-blue-700 text-white">
                <Plus className="w-4 h-4 mr-2" />
                New Content
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content Area */}
      <div className="flex">
        <main className="flex-1 px-6 py-6">
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            {/* Content Type Tabs */}
            <TabsList className="grid w-full grid-cols-8 bg-white border border-gray-200 p-1 rounded-lg">
              {contentTypes.map((type) => (
                <TabsTrigger
                  key={type.id}
                  value={type.id}
                  className="data-[state=active]:bg-blue-50 data-[state=active]:text-blue-700 text-gray-600 px-3 py-2 text-sm"
                >
                  <type.icon className="w-4 h-4 mr-1" />
                  {type.label}
                </TabsTrigger>
              ))}
              <TabsTrigger 
                value="media" 
                className="data-[state=active]:bg-blue-50 data-[state=active]:text-blue-700 text-gray-600 px-3 py-2 text-sm"
              >
                <Image className="w-4 h-4 mr-1" />
                Media
              </TabsTrigger>
            </TabsList>

            {/* Content Tables */}
            {contentTypes.map((type) => (
              <TabsContent key={type.id} value={type.id} className="mt-6">
                {type.entity ? (
                  <ContentTable
                    contentType={type}
                    onItemClick={handleItemClick}
                    searchTerm={searchTerm}
                    onSearchChange={setSearchTerm}
                    statusFilter={statusFilter}
                    onStatusFilterChange={setStatusFilter}
                  />
                ) : (
                  <div className="bg-white rounded-lg border border-gray-200 p-12 text-center">
                    <type.icon className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                    <h3 className="text-lg font-medium text-gray-900 mb-2">{type.label} Coming Soon</h3>
                    <p className="text-gray-500 mb-4">This content type is being built.</p>
                    <Button variant="outline" className="text-gray-600 border-gray-300">
                      Learn More
                    </Button>
                  </div>
                )}
              </TabsContent>
            ))}

            {/* Media Library */}
            <TabsContent value="media" className="mt-6">
              <MediaLibrary onItemClick={handleItemClick} />
            </TabsContent>
          </Tabs>
        </main>

        {/* Right Drawer for Content Details */}
        <ContentDrawer
          isOpen={isDrawerOpen}
          onClose={handleCloseDrawer}
          item={selectedItem}
          contentType={getContentTypeConfig()}
        />
      </div>
    </div>
  );
}