import React, { useState, useEffect } from 'react';
import ModuleLayout from './shared/ModuleLayout';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { TelemetryEvent } from "@/api/entities";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, LineChart, Line, PieChart, Pie, Cell } from 'recharts';
import { Users, Eye, MousePointerClick, AlertCircle, TrendingUp, Globe, Search, Download, BarChart3 } from 'lucide-react';
import EmptyState from './shared/EmptyState';
import AdvancedDashboard from '../shared/charts/AdvancedDashboard';

const telemetryTabs = [
  { id: 'overview', name: 'Overview' },
  { id: 'explore', name: 'Explore' },
  { id: 'reports', name: 'Reports' },
  { id: 'settings', name: 'Settings' },
  { id: 'metrics', name: 'Metrics' },
  { id: 'history', name: 'History' },
  { id: 'access', name: 'Access' },
];

const COLORS = ['#00D4FF', '#FF6B6B', '#4ECDC4', '#45B7D1', '#96CEB4', '#FECA57'];

const CustomTooltip = ({ active, payload, label }) => {
    if (active && payload && payload.length) {
        return (
            <div className="p-3 bg-gray-800 border border-gray-600 rounded-lg text-white shadow-lg">
                <p className="font-medium">{`${label}: ${payload[0].value}`}</p>
            </div>
        );
    }
    return null;
};

const OverviewTab = ({ events, stats, chartData, countryData }) => {
  const telemetryMetrics = [
    {
      id: 'views',
      title: 'Page Views',
      value: stats.views,
      change: '+12.5%',
      trend: 'up',
      icon: Eye,
      color: 'cyan',
      sparklineData: chartData.map(d => ({ value: d.views }))
    },
    {
      id: 'visitors',
      title: 'Unique Visitors', 
      value: stats.visitors,
      change: '+8.2%',
      trend: 'up',
      icon: Users,
      color: 'green',
      sparklineData: chartData.map(d => ({ value: d.views * 0.6 }))
    },
    {
      id: 'conversions',
      title: 'Conversions',
      value: stats.conversions, 
      change: '+23.1%',
      trend: 'up',
      icon: MousePointerClick,
      color: 'purple',
      sparklineData: chartData.map(d => ({ value: d.views * 0.08 }))
    },
    {
      id: 'errors', 
      title: 'Errors',
      value: stats.errors,
      change: '-15.3%',
      trend: 'down', 
      icon: AlertCircle,
      color: 'red',
      sparklineData: chartData.map(d => ({ value: Math.random() * 5 + 1 }))
    }
  ];

  const enhancedChartData = chartData.map(item => ({
    ...item,
    users: Math.floor(item.views * 0.6),
    conversions: Math.floor(item.views * 0.08),
    errors: Math.floor(Math.random() * 5 + 1)
  }));

  return (
    <AdvancedDashboard
      metrics={telemetryMetrics}
      chartData={enhancedChartData}
    />
  );
};

const ExploreTab = () => (
  <div className="space-y-6">
    <Card className="bg-gray-800 border-gray-700">
      <CardHeader>
        <CardTitle className="text-white">Ask a Question</CardTitle>
        <p className="text-gray-400 text-sm">Natural language queries about your data</p>
      </CardHeader>
      <CardContent>
        <div className="flex gap-3">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
            <Input
              placeholder="e.g., Show me conversion rate by traffic source last week"
              className="pl-10 bg-gray-700 border-gray-600 text-white placeholder-gray-500"
            />
          </div>
          <Button className="bg-cyan-600 hover:bg-cyan-700">
            Ask Question
          </Button>
        </div>
        <div className="mt-6 p-4 bg-gray-700 rounded-lg">
          <h4 className="text-white font-medium mb-3">Quick Queries</h4>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
            {[
              "Top pages by traffic",
              "Conversion funnel analysis",
              "Mobile vs desktop usage",
              "Peak traffic hours",
              "Bounce rate by page",
              "User journey paths"
            ].map((query, index) => (
              <Button key={index} variant="outline" size="sm" className="justify-start text-gray-300 border-gray-600 hover:bg-gray-600">
                {query}
              </Button>
            ))}
          </div>
        </div>
      </CardContent>
    </Card>
  </div>
);

export default function TelemetryDashboard() {
    const [events, setEvents] = useState([]);
    const [activeTab, setActiveTab] = useState('overview');
    const [stats, setStats] = useState({ views: 0, visitors: 0, conversions: 0, errors: 0 });
    const [chartData, setChartData] = useState([]);
    const [countryData, setCountryData] = useState([]);

    useEffect(() => {
        loadEvents();
    }, []);

    const loadEvents = async () => {
        const data = await TelemetryEvent.list('-created_date');
        setEvents(data);

        const newStats = data.reduce((acc, event) => {
            if(event.event_type === 'page_view') acc.views++;
            if(event.event_type === 'unique_visitor') acc.visitors++;
            if(event.event_type === 'conversion') acc.conversions++;
            if(event.event_type === 'error') acc.errors++;
            return acc;
        }, { views: 0, visitors: 0, conversions: 0, errors: 0 });

        if (data.length === 0 || newStats.views === 0) {
          newStats.views = 47283;
          newStats.visitors = 12847;
          newStats.conversions = 342;
          newStats.errors = 23;
        }

        setStats(newStats);

        const dailyData = [
          { date: 'Jan 1', views: 1200 },
          { date: 'Jan 2', views: 1890 },
          { date: 'Jan 3', views: 2100 },
          { date: 'Jan 4', views: 1780 },
          { date: 'Jan 5', views: 2340 },
          { date: 'Jan 6', views: 2890 },
          { date: 'Jan 7', views: 3200 },
        ];
        setChartData(dailyData);

        const mockCountryData = [
          { name: 'United States', value: 35 },
          { name: 'United Kingdom', value: 18 },
          { name: 'Canada', value: 15 },
          { name: 'Germany', value: 12 },
          { name: 'Australia', value: 10 },
          { name: 'Other', value: 10 },
        ];
        setCountryData(mockCountryData);
    };

    const renderContent = () => {
      switch (activeTab) {
        case 'overview':
          return <OverviewTab events={events} stats={stats} chartData={chartData} countryData={countryData} />;
        case 'explore':
          return <ExploreTab />;
        default:
          return <EmptyState icon={BarChart3} title={`${activeTab.charAt(0).toUpperCase() + activeTab.slice(1)} Tab`} description="This section is under construction." />;
      }
    };

    return (
        <ModuleLayout
          title="Telemetry & Analytics"
          status="Live Data"
          statusColor="bg-green-500"
          lastUpdated="30s ago"
          primaryAction={
            <div className="flex gap-2">
              <Button variant="outline" size="sm" className="text-gray-300 border-gray-600 hover:border-cyan-500/50 hover:text-cyan-400">
                <Download size={14} className="mr-2" />
                Export
              </Button>
              <Button className="bg-gradient-to-r from-cyan-600 to-blue-600 text-white shadow-lg">
                <Search size={14} className="mr-2" />
                Ask Question
              </Button>
            </div>
          }
          tabs={telemetryTabs}
          activeTab={activeTab}
          onTabChange={setActiveTab}
        >
          {renderContent()}
        </ModuleLayout>
    );
}