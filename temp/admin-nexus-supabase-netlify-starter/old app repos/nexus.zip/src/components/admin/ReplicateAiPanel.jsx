import React, { useState } from 'react';
import ModuleLayout from './shared/ModuleLayout';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Slider } from "@/components/ui/slider";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Play, Pause, Download, Settings, DollarSign, Clock, CheckCircle, XCircle, Loader, Eye } from 'lucide-react';
import EmptyState from './shared/EmptyState';

const replicateTabs = [
  { id: 'playground', name: 'Playground' },
  { id: 'models', name: 'Models' },
  { id: 'predictions', name: 'Predictions' },
  { id: 'analytics', name: 'Analytics' },
  { id: 'settings', name: 'Settings' },
];

const mockModels = [
  {
    name: 'stable-diffusion-xl-base-1.0',
    category: 'Image Generation',
    rating: 4.8,
    lastUsed: '2 hours ago',
    costPer: '$0.0055',
    description: 'High-quality image generation from text prompts'
  },
  {
    name: 'llama-2-70b-chat',
    category: 'Text Generation',
    rating: 4.9,
    lastUsed: '5 minutes ago',
    costPer: '$0.0012',
    description: 'Advanced conversational AI model'
  },
  {
    name: 'whisper-large-v3',
    category: 'Audio Processing',
    rating: 4.7,
    lastUsed: '1 day ago',
    costPer: '$0.0008',
    description: 'Speech to text transcription'
  }
];

const mockPredictions = [
  {
    id: 'pred_123abc',
    model: 'stable-diffusion-xl',
    status: 'succeeded',
    cost: 0.0055,
    duration: 12.3,
    created: '2 hours ago',
    prompt: 'A cyberpunk cityscape at sunset'
  },
  {
    id: 'pred_456def',
    model: 'llama-2-70b-chat',
    status: 'processing',
    cost: 0.0024,
    duration: null,
    created: '5 minutes ago',
    prompt: 'Write a product description for...'
  },
  {
    id: 'pred_789ghi',
    model: 'whisper-large-v3',
    status: 'failed',
    cost: 0.0008,
    duration: 3.1,
    created: '1 hour ago',
    prompt: 'Audio file transcription'
  }
];

const PlaygroundTab = () => {
  const [selectedModel, setSelectedModel] = useState('stable-diffusion-xl-base-1.0');
  const [prompt, setPrompt] = useState('');
  const [isRunning, setIsRunning] = useState(false);
  const [steps, setSteps] = useState([50]);
  const [guidance, setGuidance] = useState([7.5]);

  const handleRunPrediction = () => {
    setIsRunning(true);
    // Mock prediction run
    setTimeout(() => {
      setIsRunning(false);
    }, 3000);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      <div className="space-y-6">
        <Card className="bg-gray-800 border-gray-700">
          <CardHeader>
            <CardTitle className="text-white">Model Configuration</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">Model</label>
              <Select value={selectedModel} onValueChange={setSelectedModel}>
                <SelectTrigger className="bg-gray-700 border-gray-600 text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-gray-800 border-gray-600">
                  {mockModels.map(model => (
                    <SelectItem key={model.name} value={model.name} className="text-white focus:bg-gray-700">
                      {model.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">Prompt</label>
              <Textarea
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                placeholder="Describe what you want to generate..."
                className="bg-gray-700 border-gray-600 text-white placeholder-gray-500 h-32 font-mono"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">Steps: {steps[0]}</label>
                <Slider
                  value={steps}
                  onValueChange={setSteps}
                  min={10}
                  max={100}
                  step={1}
                  className="w-full"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">Guidance: {guidance[0]}</label>
                <Slider
                  value={guidance}
                  onValueChange={setGuidance}
                  min={1}
                  max={20}
                  step={0.1}
                  className="w-full"
                />
              </div>
            </div>

            <Button 
              onClick={handleRunPrediction}
              disabled={!prompt || isRunning}
              className="w-full bg-cyan-600 hover:bg-cyan-700 disabled:opacity-50"
            >
              {isRunning ? (
                <>
                  <Loader className="w-4 h-4 mr-2 animate-spin" />
                  Running...
                </>
              ) : (
                <>
                  <Play className="w-4 h-4 mr-2" />
                  Run Prediction
                </>
              )}
            </Button>
          </CardContent>
        </Card>
      </div>

      <div className="space-y-6">
        <Card className="bg-gray-800 border-gray-700">
          <CardHeader>
            <CardTitle className="text-white">Output Preview</CardTitle>
          </CardHeader>
          <CardContent>
            {isRunning ? (
              <div className="flex items-center justify-center h-64 bg-gray-700 rounded-lg">
                <div className="text-center">
                  <Loader className="w-8 h-8 animate-spin text-cyan-500 mx-auto mb-4" />
                  <p className="text-gray-400">Generating your content...</p>
                </div>
              </div>
            ) : (
              <div className="flex items-center justify-center h-64 bg-gray-700 rounded-lg border-2 border-dashed border-gray-600">
                <div className="text-center">
                  <Eye className="w-8 h-8 text-gray-500 mx-auto mb-2" />
                  <p className="text-gray-500">Output will appear here</p>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        <Card className="bg-gray-800 border-gray-700">
          <CardHeader>
            <CardTitle className="text-white">Saved Presets</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {['Creative Images', 'Technical Diagrams', 'Portrait Photography'].map((preset, index) => (
                <Button key={index} variant="outline" className="w-full justify-start text-gray-300 border-gray-600 hover:bg-gray-700">
                  {preset}
                </Button>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

const ModelsTab = () => (
  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
    {mockModels.map((model, index) => (
      <Card key={index} className="bg-gray-800 border-gray-700 hover:border-cyan-500/50 transition-colors">
        <CardHeader>
          <div className="flex items-start justify-between">
            <div>
              <CardTitle className="text-white text-sm">{model.name}</CardTitle>
              <Badge className="mt-2 bg-cyan-500/20 text-cyan-400">{model.category}</Badge>
            </div>
            <div className="text-right text-xs text-gray-400">
              <div>★ {model.rating}</div>
              <div>{model.lastUsed}</div>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <p className="text-gray-400 text-sm mb-4">{model.description}</p>
          <div className="flex items-center justify-between">
            <span className="text-green-400 font-medium">{model.costPer} per run</span>
            <Button size="sm" className="bg-cyan-600 hover:bg-cyan-700">Use Model</Button>
          </div>
        </CardContent>
      </Card>
    ))}
  </div>
);

const PredictionsTab = () => (
  <Card className="bg-gray-800 border-gray-700">
    <CardHeader>
      <div className="flex items-center justify-between">
        <CardTitle className="text-white">Recent Predictions</CardTitle>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" className="text-gray-300 border-gray-600">
            <Download size={14} className="mr-2" />
            Export
          </Button>
          <Button variant="outline" size="sm" className="text-gray-300 border-gray-600">
            Cancel All
          </Button>
        </div>
      </div>
    </CardHeader>
    <CardContent>
      <Table>
        <TableHeader>
          <TableRow className="border-gray-700">
            <TableHead className="text-white">ID</TableHead>
            <TableHead className="text-white">Model</TableHead>
            <TableHead className="text-white">Status</TableHead>
            <TableHead className="text-white">Cost</TableHead>
            <TableHead className="text-white">Duration</TableHead>
            <TableHead className="text-white">Created</TableHead>
            <TableHead></TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {mockPredictions.map(prediction => (
            <TableRow key={prediction.id} className="border-gray-700">
              <TableCell className="font-mono text-cyan-400">{prediction.id}</TableCell>
              <TableCell className="text-gray-300">{prediction.model}</TableCell>
              <TableCell>
                <Badge className={`${
                  prediction.status === 'succeeded' ? 'bg-green-500/20 text-green-400' :
                  prediction.status === 'processing' ? 'bg-yellow-500/20 text-yellow-400' :
                  'bg-red-500/20 text-red-400'
                }`}>
                  {prediction.status === 'succeeded' && <CheckCircle size={12} className="mr-1" />}
                  {prediction.status === 'processing' && <Loader size={12} className="mr-1 animate-spin" />}
                  {prediction.status === 'failed' && <XCircle size={12} className="mr-1" />}
                  {prediction.status}
                </Badge>
              </TableCell>
              <TableCell className="text-gray-300">${prediction.cost.toFixed(4)}</TableCell>
              <TableCell className="text-gray-300">
                {prediction.duration ? `${prediction.duration}s` : '-'}
              </TableCell>
              <TableCell className="text-gray-400">{prediction.created}</TableCell>
              <TableCell className="text-right">
                <Button variant="ghost" size="sm" className="text-gray-400 hover:text-white">
                  <Eye size={14} />
                </Button>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </CardContent>
  </Card>
);

const AnalyticsTab = () => (
  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
    <Card className="bg-gray-800 border-gray-700">
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium text-gray-400">MTD Spend</CardTitle>
        <DollarSign className="h-4 w-4 text-green-400" />
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-bold text-white">$127.43</div>
        <p className="text-xs text-gray-400">Budget: $500/month</p>
      </CardContent>
    </Card>

    <Card className="bg-gray-800 border-gray-700">
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium text-gray-400">Avg Latency</CardTitle>
        <Clock className="h-4 w-4 text-cyan-400" />
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-bold text-white">8.2s</div>
        <p className="text-xs text-green-400">-15% vs last month</p>
      </CardContent>
    </Card>

    <Card className="bg-gray-800 border-gray-700">
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium text-gray-400">Success Rate</CardTitle>
        <CheckCircle className="h-4 w-4 text-green-400" />
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-bold text-white">98.3%</div>
        <p className="text-xs text-green-400">+2.1% vs last month</p>
      </CardContent>
    </Card>

    <Card className="bg-gray-800 border-gray-700">
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium text-gray-400">Total Predictions</CardTitle>
        <Play className="h-4 w-4 text-purple-400" />
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-bold text-white">2,847</div>
        <p className="text-xs text-green-400">+34% vs last month</p>
      </CardContent>
    </Card>
  </div>
);

export default function ReplicateAiPanel() {
    const [activeTab, setActiveTab] = useState('playground');

    const renderContent = () => {
        switch(activeTab) {
            case 'playground': return <PlaygroundTab />;
            case 'models': return <ModelsTab />;
            case 'predictions': return <PredictionsTab />;
            case 'analytics': return <AnalyticsTab />;
            default: return <EmptyState icon={Settings} title={`${activeTab.charAt(0).toUpperCase() + activeTab.slice(1)} Tab`} description="This section is under construction." />;
        }
    };

    return (
        <ModuleLayout
          title="Replicate AI Panel"
          status="$127 MTD Spend"
          statusColor="bg-green-500"
          lastUpdated="Live"
          primaryAction={
            <div className="flex gap-2">
              <Button variant="outline" size="sm" className="text-gray-300 border-gray-600">
                <Settings size={14} className="mr-2" />
                Manage Keys
              </Button>
              <Button className="bg-cyan-600 hover:bg-cyan-700">
                <Play size={14} className="mr-2" />
                Run Prediction
              </Button>
            </div>
          }
          tabs={replicateTabs}
          activeTab={activeTab}
          onTabChange={setActiveTab}
        >
          {renderContent()}
        </ModuleLayout>
    );
}