import React, { useState, useEffect } from 'react';
import { AIPrediction } from '@/api/entities';
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { motion } from "framer-motion";
import { Sparkles, X, Check, Clock } from 'lucide-react';

export default function PredictionsTab() {
    const [predictions, setPredictions] = useState([]);

    useEffect(() => {
        loadPredictions();
    }, []);

    const loadPredictions = async () => {
        const data = await AIPrediction.list("-created_date");
        setPredictions(data);
    };

    const statusBadge = (status) => {
        switch(status) {
            case 'succeeded': return <Badge className="bg-green-500 text-white"><Check size={12} className="mr-1"/> Succeeded</Badge>;
            case 'failed': return <Badge className="bg-red-500 text-white"><X size={12} className="mr-1"/> Failed</Badge>;
            case 'processing': return <Badge className="bg-blue-500 text-white"><Sparkles size={12} className="mr-1 animate-spin"/> Processing</Badge>;
            default: return <Badge variant="secondary"><Clock size={12} className="mr-1"/> {status}</Badge>;
        }
    };

    return (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {predictions.map((p, i) => (
                <motion.div key={p.id} initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} transition={{ delay: i * 0.05 }}>
                    <Card className="bg-gray-800 border-gray-700">
                        <CardContent className="p-4">
                            <img src={p.output_url || "https://via.placeholder.com/512x512.png/000000/FFFFFF?text=No+Preview"} alt="prediction" className="rounded-md mb-4 aspect-square object-cover" />
                            <div className="flex justify-between items-center mb-2">
                                {statusBadge(p.status)}
                                <span className="text-xs text-gray-400">{new Date(p.created_date).toLocaleTimeString()}</span>
                            </div>
                            <p className="text-xs text-gray-400 truncate">{p.prompt}</p>
                            <div className="flex justify-between mt-2 text-xs text-gray-500">
                               <span>Cost: ${p.cost?.toFixed(4)}</span>
                               <span>Time: {p.duration}s</span>
                            </div>
                        </CardContent>
                    </Card>
                </motion.div>
            ))}
        </div>
    );
}