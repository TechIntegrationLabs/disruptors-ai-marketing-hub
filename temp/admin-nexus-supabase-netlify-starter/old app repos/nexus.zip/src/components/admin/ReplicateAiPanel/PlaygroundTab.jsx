import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Slider } from "@/components/ui/slider";
import { Label } from "@/components/ui/label";
import { Card, CardContent } from "@/components/ui/card";
import { Zap, Settings, Sparkles, Image as ImageIcon } from 'lucide-react';
import { AIPrediction } from '@/api/entities';

export default function PlaygroundTab({ models }) {
    const [prompt, setPrompt] = useState('A cyberpunk cityscape at night, with neon signs reflecting on wet streets, flying cars, and towering skyscrapers.');
    const [steps, setSteps] = useState(25);
    const [guidance, setGuidance] = useState(7.5);
    const [isGenerating, setIsGenerating] = useState(false);
    const [generatedImage, setGeneratedImage] = useState(null);

    const handleGenerate = async () => {
        setIsGenerating(true);
        setGeneratedImage(null);
        // Mock generation
        await new Promise(resolve => setTimeout(resolve, 3000));
        await AIPrediction.create({
            model_name: "stable-diffusion",
            prompt: prompt,
            status: "succeeded",
            output_url: "https://via.placeholder.com/512x512.png/000000/00D4FF?text=Generated+Image",
            cost: 0.005,
            duration: 3
        });
        setGeneratedImage("https://via.placeholder.com/512x512.png/000000/00D4FF?text=Generated+Image");
        setIsGenerating(false);
    };

    return (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2">
                <Card className="bg-gray-800 border-gray-700 h-full">
                    <CardContent className="p-6">
                        <div className="flex justify-center items-center bg-gray-900 rounded-lg min-h-[512px]">
                            {isGenerating && <div className="text-white"><Sparkles className="animate-spin mr-2" />Generating...</div>}
                            {generatedImage && !isGenerating && <img src={generatedImage} alt="Generated" className="rounded-lg max-w-full max-h-full" />}
                            {!generatedImage && !isGenerating && <div className="text-gray-500 text-center p-4"><ImageIcon size={48} className="mx-auto mb-2" />Your generated image will appear here.</div>}
                        </div>
                    </CardContent>
                </Card>
            </div>
            <div className="space-y-6">
                <Card className="bg-gray-800 border-gray-700">
                    <CardContent className="p-6 space-y-4">
                        <h3 className="text-lg font-semibold text-white flex items-center gap-2"><Zap size={18}/> Prompt</h3>
                        <Textarea 
                            value={prompt}
                            onChange={(e) => setPrompt(e.target.value)}
                            placeholder="Enter your prompt..." 
                            className="bg-gray-700 text-white border-gray-600 min-h-[150px]"
                        />
                    </CardContent>
                </Card>
                <Card className="bg-gray-800 border-gray-700">
                    <CardContent className="p-6 space-y-6">
                        <h3 className="text-lg font-semibold text-white flex items-center gap-2"><Settings size={18}/> Parameters</h3>
                        <div className="space-y-4">
                            <div>
                                <Label htmlFor="steps" className="text-gray-300">Steps: {steps}</Label>
                                <Slider id="steps" defaultValue={[steps]} max={100} step={1} onValueChange={(val) => setSteps(val[0])} />
                            </div>
                            <div>
                                <Label htmlFor="guidance" className="text-gray-300">Guidance: {guidance}</Label>
                                <Slider id="guidance" defaultValue={[guidance]} max={20} step={0.1} onValueChange={(val) => setGuidance(val[0])} />
                            </div>
                        </div>
                    </CardContent>
                </Card>
                <Button onClick={handleGenerate} disabled={isGenerating} size="lg" className="w-full bg-cyan-600 hover:bg-cyan-700 text-white">
                    {isGenerating ? <Sparkles className="animate-spin mr-2"/> : <Zap className="mr-2" />}
                    Generate
                </Button>
            </div>
        </div>
    );
}