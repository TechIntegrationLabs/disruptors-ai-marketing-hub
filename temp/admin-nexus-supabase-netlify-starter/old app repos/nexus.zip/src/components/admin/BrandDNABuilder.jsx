import React, { useState, useEffect, useCallback } from 'react';
import ModuleLayout from './shared/ModuleLayout';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Slider } from "@/components/ui/slider";
import { 
  Palette, 
  Upload, 
  CheckCircle, 
  Plus,
  X,
  Zap,
  Settings,
  FileJson,
  FileText,
  Type,
  Mic,
  Paintbrush,
  Book,
  Grid,
  Eye,
  Copy
} from "lucide-react";
import { BrandRule } from "@/api/entities";
import { motion } from 'framer-motion';

const brandDNATabs = [
    { id: 'overview', name: 'Overview' },
    { id: 'voice', name: 'Voice & Tone' },
    { id: 'visuals', name: 'Visuals' },
    { id: 'rules', name: 'Rules & Examples' },
    { id: 'snapshot', name: 'DNA Snapshot' },
];

const OverviewTab = ({ brandData, setBrandData }) => (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
            <Card className="bg-gray-800 border-gray-700">
                <CardHeader>
                    <CardTitle className="text-white">Brand Summary</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                    <div>
                        <label className="block text-sm font-medium text-gray-400 mb-2">Brand Pitch (One Line)</label>
                        <Input
                            placeholder="What we do in one sentence"
                            value={brandData.brand_pitch || ''}
                            onChange={(e) => setBrandData({...brandData, brand_pitch: e.target.value})}
                            className="bg-gray-700 border-gray-600 text-white"
                        />
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-gray-400 mb-2">Target Audience</label>
                        <Input
                            placeholder="A short description of who we're for"
                            value={brandData.target_audience || ''}
                            onChange={(e) => setBrandData({...brandData, target_audience: e.target.value})}
                            className="bg-gray-700 border-gray-600 text-white"
                        />
                    </div>
                </CardContent>
            </Card>
        </div>
        <div className="space-y-6">
            <Card className="bg-gray-800 border-gray-700">
                <CardHeader>
                    <CardTitle className="text-white text-base">Quick View</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                    <div className="flex flex-wrap gap-2">
                        <span className="text-sm text-gray-400 mr-2">Voice:</span>
                        {(brandData.voice_keywords || []).slice(0, 3).map((keyword, index) => (
                            <Badge key={index} variant="secondary" className="bg-purple-500/20 text-purple-300">{keyword}</Badge>
                        ))}
                    </div>
                    <div className="flex items-center gap-2">
                        <span className="text-sm text-gray-400 mr-2">Colors:</span>
                        {(brandData.primary_colors || []).slice(0, 4).map((color, index) => (
                            <div key={index} className="w-6 h-6 rounded-full border-2 border-gray-600" style={{ backgroundColor: color.hex }} title={color.name}></div>
                        ))}
                    </div>
                </CardContent>
            </Card>
            <Button className="w-full bg-cyan-600 hover:bg-cyan-700">
                <CheckCircle size={16} className="mr-2" />
                Audit Page against DNA
            </Button>
        </div>
    </div>
);

const VoiceToneTab = ({ brandData, setBrandData }) => {
    const addVoiceKeyword = (keyword) => {
        const keywords = brandData.voice_keywords || [];
        if (keyword && !keywords.includes(keyword)) {
            setBrandData({ ...brandData, voice_keywords: [...keywords, keyword] });
        }
    };

    const removeVoiceKeyword = (index) => {
        const keywords = brandData.voice_keywords || [];
        setBrandData({ ...brandData, voice_keywords: keywords.filter((_, i) => i !== index) });
    };

    return (
        <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <Card className="bg-gray-800 border-gray-700">
                    <CardHeader>
                        <CardTitle className="text-white">Core Messaging</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                        <div>
                            <label className="text-sm font-medium text-gray-400 mb-2 block">How we introduce ourselves?</label>
                            <Input value={brandData.voice_oneliner || ''} onChange={(e) => setBrandData({...brandData, voice_oneliner: e.target.value})} placeholder="e.g., We help small businesses grow online" className="bg-gray-700 border-gray-600 text-white" />
                        </div>
                        <div>
                            <label className="text-sm font-medium text-gray-400 mb-2 block">30-second pitch</label>
                            <Textarea value={brandData.thirty_second_pitch || ''} onChange={(e) => setBrandData({...brandData, thirty_second_pitch: e.target.value})} placeholder="Your elevator pitch" className="bg-gray-700 border-gray-600 text-white h-24" />
                        </div>
                    </CardContent>
                </Card>
                <Card className="bg-gray-800 border-gray-700">
                    <CardHeader>
                        <CardTitle className="text-white">Voice Keywords</CardTitle>
                        <p className="text-sm text-gray-500">Words people should use to describe your brand.</p>
                    </CardHeader>
                    <CardContent>
                        <div className="flex flex-wrap gap-2 mb-3">
                            {(brandData.voice_keywords || []).map((keyword, index) => (
                                <Badge key={index} variant="secondary" className="bg-purple-500/20 text-purple-300 cursor-pointer" onClick={() => removeVoiceKeyword(index)}>
                                    {keyword}
                                    <X className="w-3 h-3 ml-1" />
                                </Badge>
                            ))}
                        </div>
                        <Input
                            placeholder="Add word (press Enter)"
                            onKeyPress={(e) => {
                                if (e.key === 'Enter' && e.target.value.trim()) {
                                    addVoiceKeyword(e.target.value.trim());
                                    e.target.value = '';
                                }
                            }}
                            className="bg-gray-700 border-gray-600 text-white"
                        />
                    </CardContent>
                </Card>
            </div>
        </div>
    );
};

const VisualsTab = ({ brandData, setBrandData }) => (
    <Card className="bg-gray-800 border-gray-700">
      <CardHeader>
        <CardTitle className="text-white">Visual Identity</CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
                <h3 className="text-lg font-semibold text-gray-300 mb-3">Main Colors</h3>
                <div className="flex flex-wrap gap-4">
                {(brandData.primary_colors || []).map((color, index) => (
                    <div key={index} className="flex items-center gap-2">
                        <div className="w-8 h-8 rounded-full border-2 border-gray-600" style={{ backgroundColor: color.hex }}></div>
                        <div>
                            <p className="text-white font-medium text-sm">{color.name}</p>
                            <p className="text-gray-400 font-mono text-xs">{color.hex}</p>
                        </div>
                    </div>
                ))}
                </div>
            </div>
            <div>
                <h3 className="text-lg font-semibold text-gray-300 mb-3">Main Fonts</h3>
                <div className="space-y-2">
                    <div>
                        <p className="text-sm text-gray-400">Heading</p>
                        <p className="font-semibold text-white text-lg">{brandData.fonts?.heading || 'Not set'}</p>
                    </div>
                    <div>
                        <p className="text-sm text-gray-400">Body</p>
                        <p className="text-white text-lg">{brandData.fonts?.body || 'Not set'}</p>
                    </div>
                </div>
            </div>
        </div>
        <div>
            <h3 className="text-lg font-semibold text-gray-300 mb-3">Logos</h3>
            <div className="grid grid-cols-3 gap-4 p-4 bg-gray-900/50 rounded-lg">
                <div className="text-center">
                    <p className="text-sm text-gray-400 mb-2">Dark</p>
                    <div className="bg-white p-4 rounded-md flex items-center justify-center">
                        <img src={brandData.logo_urls?.dark} alt="Dark Logo" className="h-12"/>
                    </div>
                </div>
                <div className="text-center">
                    <p className="text-sm text-gray-400 mb-2">Light</p>
                    <div className="bg-black p-4 rounded-md flex items-center justify-center">
                        <img src={brandData.logo_urls?.light} alt="Light Logo" className="h-12"/>
                    </div>
                </div>
                <div className="text-center">
                    <p className="text-sm text-gray-400 mb-2">Mono</p>
                    <div className="bg-gray-500 p-4 rounded-md flex items-center justify-center">
                        <img src={brandData.logo_urls?.mono} alt="Mono Logo" className="h-12"/>
                    </div>
                </div>
            </div>
        </div>
      </CardContent>
    </Card>
);

const RulesTab = ({ brandData, setBrandData }) => (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card className="bg-green-500/10 border-green-500/30">
            <CardHeader>
                <CardTitle className="text-green-300">We Are (Do's)</CardTitle>
            </CardHeader>
            <CardContent>
                <ul className="list-disc list-inside space-y-2 text-green-200">
                    {(brandData.we_are || []).map((item, index) => (<li key={index}>{item}</li>))}
                </ul>
            </CardContent>
        </Card>
        <Card className="bg-red-500/10 border-red-500/30">
            <CardHeader>
                <CardTitle className="text-red-300">We Are Not (Don'ts)</CardTitle>
            </CardHeader>
            <CardContent>
                <ul className="list-disc list-inside space-y-2 text-red-200">
                     {(brandData.we_are_not || []).map((item, index) => (<li key={index}>{item}</li>))}
                </ul>
            </CardContent>
        </Card>
    </div>
);

const DnaSnapshotTab = ({ brandData }) => {
    const downloadJSON = () => {
        const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(brandData, null, 2));
        const downloadAnchorNode = document.createElement('a');
        downloadAnchorNode.setAttribute("href", dataStr);
        downloadAnchorNode.setAttribute("download", "brand_dna_snapshot.json");
        document.body.appendChild(downloadAnchorNode);
        downloadAnchorNode.click();
        downloadAnchorNode.remove();
    };
    
    const downloadPDF = () => { alert("PDF download functionality coming soon!"); };

    return (
        <Card className="bg-gray-800 border-gray-700">
            <CardHeader className="flex flex-row items-center justify-between">
                <div>
                    <CardTitle className="text-white">Brand DNA Snapshot</CardTitle>
                    <p className="text-gray-400 text-sm">A complete, at-a-glance view of your entire brand identity.</p>
                </div>
                <div className="flex gap-2">
                    <Button variant="outline" className="text-gray-300 border-gray-600" onClick={downloadJSON}><FileJson size={16} className="mr-2" /> Download JSON</Button>
                    <Button variant="outline" className="text-gray-300 border-gray-600" onClick={downloadPDF}><FileText size={16} className="mr-2" /> Download PDF</Button>
                </div>
            </CardHeader>
            <CardContent className="space-y-8 p-8">
                 {/* Core Messaging */}
                <div className="space-y-4">
                    <h3 className="text-xl font-semibold text-cyan-400 border-b border-cyan-500/30 pb-2">Core Messaging</h3>
                    <div className="grid grid-cols-2 gap-x-8">
                        <p><strong className="text-gray-400 font-medium">Pitch:</strong> <span className="text-white">{brandData.brand_pitch}</span></p>
                        <p><strong className="text-gray-400 font-medium">Audience:</strong> <span className="text-white">{brandData.target_audience}</span></p>
                    </div>
                </div>
                {/* Voice & Tone */}
                <div className="space-y-4">
                    <h3 className="text-xl font-semibold text-cyan-400 border-b border-cyan-500/30 pb-2">Voice & Tone</h3>
                    <div className="flex gap-2">
                        {(brandData.voice_keywords || []).map(kw => <Badge key={kw} className="bg-purple-500/20 text-purple-300">{kw}</Badge>)}
                    </div>
                </div>
                 {/* Visuals */}
                <div className="space-y-4">
                    <h3 className="text-xl font-semibold text-cyan-400 border-b border-cyan-500/30 pb-2">Visuals</h3>
                    <div className="flex gap-8">
                      <div>
                        <h4 className="text-gray-400 mb-2">Colors</h4>
                        <div className="flex gap-2">
                            {(brandData.primary_colors || []).map(c => <div key={c.hex} className="w-10 h-10 rounded-full border-2 border-gray-600" style={{backgroundColor: c.hex}} title={c.name} />)}
                        </div>
                      </div>
                       <div>
                        <h4 className="text-gray-400 mb-2">Fonts</h4>
                        <p><strong className="font-medium">H:</strong> <span className="text-white">{brandData.fonts?.heading}</span></p>
                        <p><strong className="font-medium">B:</strong> <span className="text-white">{brandData.fonts?.body}</span></p>
                      </div>
                    </div>
                </div>
            </CardContent>
        </Card>
    );
};

export default function BrandDNABuilder() {
    const [brandData, setBrandData] = useState({});
    const [activeTab, setActiveTab] = useState('overview');
    
    const loadBrandData = async () => {
        try {
            const data = await BrandRule.list(); 
            if (data.length > 0) {
                setBrandData(data[0]);
            } else {
                setBrandData({
                    brand_pitch: 'The all-in-one AI Marketing Platform.',
                    target_audience: 'Marketing agencies and SMBs',
                    voice_keywords: ['Authoritative', 'Innovative', 'Clear'],
                    primary_colors: [
                        { name: 'Cyan', hex: '#00D4FF' },
                        { name: 'Blue', hex: '#3B82F6' },
                        { name: 'Green', hex: '#10B981' },
                        { name: 'Dark', hex: '#111827' }
                    ],
                    fonts: { heading: 'Inter', body: 'Roboto' },
                    logo_urls: { dark: 'https://via.placeholder.com/150/000000/FFFFFF/?text=LOGO', light: 'https://via.placeholder.com/150/FFFFFF/000000/?text=LOGO', mono: 'https://via.placeholder.com/150/808080/FFFFFF/?text=LOGO' },
                    we_are: ['Data-driven', 'User-centric', 'Automated'],
                    we_are_not: ['Complicated', 'Manual', 'Guesswork']
                });
            }
        } catch (error) {
            console.error('Error loading brand data:', error);
        }
    };

    useEffect(() => {
        loadBrandData();
    }, []);

    const saveBrandData = useCallback(async () => {
        try {
            if (brandData.id) {
                await BrandRule.update(brandData.id, brandData);
            } else if (Object.keys(brandData).length > 1) { // Prevent saving empty object on init
                const created = await BrandRule.create(brandData);
                setBrandData(created);
            }
        } catch (error) {
            console.error('Error saving brand data:', error);
        }
    }, [brandData]);

    useEffect(() => {
        const saveTimer = setTimeout(() => { saveBrandData(); }, 1000);
        return () => clearTimeout(saveTimer);
    }, [brandData, saveBrandData]);

    const renderTabContent = () => {
        switch (activeTab) {
            case 'overview': return <OverviewTab brandData={brandData} setBrandData={setBrandData} />;
            case 'voice': return <VoiceToneTab brandData={brandData} setBrandData={setBrandData} />;
            case 'visuals': return <VisualsTab brandData={brandData} setBrandData={setBrandData} />;
            case 'rules': return <RulesTab brandData={brandData} setBrandData={setBrandData} />;
            case 'snapshot': return <DnaSnapshotTab brandData={brandData} />;
            default: return null;
        }
    };

    return (
        <ModuleLayout
            title="Brand DNA"
            status={`78% Complete`}
            statusColor="bg-purple-500"
            lastUpdated="2 weeks ago"
            primaryAction={<Button className="bg-purple-600 hover:bg-purple-700"><Plus size={16} className="mr-2" /> Add Pillar</Button>}
            tabs={brandDNATabs}
            activeTab={activeTab}
            onTabChange={setActiveTab}
        >
            {renderTabContent()}
        </ModuleLayout>
    );
}