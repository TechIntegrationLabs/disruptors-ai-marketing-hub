import React, { useState } from 'react';
import ModuleLayout from './shared/ModuleLayout';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Shield, Plus, Eye, Settings, Activity, CheckCircle, AlertTriangle, Users, Brain, Zap } from 'lucide-react';
import EmptyState from './shared/EmptyState';

const subAgentTabs = [
  { id: 'overview', name: 'Overview' },
  { id: 'agents', name: 'Agents' },
  { id: 'guardrails', name: 'Guardrails' },
  { id: 'settings', name: 'Settings' },
  { id: 'metrics', name: 'Metrics' },
  { id: 'history', name: 'History' },
  { id: 'access', name: 'Access' },
];

const mockSubAgents = [
  {
    id: 'agent_001',
    name: 'Content Reviewer',
    type: 'Quality Assurance',
    status: 'active',
    confidence: 94.2,
    tasksCompleted: 1247,
    lastActive: '5 minutes ago',
    specialization: 'Content quality and brand compliance checking'
  },
  {
    id: 'agent_002',
    name: 'SEO Optimizer',
    type: 'Content Enhancement',
    status: 'active',
    confidence: 97.8,
    tasksCompleted: 834,
    lastActive: '12 minutes ago',
    specialization: 'SEO analysis and content optimization'
  },
  {
    id: 'agent_003',
    name: 'Data Analyst',
    type: 'Analytics',
    status: 'training',
    confidence: 78.3,
    tasksCompleted: 234,
    lastActive: '2 hours ago',
    specialization: 'Data processing and insight generation'
  },
  {
    id: 'agent_004',
    name: 'Customer Support',
    type: 'Communication',
    status: 'paused',
    confidence: 91.5,
    tasksCompleted: 2156,
    lastActive: '1 day ago',
    specialization: 'Customer inquiry handling and response generation'
  }
];

const mockGuardrails = [
  {
    id: 'guard_001',
    name: 'Brand Safety',
    description: 'Ensures all content adheres to brand guidelines and voice',
    type: 'Content',
    status: 'active',
    violations: 2,
    lastTriggered: '3 hours ago'
  },
  {
    id: 'guard_002',
    name: 'Data Privacy',
    description: 'Prevents sharing of sensitive customer information',
    type: 'Security',
    status: 'active',
    violations: 0,
    lastTriggered: 'Never'
  },
  {
    id: 'guard_003',
    name: 'Quality Threshold',
    description: 'Blocks content below 85% quality score',
    type: 'Quality',
    status: 'active',
    violations: 7,
    lastTriggered: '1 hour ago'
  }
];

const OverviewTab = () => (
  <div className="space-y-6">
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      <Card className="bg-gray-800 border-gray-700">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium text-gray-400">Total Agents</CardTitle>
          <Shield className="h-4 w-4 text-cyan-400" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold text-white">4</div>
          <p className="text-xs text-green-400">2 active, 1 training</p>
        </CardContent>
      </Card>

      <Card className="bg-gray-800 border-gray-700">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium text-gray-400">Avg Confidence</CardTitle>
          <Brain className="h-4 w-4 text-green-400" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold text-white">90.5%</div>
          <p className="text-xs text-green-400">+3.2% vs last week</p>
        </CardContent>
      </Card>

      <Card className="bg-gray-800 border-gray-700">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium text-gray-400">Tasks Completed</CardTitle>
          <Activity className="h-4 w-4 text-purple-400" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold text-white">4,471</div>
          <p className="text-xs text-gray-400">This month</p>
        </CardContent>
      </Card>

      <Card className="bg-gray-800 border-gray-700">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium text-gray-400">Guardrail Violations</CardTitle>
          <AlertTriangle className="h-4 w-4 text-yellow-400" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold text-white">9</div>
          <p className="text-xs text-green-400">-23% vs last week</p>
        </CardContent>
      </Card>
    </div>

    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      <Card className="bg-gray-800 border-gray-700">
        <CardHeader>
          <CardTitle className="text-white">Active Sub-Agents</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {mockSubAgents.slice(0, 3).map(agent => (
              <div key={agent.id} className="flex items-center justify-between p-3 bg-gray-700 rounded-lg">
                <div className="flex items-center space-x-3">
                  <div className="p-2 bg-cyan-600 rounded-lg">
                    <Shield className="w-4 h-4 text-white" />
                  </div>
                  <div>
                    <h4 className="font-medium text-white">{agent.name}</h4>
                    <p className="text-xs text-gray-400">{agent.type}</p>
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-sm font-medium text-white">{agent.confidence}%</div>
                  <div className="text-xs text-gray-400">{agent.lastActive}</div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <Card className="bg-gray-800 border-gray-700">
        <CardHeader>
          <CardTitle className="text-white">Recent Guardrail Activity</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {mockGuardrails.map(guardrail => (
              <div key={guardrail.id} className="flex items-center justify-between p-3 bg-gray-700 rounded-lg">
                <div>
                  <h4 className="font-medium text-white">{guardrail.name}</h4>
                  <p className="text-xs text-gray-400">{guardrail.type}</p>
                </div>
                <div className="text-right">
                  <Badge className={guardrail.violations > 0 ? 'bg-yellow-500/20 text-yellow-400' : 'bg-green-500/20 text-green-400'}>
                    {guardrail.violations} violations
                  </Badge>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  </div>
);

const AgentsTab = () => (
  <Card className="bg-gray-800 border-gray-700">
    <CardHeader>
      <div className="flex items-center justify-between">
        <CardTitle className="text-white">Sub-Agents</CardTitle>
        <Button className="bg-cyan-600 hover:bg-cyan-700">
          <Plus size={16} className="mr-2" />
          Create Agent
        </Button>
      </div>
    </CardHeader>
    <CardContent>
      <Table>
        <TableHeader>
          <TableRow className="border-gray-700">
            <TableHead className="text-white">Agent</TableHead>
            <TableHead className="text-white">Type</TableHead>
            <TableHead className="text-white">Status</TableHead>
            <TableHead className="text-white">Confidence</TableHead>
            <TableHead className="text-white">Tasks</TableHead>
            <TableHead className="text-white">Last Active</TableHead>
            <TableHead></TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {mockSubAgents.map(agent => (
            <TableRow key={agent.id} className="border-gray-700">
              <TableCell>
                <div>
                  <div className="font-medium text-white">{agent.name}</div>
                  <div className="text-xs text-gray-400 mt-1">{agent.specialization}</div>
                </div>
              </TableCell>
              <TableCell className="text-gray-300">{agent.type}</TableCell>
              <TableCell>
                <Badge className={`${
                  agent.status === 'active' ? 'bg-green-500/20 text-green-400' :
                  agent.status === 'training' ? 'bg-yellow-500/20 text-yellow-400' :
                  'bg-gray-500/20 text-gray-400'
                }`}>
                  {agent.status === 'active' && <CheckCircle size={12} className="mr-1" />}
                  {agent.status === 'training' && <Activity size={12} className="mr-1 animate-pulse" />}
                  {agent.status}
                </Badge>
              </TableCell>
              <TableCell className="text-gray-300">{agent.confidence}%</TableCell>
              <TableCell className="text-gray-300">{agent.tasksCompleted}</TableCell>
              <TableCell className="text-gray-400">{agent.lastActive}</TableCell>
              <TableCell className="text-right">
                <div className="flex items-center gap-1">
                  <Button size="sm" variant="ghost" className="text-gray-400 hover:text-white">
                    <Eye size={14} />
                  </Button>
                  <Button size="sm" variant="ghost" className="text-gray-400 hover:text-white">
                    <Settings size={14} />
                  </Button>
                </div>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </CardContent>
  </Card>
);

const GuardrailsTab = () => (
  <div className="space-y-6">
    <Card className="bg-gray-800 border-gray-700">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="text-white">Active Guardrails</CardTitle>
            <p className="text-gray-400 text-sm mt-1">Safety rules and quality controls for your agents</p>
          </div>
          <Button className="bg-cyan-600 hover:bg-cyan-700">
            <Plus size={16} className="mr-2" />
            New Guardrail
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {mockGuardrails.map(guardrail => (
            <Card key={guardrail.id} className="bg-gray-700 border-gray-600">
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between">
                  <div>
                    <CardTitle className="text-white text-sm">{guardrail.name}</CardTitle>
                    <Badge className="mt-2 bg-blue-500/20 text-blue-400">{guardrail.type}</Badge>
                  </div>
                  <Badge className={guardrail.status === 'active' ? 'bg-green-500/20 text-green-400' : 'bg-gray-500/20 text-gray-400'}>
                    {guardrail.status}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-gray-400 text-sm mb-4">{guardrail.description}</p>
                <div className="space-y-2 text-xs">
                  <div className="flex justify-between">
                    <span className="text-gray-400">Violations:</span>
                    <span className={guardrail.violations > 0 ? 'text-yellow-400' : 'text-green-400'}>
                      {guardrail.violations}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Last Triggered:</span>
                    <span className="text-gray-300">{guardrail.lastTriggered}</span>
                  </div>
                </div>
                <div className="flex justify-between mt-4">
                  <Button size="sm" variant="outline" className="border-gray-600 text-gray-300">
                    Configure
                  </Button>
                  <Button size="sm" variant="ghost" className="text-gray-400 hover:text-white">
                    <Eye size={14} />
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </CardContent>
    </Card>
  </div>
);

export default function SubAgentManagement() {
  const [activeTab, setActiveTab] = useState('overview');

  const renderContent = () => {
    switch (activeTab) {
      case 'overview':
        return <OverviewTab />;
      case 'agents':
        return <AgentsTab />;
      case 'guardrails':
        return <GuardrailsTab />;
      default:
        return <EmptyState icon={Shield} title={`${activeTab.charAt(0).toUpperCase() + activeTab.slice(1)} Tab`} description="This section is under construction." />;
    }
  };

  return (
    <ModuleLayout
      title="Sub-Agent Management"
      status="4 Agents Active"
      statusColor="bg-green-500"
      lastUpdated="Live"
      primaryAction={
        <div className="flex gap-2">
          <Button variant="outline" size="sm" className="text-gray-300 border-gray-600">
            <Settings size={14} className="mr-2" />
            Configure
          </Button>
          <Button className="bg-cyan-600 hover:bg-cyan-700">
            <Plus size={14} className="mr-2" />
            New Agent
          </Button>
        </div>
      }
      tabs={subAgentTabs}
      activeTab={activeTab}
      onTabChange={setActiveTab}
    >
      {renderContent()}
    </ModuleLayout>
  );
}