import React, { useState, useEffect } from 'react';
import ModuleLayout from './shared/ModuleLayout';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Brain, Upload, Search, BarChart2, Zap, FileJson, FileText, CheckCircle, Package, Plus } from "lucide-react";
import { BrainFact } from "@/api/entities";
import { Integration } from "@/api/entities";
import AdvancedDashboard from '../shared/charts/AdvancedDashboard';
import { motion } from 'framer-motion';

const businessBrainTabs = [
  { id: 'sources', name: 'Knowledge Sources' },
  { id: 'explorer', name: 'Fact Explorer' },
  { id: 'analytics', name: 'Analytics' },
  { id: 'snapshot', name: 'Brain Snapshot' },
];

const factCategories = ["Overview", "Offers", "ICP", "FAQ", "Proof", "Compliance", "Lexicon", "Competitors", "Policies"];

const KnowledgeSourcesTab = ({ integrations }) => (
  <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
    <div className="lg:col-span-2 space-y-6">
      <Card className="bg-gray-800 border-gray-700">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2"><Zap /> Connected Integrations</CardTitle>
          <p className="text-sm text-gray-400">Manage data feeds from your connected apps.</p>
        </CardHeader>
        <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {integrations.filter(i => i.status === 'connected').map(integration => (
            <Card key={integration.id} className="bg-gray-700/50 border-gray-600">
              <CardContent className="p-4 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <img src={integration.logo_url} alt={integration.name} className="h-8 w-8" />
                  <div>
                    <h3 className="font-semibold text-white text-sm">{integration.name}</h3>
                    <Badge variant="outline" className="text-green-400 border-green-500/50 text-xs mt-1">
                      <CheckCircle size={12} className="mr-1" /> Connected
                    </Badge>
                  </div>
                </div>
                <Button size="sm" variant="outline" className="text-gray-300 border-gray-600">Configure</Button>
              </CardContent>
            </Card>
          ))}
          {integrations.filter(i => i.status === 'connected').length === 0 && (
             <p className="text-gray-500 p-4 col-span-2">No integrations connected. Visit the Integrations Hub to add sources.</p>
          )}
        </CardContent>
      </Card>
    </div>
    <div className="space-y-8">
      <Card className="bg-gray-800 border-gray-700">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2"><Upload /> Manual Upload</CardTitle>
          <p className="text-sm text-gray-400">Add documents directly to the brain.</p>
        </CardHeader>
        <CardContent className="flex flex-col items-center text-center p-6">
            <div className="p-3 bg-gray-700 rounded-full mb-4 border border-gray-600">
                <Upload className="w-8 h-8 text-cyan-400" />
            </div>
            <p className="text-gray-400 mt-2 max-w-md mx-auto text-sm">
                Drop in PDFs, Word docs, or spreadsheets. We'll scan them, pull out the key info, and add it to your Business Brain.
            </p>
            <Button className="mt-6 bg-cyan-600 hover:bg-cyan-700">Upload File</Button>
            <p className="text-xs text-gray-500 mt-3">Your files are processed securely.</p>
        </CardContent>
      </Card>
    </div>
  </div>
);

const FactExplorerTab = ({ facts }) => (
    <Card className="bg-gray-800 border-gray-700">
        <CardHeader>
            <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={20} />
                <Input placeholder="Ask a question, find a fact..." className="pl-10 text-base bg-gray-700 border-gray-600 text-white" />
            </div>
            <div className="flex flex-wrap gap-2 pt-4">
                {factCategories.map(cat => <Button key={cat} variant="outline" size="sm" className="text-gray-300 border-gray-600 hover:bg-gray-700">{cat}</Button>)}
            </div>
        </CardHeader>
        <CardContent>
            <div className="border border-gray-700 rounded-lg max-h-[600px] overflow-y-auto">
                <div className="divide-y divide-gray-700">
                    {facts.map(fact => (
                        <motion.div 
                          key={fact.id} 
                          className="p-4 hover:bg-gray-700/50"
                          initial={{ opacity: 0, x: -10 }}
                          animate={{ opacity: 1, x: 0 }}
                          transition={{ duration: 0.3 }}
                        >
                            <p className="text-white">{fact.content}</p>
                            <div className="flex items-center justify-between mt-2 text-sm">
                                <div className="flex items-center gap-4">
                                    <Badge variant="secondary" className="bg-blue-500/20 text-blue-300">{fact.category}</Badge>
                                    <span className="text-gray-500 flex items-center gap-1"><Package size={14}/> {fact.source_document}</span>
                                </div>
                                <div className="flex items-center gap-2 text-gray-400">
                                    <span>Confidence:</span>
                                    <div className="w-20 h-2 bg-gray-600 rounded-full">
                                        <div className="h-2 bg-cyan-400 rounded-full" style={{ width: `${fact.confidence_score * 100}%` }}></div>
                                    </div>
                                    <span>{(fact.confidence_score * 100).toFixed(0)}%</span>
                                </div>
                            </div>
                        </motion.div>
                    ))}
                </div>
            </div>
        </CardContent>
    </Card>
);

const AnalyticsTab = () => {
  const analyticsData = [
    { name: 'Jan', coverage: 40, facts: 2400 },
    { name: 'Feb', coverage: 55, facts: 3398 },
    { name: 'Mar', coverage: 62, facts: 5200 },
    { name: 'Apr', coverage: 78, facts: 7800 },
    { name: 'May', coverage: 82, facts: 9800 },
    { name: 'Jun', coverage: 88, facts: 12890 },
  ];
  const metrics = [
    { id: 'facts', title: 'Total Facts', value: '12,890', change: '+310', trend: 'up', icon: Brain, color: 'cyan', sparklineData: analyticsData.map(d => ({ value: d.facts }))},
    { id: 'coverage', title: 'Knowledge Coverage', value: '88%', change: '+1.2%', trend: 'up', icon: CheckCircle, color: 'green', sparklineData: analyticsData.map(d => ({ value: d.coverage }))},
    { id: 'sources', title: 'Data Sources', value: '7', change: '+1', trend: 'up', icon: Zap, color: 'blue', sparklineData: [{value:2},{value:3},{value:4},{value:5},{value:6},{value:7}]},
    { id: 'queries', title: 'Queries Last 7d', value: '1,204', change: '+15%', trend: 'up', icon: Search, color: 'purple', sparklineData: [{value:800},{value:950},{value:900},{value:1100},{value:1050},{value:1204}]}
  ];
  const enhancedChartData = analyticsData.map(item => ({...item, 'Coverage %': item.coverage, 'Facts Stored': item.facts}));

  return <AdvancedDashboard metrics={metrics} chartData={enhancedChartData} />;
};

const BrainSnapshotTab = ({ facts }) => {
  const downloadJSON = () => {
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(facts, null, 2));
    const downloadAnchorNode = document.createElement('a');
    downloadAnchorNode.setAttribute("href", dataStr);
    downloadAnchorNode.setAttribute("download", "business_brain_snapshot.json");
    document.body.appendChild(downloadAnchorNode);
    downloadAnchorNode.click();
    downloadAnchorNode.remove();
  };
  
  const downloadPDF = () => {
    alert("PDF download functionality coming soon!");
  };

  const groupedFacts = facts.reduce((acc, fact) => {
    if (!acc[fact.category]) {
      acc[fact.category] = [];
    }
    acc[fact.category].push(fact);
    return acc;
  }, {});

  return (
    <Card className="bg-gray-800 border-gray-700">
      <CardHeader className="flex flex-row items-center justify-between">
        <div>
          <CardTitle className="text-white">Business Brain Snapshot</CardTitle>
          <p className="text-gray-400 text-sm">A complete, categorized view of all knowledge currently in the brain.</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" className="text-gray-300 border-gray-600" onClick={downloadJSON}><FileJson size={16} className="mr-2" /> Download JSON</Button>
          <Button variant="outline" className="text-gray-300 border-gray-600" onClick={downloadPDF}><FileText size={16} className="mr-2" /> Download PDF</Button>
        </div>
      </CardHeader>
      <CardContent className="space-y-6">
        {Object.entries(groupedFacts).map(([category, factsInCategory]) => (
          <motion.div key={category} initial={{opacity:0}} animate={{opacity:1}} transition={{delay:0.2}}>
            <Card className="bg-gray-900/50 border-gray-700">
              <CardHeader>
                <CardTitle className="text-cyan-400 text-lg">{category}</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="list-disc list-inside space-y-2">
                  {factsInCategory.map(fact => (
                    <li key={fact.id} className="text-white">{fact.content} <span className="text-gray-500 text-xs">- Source: {fact.source_document}</span></li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </CardContent>
    </Card>
  );
};

export default function BusinessBrainBuilder() {
    const [facts, setFacts] = useState([]);
    const [integrations, setIntegrations] = useState([]);
    const [activeTab, setActiveTab] = useState('sources');
    
    useEffect(() => {
        const loadData = async () => {
            const brainFacts = await BrainFact.list();
            const integrationData = await Integration.list();
            setFacts(brainFacts.length > 0 ? brainFacts : [
              { id: '1', content: 'We are a leading AI-powered marketing automation platform.', category: 'Overview', source_document: 'Website Homepage', confidence_score: 0.98 },
              { id: '2', content: 'Our main offer is the WebsiteOS, a subscription-based service.', category: 'Offers', source_document: 'Pricing Page', confidence_score: 0.99 },
              { id: '3', content: 'Our Ideal Customer Profile (ICP) is mid-sized B2B SaaS companies.', category: 'ICP', source_document: 'Marketing Strategy Deck', confidence_score: 0.95 },
            ]);
            setIntegrations(integrationData.length > 0 ? integrationData : [
                {id: '1', name: 'Google Analytics 4', logo_url: '🔍', status: 'connected'},
                {id: '2', name: 'DataForSEO', logo_url: '🎯', status: 'connected'},
                {id: '3', name: 'Google Ads', logo_url: '💰', status: 'disconnected'},
            ]);
        };
        loadData();
    }, []);

    const renderContent = () => {
      switch(activeTab) {
        case 'sources': return <KnowledgeSourcesTab integrations={integrations} />;
        case 'explorer': return <FactExplorerTab facts={facts} />;
        case 'analytics': return <AnalyticsTab />;
        case 'snapshot': return <BrainSnapshotTab facts={facts} />;
        default: return null;
      }
    }

    return (
        <ModuleLayout
          title="Business Brain"
          status={`${facts.length} Facts • ${integrations.filter(i=>i.status === 'connected').length} Sources`}
          statusColor="bg-blue-500"
          lastUpdated="2h ago"
          primaryAction={ <Button className="bg-cyan-600 hover:bg-cyan-700"><Plus size={16} className="mr-2" /> Add Fact</Button> }
          tabs={businessBrainTabs}
          activeTab={activeTab}
          onTabChange={setActiveTab}
        >
          {renderContent()}
        </ModuleLayout>
    );
}