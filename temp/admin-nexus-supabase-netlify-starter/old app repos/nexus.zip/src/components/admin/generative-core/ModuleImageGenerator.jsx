import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { GenerateImage } from "@/api/integrations";
import { Wand2, Image as ImageIcon, Zap, CheckCircle, Clock, AlertCircle } from "lucide-react";
import { motion, AnimatePresence } from 'framer-motion';

const ModuleImageGenerator = () => {
  const [isGenerating, setIsGenerating] = useState(false);
  const [progress, setProgress] = useState(0);
  const [currentModule, setCurrentModule] = useState('');
  const [generatedImages, setGeneratedImages] = useState({});
  const [generationResults, setGenerationResults] = useState([]);

  // Mock AI modules that need feature images
  const aiModules = [
    { id: 'author-personas', name: 'Author Personas & Style Library', category: 'Content Generation' },
    { id: 'content-ideation', name: 'Content Ideation & Keyword Mapper', category: 'Research' },
    { id: 'long-tail-factory', name: 'Long-Tail Landing Page Factory', category: 'SEO' },
    { id: 'schema-wizard', name: 'Schema Wizard & Rich Results Manager', category: 'Technical SEO' },
    { id: 'pillar-generator', name: 'Pillar & Cluster Page Generator', category: 'Content Strategy' },
    { id: 'image-optimizer', name: 'Image Optimizer & Metadata Tagger', category: 'Performance' },
    { id: 'internal-linking', name: 'Internal Linking Architect', category: 'SEO' },
    { id: 'semantic-search', name: 'Semantic Site Search', category: 'User Experience' },
    { id: 'landing-builder', name: 'Landing Page Builder', category: 'Conversion' },
    { id: 'staggered-publisher', name: 'Staggered Publisher', category: 'Publishing' },
  ];

  const generateStylePrompt = (module) => {
    const baseStyle = "Modern, minimalist, high-tech digital illustration with a dark theme. Use cyan (#00D4FF), electric blue (#3B82F6), and green (#10B981) accent colors on a dark gray background.";
    
    const categoryStyles = {
      'Content Generation': `${baseStyle} Feature a stylized pen or writing interface with flowing text elements and creative symbols.`,
      'Research': `${baseStyle} Show magnifying glass, data visualization elements, and search interfaces with analytical graphs.`,
      'SEO': `${baseStyle} Include search engine symbols, ranking charts, and website structure diagrams.`,
      'Technical SEO': `${baseStyle} Feature code blocks, schema markup visualization, and technical optimization icons.`,
      'Content Strategy': `${baseStyle} Show interconnected content nodes, strategic planning elements, and workflow diagrams.`,
      'Performance': `${baseStyle} Display speed optimization symbols, performance metrics, and efficiency indicators.`,
      'User Experience': `${baseStyle} Feature user interface elements, search bars, and interaction design components.`,
      'Conversion': `${baseStyle} Show conversion funnels, CTA buttons, and optimization elements.`,
      'Publishing': `${baseStyle} Display publishing workflows, calendar elements, and distribution networks.`
    };

    return categoryStyles[module.category] || baseStyle;
  };

  const handleGenerateAll = async () => {
    setIsGenerating(true);
    setProgress(0);
    setGenerationResults([]);
    
    const results = [];
    
    for (let i = 0; i < aiModules.length; i++) {
      const module = aiModules[i];
      setCurrentModule(module.name);
      setProgress(((i + 1) / aiModules.length) * 100);
      
      try {
        const prompt = generateStylePrompt(module);
        const result = await GenerateImage({ prompt });
        
        results.push({
          moduleId: module.id,
          moduleName: module.name,
          status: 'success',
          imageUrl: result.url,
          timestamp: new Date().toLocaleTimeString()
        });
        
        setGeneratedImages(prev => ({
          ...prev,
          [module.id]: result.url
        }));
        
      } catch (error) {
        results.push({
          moduleId: module.id,
          moduleName: module.name,
          status: 'error',
          error: error.message,
          timestamp: new Date().toLocaleTimeString()
        });
      }
      
      setGenerationResults([...results]);
      
      // Small delay between generations to prevent rate limiting
      if (i < aiModules.length - 1) {
        await new Promise(resolve => setTimeout(resolve, 1000));
      }
    }
    
    setIsGenerating(false);
    setCurrentModule('');
    setProgress(100);
  };

  const handleGenerateSingle = async (module) => {
    try {
      const prompt = generateStylePrompt(module);
      const result = await GenerateImage({ prompt });
      
      setGeneratedImages(prev => ({
        ...prev,
        [module.id]: result.url
      }));
      
      setGenerationResults(prev => [
        ...prev.filter(r => r.moduleId !== module.id),
        {
          moduleId: module.id,
          moduleName: module.name,
          status: 'success',
          imageUrl: result.url,
          timestamp: new Date().toLocaleTimeString()
        }
      ]);
    } catch (error) {
      setGenerationResults(prev => [
        ...prev.filter(r => r.moduleId !== module.id),
        {
          moduleId: module.id,
          moduleName: module.name,
          status: 'error',
          error: error.message,
          timestamp: new Date().toLocaleTimeString()
        }
      ]);
    }
  };

  return (
    <div className="space-y-6">
      {/* Control Panel */}
      <Card className="bg-gray-800 border-gray-700">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <ImageIcon className="text-cyan-400" />
            AI Module Image Generator
          </CardTitle>
          <p className="text-gray-400 text-sm">
            Generate consistent, branded feature images for all AI modules using AI image generation.
          </p>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between mb-4">
            <div>
              <p className="text-white font-medium">Generate All Module Images</p>
              <p className="text-gray-400 text-sm">Creates feature images for {aiModules.length} AI modules</p>
            </div>
            <Button
              onClick={handleGenerateAll}
              disabled={isGenerating}
              className="bg-gradient-to-r from-cyan-600 to-blue-600 text-white"
            >
              {isGenerating ? (
                <>
                  <Clock className="w-4 h-4 mr-2 animate-spin" />
                  Generating...
                </>
              ) : (
                <>
                  <Wand2 className="w-4 h-4 mr-2" />
                  Generate All Images
                </>
              )}
            </Button>
          </div>

          {isGenerating && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              className="space-y-3"
            >
              <Progress value={progress} className="w-full" />
              <p className="text-cyan-400 text-sm">
                Currently generating: {currentModule}
              </p>
            </motion.div>
          )}
        </CardContent>
      </Card>

      {/* Module Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <AnimatePresence>
          {aiModules.map((module, index) => {
            const result = generationResults.find(r => r.moduleId === module.id);
            const hasImage = generatedImages[module.id];
            
            return (
              <motion.div
                key={module.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.05 }}
              >
                <Card className="bg-gray-800 border-gray-700 hover:border-cyan-500/50 transition-colors">
                  <CardHeader className="pb-3">
                    <div className="flex items-start justify-between">
                      <div>
                        <CardTitle className="text-white text-sm mb-2">{module.name}</CardTitle>
                        <Badge className="bg-blue-500/20 text-blue-400 text-xs">
                          {module.category}
                        </Badge>
                      </div>
                      {result && (
                        <div className="ml-2">
                          {result.status === 'success' && <CheckCircle className="w-4 h-4 text-green-400" />}
                          {result.status === 'error' && <AlertCircle className="w-4 h-4 text-red-400" />}
                        </div>
                      )}
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="aspect-video bg-gray-700 rounded-lg mb-4 overflow-hidden flex items-center justify-center">
                      {hasImage ? (
                        <img 
                          src={generatedImages[module.id]} 
                          alt={module.name}
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <ImageIcon className="w-8 h-8 text-gray-500" />
                      )}
                    </div>
                    
                    <div className="flex justify-between items-center">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleGenerateSingle(module)}
                        className="text-gray-300 border-gray-600 hover:border-cyan-500/50"
                      >
                        <Zap className="w-3 h-3 mr-1" />
                        {hasImage ? 'Regenerate' : 'Generate'}
                      </Button>
                      
                      {result && (
                        <span className="text-xs text-gray-500">
                          {result.timestamp}
                        </span>
                      )}
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            );
          })}
        </AnimatePresence>
      </div>
    </div>
  );
};

export default ModuleImageGenerator;