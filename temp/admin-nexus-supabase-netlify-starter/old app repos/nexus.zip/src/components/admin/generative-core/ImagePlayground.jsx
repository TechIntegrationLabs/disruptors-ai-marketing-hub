import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { GenerateImage } from "@/api/integrations";
import { ImageIcon, Zap, Wand2, Loader, Download } from "lucide-react";
import { motion, AnimatePresence } from 'framer-motion';

const ImagePlayground = () => {
  const [prompt, setPrompt] = useState('');
  const [style, setStyle] = useState('photorealistic');
  const [aspectRatio, setAspectRatio] = useState('16:9');
  const [isLoading, setIsLoading] = useState(false);
  const [generatedImage, setGeneratedImage] = useState(null);
  const [error, setError] = useState(null);

  const handleGenerate = async () => {
    if (!prompt) return;
    setIsLoading(true);
    setError(null);
    setGeneratedImage(null);

    const detailedPrompt = `Generate a ${style} image. Aspect ratio ${aspectRatio}. Prompt: ${prompt}`;

    try {
      // This call assumes a backend function is set up to call the actual AI API
      const result = await GenerateImage({ prompt: detailedPrompt });
      setGeneratedImage(result.url); // Assuming the integration returns { url: '...' }
    } catch (e) {
      setError("Failed to generate image. The backend service may not be configured.");
      console.error(e);
      // For demo purposes, set a placeholder image on error
      setGeneratedImage(`https://placehold.co/1024x576/1F2937/00D4FF/png?text=Generation+Failed`);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Card className="bg-gray-800 border-gray-700 h-full flex flex-col">
      <CardHeader>
        <CardTitle className="text-white flex items-center gap-2">
          <Wand2 className="text-cyan-400" />
          Image Generation Playground
        </CardTitle>
      </CardHeader>
      <CardContent className="flex-grow flex flex-col lg:flex-row gap-6">
        {/* Controls */}
        <div className="lg:w-1/3 space-y-4 flex flex-col">
          <Textarea
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            placeholder="Describe the image you want to create..."
            className="flex-grow bg-gray-900 border-gray-600 text-white placeholder:text-gray-500 min-h-[150px]"
          />
          <div className="grid grid-cols-2 gap-4">
            <Select value={style} onValueChange={setStyle}>
              <SelectTrigger className="bg-gray-900 border-gray-600 text-white">
                <SelectValue placeholder="Style" />
              </SelectTrigger>
              <SelectContent className="bg-gray-800 border-gray-600 text-white">
                <SelectItem value="photorealistic">Photorealistic</SelectItem>
                <SelectItem value="digital-art">Digital Art</SelectItem>
                <SelectItem value="3d-illustration">3D Illustration</SelectItem>
                <SelectItem value="minimalist-logo">Minimalist Logo</SelectItem>
                <SelectItem value="cyberpunk">Cyberpunk</SelectItem>
              </SelectContent>
            </Select>
            <Select value={aspectRatio} onValueChange={setAspectRatio}>
              <SelectTrigger className="bg-gray-900 border-gray-600 text-white">
                <SelectValue placeholder="Aspect Ratio" />
              </SelectTrigger>
              <SelectContent className="bg-gray-800 border-gray-600 text-white">
                <SelectItem value="16:9">16:9 (Landscape)</SelectItem>
                <SelectItem value="1:1">1:1 (Square)</SelectItem>
                <SelectItem value="9:16">9:16 (Portrait)</SelectItem>
                <SelectItem value="4:3">4:3 (Standard)</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <Button onClick={handleGenerate} disabled={isLoading || !prompt} className="w-full bg-cyan-600 hover:bg-cyan-700 text-white">
            {isLoading ? <Loader className="animate-spin mr-2" /> : <Zap className="mr-2" />}
            Generate Image
          </Button>
        </div>

        {/* Image Display */}
        <div className="lg:w-2/3 flex-grow bg-gray-900/50 rounded-lg border border-dashed border-gray-600 flex items-center justify-center p-4 relative overflow-hidden">
          <AnimatePresence>
            {isLoading && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="absolute inset-0 bg-gray-900/50 backdrop-blur-sm flex flex-col items-center justify-center z-10"
              >
                <Loader className="w-10 h-10 text-cyan-400 animate-spin" />
                <p className="text-white mt-4">Generating your vision...</p>
              </motion.div>
            )}
            {!isLoading && generatedImage && (
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                className="w-full h-full relative group"
              >
                <img src={generatedImage} alt={prompt} className="object-contain w-full h-full rounded-md" />
                <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                  <Button asChild variant="secondary" className="bg-white/20 hover:bg-white/30 text-white">
                    <a href={generatedImage} download={`generated-image-${Date.now()}.png`}>
                      <Download className="mr-2" /> Download
                    </a>
                  </Button>
                </div>
              </motion.div>
            )}
            {!isLoading && !generatedImage && (
              <div className="text-center text-gray-500">
                <ImageIcon className="mx-auto w-16 h-16" />
                <p>Your generated image will appear here.</p>
                {error && <p className="text-red-500 mt-2">{error}</p>}
              </div>
            )}
          </AnimatePresence>
        </div>
      </CardContent>
    </Card>
  );
};

export default ImagePlayground;