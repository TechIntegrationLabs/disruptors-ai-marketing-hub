import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Cpu, Zap, Image as ImageIcon, Sparkles, Check } from "lucide-react";

const ModelSettings = () => {
  const [modelConfig, setModelConfig] = useState({
    reasoning: 'gpt-4o',
    fast_response: 'gemini-1.5-flash',
    image_generation: 'dall-e-3'
  });

  const handleModelChange = (task, model) => {
    setModelConfig(prev => ({ ...prev, [task]: model }));
  };

  return (
    <div className="space-y-6">
      <Card className="bg-gray-800 border-gray-700">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Sparkles className="text-cyan-400" />
            AI Model Configuration
          </CardTitle>
          <p className="text-gray-400 text-sm">
            Select the default generative models for different types of tasks across WebsiteOS.
          </p>
        </CardHeader>
        <CardContent className="space-y-8">
          <Alert className="bg-blue-500/10 border-blue-500/30">
            <AlertTitle className="text-blue-300">Model Name Mapping</AlertTitle>
            <AlertDescription className="text-blue-400">
              We use the latest available models. "GPT-5" refers to **GPT-4o** until the next version is released. "Nano Banana" refers to the fast and efficient **Gemini 1.5 Flash**.
            </AlertDescription>
          </Alert>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Complex Reasoning */}
            <Card className="bg-gray-700/50 border-gray-600">
              <CardHeader>
                <div className="flex items-center gap-3">
                  <Cpu className="text-purple-400" />
                  <CardTitle className="text-white text-base">Complex Reasoning</CardTitle>
                </div>
                <p className="text-gray-400 text-xs pt-2">For analysis, content generation, and strategic planning.</p>
              </CardHeader>
              <CardContent>
                <Select value={modelConfig.reasoning} onValueChange={(val) => handleModelChange('reasoning', val)}>
                  <SelectTrigger className="bg-gray-800 border-gray-600 text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-gray-800 border-gray-600 text-white">
                    <SelectItem value="gpt-4o" className="focus:bg-gray-700">OpenAI GPT-4o</SelectItem>
                    <SelectItem value="gemini-1.5-pro" className="focus:bg-gray-700">Google Gemini 1.5 Pro</SelectItem>
                  </SelectContent>
                </Select>
              </CardContent>
            </Card>

            {/* Fast Responses */}
            <Card className="bg-gray-700/50 border-gray-600">
              <CardHeader>
                <div className="flex items-center gap-3">
                  <Zap className="text-yellow-400" />
                  <CardTitle className="text-white text-base">Fast Responses</CardTitle>
                </div>
                <p className="text-gray-400 text-xs pt-2">For summarization, classification, and quick UI tasks.</p>
              </CardHeader>
              <CardContent>
                <Select value={modelConfig.fast_response} onValueChange={(val) => handleModelChange('fast_response', val)}>
                  <SelectTrigger className="bg-gray-800 border-gray-600 text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-gray-800 border-gray-600 text-white">
                    <SelectItem value="gemini-1.5-flash" className="focus:bg-gray-700">Google Gemini 1.5 Flash</SelectItem>
                    <SelectItem value="gpt-4o" className="focus:bg-gray-700">OpenAI GPT-4o</SelectItem>
                  </SelectContent>
                </Select>
              </CardContent>
            </Card>

            {/* Image Generation */}
            <Card className="bg-gray-700/50 border-gray-600">
              <CardHeader>
                <div className="flex items-center gap-3">
                  <ImageIcon className="text-green-400" />
                  <CardTitle className="text-white text-base">Image Generation</CardTitle>
                </div>
                <p className="text-gray-400 text-xs pt-2">For creating feature images, illustrations, and brand assets.</p>
              </CardHeader>
              <CardContent>
                <Select value={modelConfig.image_generation} onValueChange={(val) => handleModelChange('image_generation', val)}>
                  <SelectTrigger className="bg-gray-800 border-gray-600 text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-gray-800 border-gray-600 text-white">
                    <SelectItem value="dall-e-3" className="focus:bg-gray-700">OpenAI DALL-E 3</SelectItem>
                    {/* Add Gemini image gen when API is broadly available */}
                  </SelectContent>
                </Select>
              </CardContent>
            </Card>
          </div>

          <div className="flex justify-end">
            <Button className="bg-cyan-600 hover:bg-cyan-700 text-white">
              <Check className="w-4 h-4 mr-2" />
              Save Model Preferences
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default ModelSettings;