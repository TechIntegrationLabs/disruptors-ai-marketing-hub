import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { CheckCircle, Smartphone } from 'lucide-react';

const MetaAdsConfig = ({ integration, onUpdate, onCancel }) => {
  const [isConnected, setIsConnected] = useState(false);

  const handleConnect = () => {
    setIsConnected(true);
    onUpdate(integration.id, 'connected', { isConnected: true });
  };

  return (
    <div className="h-full flex flex-col p-6">
      <div className="flex-grow space-y-6">
        <Card className="bg-gray-800 border-gray-700">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <Smartphone className="w-5 h-5" />
              Connect Meta Ads
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {!isConnected ? (
              <>
                <p className="text-gray-400 text-sm">
                  Connect Meta Ads (Facebook & Instagram) to track social media advertising performance.
                </p>
                
                <Button onClick={handleConnect} className="w-full bg-blue-600 hover:bg-blue-700">
                  <Smartphone className="w-4 h-4 mr-2" />
                  Connect with Meta
                </Button>
              </>
            ) : (
              <Alert className="bg-green-500/20 border-green-500/50">
                <CheckCircle className="h-4 w-4" />
                <AlertDescription className="text-green-400">
                  Successfully connected to Meta Ads! Full configuration coming soon.
                </AlertDescription>
              </Alert>
            )}
          </CardContent>
        </Card>
      </div>

      <div className="border-t border-gray-700 pt-6 flex justify-between">
        <Button variant="outline" onClick={onCancel} className="border-gray-600 text-gray-300">
          Cancel
        </Button>
        <Button onClick={() => onUpdate(integration.id, isConnected ? 'connected' : 'disconnected', { isConnected })} 
                className="bg-amber-600 hover:bg-amber-700 text-black">
          <CheckCircle className="w-4 h-4 mr-2" />
          Save Configuration
        </Button>
      </div>
    </div>
  );
};

export default MetaAdsConfig;