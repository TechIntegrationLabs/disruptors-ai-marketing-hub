import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { CheckCircle, Workflow } from 'lucide-react';

const ZapierConfig = ({ integration, onUpdate, onCancel }) => {
  const [isConnected, setIsConnected] = useState(false);

  const handleConnect = () => {
    setIsConnected(true);
    onUpdate(integration.id, 'connected', { isConnected: true });
  };

  return (
    <div className="h-full flex flex-col p-6">
      <div className="flex-grow space-y-6">
        <Card className="bg-gray-800 border-gray-700">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <Workflow className="w-5 h-5" />
              Connect Zapier
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {!isConnected ? (
              <>
                <p className="text-gray-400 text-sm">
                  Connect Zapier for automation workflows and multi-app integrations.
                </p>
                
                <Button onClick={handleConnect} className="w-full bg-blue-600 hover:bg-blue-700">
                  <Workflow className="w-4 h-4 mr-2" />
                  Connect Zapier
                </Button>
              </>
            ) : (
              <Alert className="bg-green-500/20 border-green-500/50">
                <CheckCircle className="h-4 w-4" />
                <AlertDescription className="text-green-400">
                  Successfully connected to Zapier! Full configuration coming soon.
                </AlertDescription>
              </Alert>
            )}
          </CardContent>
        </Card>
      </div>

      <div className="border-t border-gray-700 pt-6 flex justify-between">
        <Button variant="outline" onClick={onCancel} className="border-gray-600 text-gray-300">
          Cancel
        </Button>
        <Button onClick={() => onUpdate(integration.id, isConnected ? 'connected' : 'disconnected', { isConnected })} 
                className="bg-amber-600 hover:bg-amber-700 text-black">
          <CheckCircle className="w-4 h-4 mr-2" />
          Save Configuration
        </Button>
      </div>
    </div>
  );
};

export default ZapierConfig;