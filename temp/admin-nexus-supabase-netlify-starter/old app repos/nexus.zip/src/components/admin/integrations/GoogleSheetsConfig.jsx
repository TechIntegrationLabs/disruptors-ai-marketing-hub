import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { CheckCircle, FileText, Plus } from 'lucide-react';

const GoogleSheetsConfig = ({ integration, onUpdate, onCancel }) => {
  const [sheets, setSheets] = useState([]);
  const [newSheet, setNewSheet] = useState({ name: '', url: '' });

  const handleAddSheet = () => {
    if (!newSheet.name || !newSheet.url) return;
    
    setSheets(prev => [...prev, { ...newSheet, id: Date.now() }]);
    setNewSheet({ name: '', url: '' });
    onUpdate(integration.id, 'connected', { sheets: [...sheets, newSheet] });
  };

  return (
    <div className="h-full flex flex-col p-6">
      <div className="flex-grow space-y-6">
        <Card className="bg-gray-800 border-gray-700">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <FileText className="w-5 h-5" />
              Google Sheets Data Sources
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-gray-400 text-sm">
              Add Google Sheets as live data sources. Make sure sheets are publicly viewable or shared with appropriate permissions.
            </p>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Sheet Name
                </label>
                <Input
                  placeholder="e.g., Customer Data"
                  value={newSheet.name}
                  onChange={(e) => setNewSheet(prev => ({ ...prev, name: e.target.value }))}
                  className="bg-gray-700 border-gray-600 text-white"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Sheet URL
                </label>
                <div className="flex gap-2">
                  <Input
                    placeholder="https://docs.google.com/spreadsheets/d/..."
                    value={newSheet.url}
                    onChange={(e) => setNewSheet(prev => ({ ...prev, url: e.target.value }))}
                    className="bg-gray-700 border-gray-600 text-white flex-1"
                  />
                  <Button 
                    onClick={handleAddSheet}
                    disabled={!newSheet.name || !newSheet.url}
                    className="bg-green-600 hover:bg-green-700"
                  >
                    <Plus className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </div>

            {sheets.length > 0 && (
              <div className="space-y-2">
                <h4 className="font-medium text-white">Connected Sheets</h4>
                {sheets.map(sheet => (
                  <div key={sheet.id} className="p-3 bg-gray-700 rounded-lg flex items-center justify-between">
                    <div>
                      <div className="font-medium text-white">{sheet.name}</div>
                      <div className="text-xs text-gray-400 truncate max-w-xs">{sheet.url}</div>
                    </div>
                    <CheckCircle className="w-4 h-4 text-green-400" />
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <div className="border-t border-gray-700 pt-6 flex justify-between">
        <Button variant="outline" onClick={onCancel} className="border-gray-600 text-gray-300">
          Cancel
        </Button>
        <Button onClick={() => onUpdate(integration.id, sheets.length > 0 ? 'connected' : 'disconnected', { sheets })} 
                className="bg-amber-600 hover:bg-amber-700 text-black">
          <CheckCircle className="w-4 h-4 mr-2" />
          Save Configuration
        </Button>
      </div>
    </div>
  );
};

export default GoogleSheetsConfig;