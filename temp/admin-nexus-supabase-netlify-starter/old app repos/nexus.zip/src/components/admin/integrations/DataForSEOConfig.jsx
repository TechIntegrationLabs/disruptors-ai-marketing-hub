import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { CheckCircle, Key, Target } from 'lucide-react';

const DataForSEOConfig = ({ integration, onUpdate, onCancel }) => {
  const [config, setConfig] = useState({
    isConnected: false,
    email: '',
    apiKey: ''
  });
  const [isConnecting, setIsConnecting] = useState(false);

  const handleConnect = async () => {
    if (!config.email || !config.apiKey) return;
    
    setIsConnecting(true);
    // Simulate API validation
    setTimeout(() => {
      setConfig(prev => ({ ...prev, isConnected: true }));
      setIsConnecting(false);
      onUpdate(integration.id, 'connected', config);
    }, 2000);
  };

  return (
    <div className="h-full flex flex-col p-6">
      <div className="flex-grow space-y-6">
        <Card className="bg-gray-800 border-gray-700">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <Target className="w-5 h-5" />
              Connect DataForSEO
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {!config.isConnected ? (
              <>
                <p className="text-gray-400 text-sm">
                  Connect DataForSEO for comprehensive SEO data, keyword research, and competitor analysis.
                </p>
                
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-2">
                      DataForSEO Email
                    </label>
                    <Input
                      type="email"
                      placeholder="your-email@example.com"
                      value={config.email}
                      onChange={(e) => setConfig(prev => ({ ...prev, email: e.target.value }))}
                      className="bg-gray-700 border-gray-600 text-white"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-2">
                      API Key
                    </label>
                    <Input
                      type="password"
                      placeholder="Your DataForSEO API key"
                      value={config.apiKey}
                      onChange={(e) => setConfig(prev => ({ ...prev, apiKey: e.target.value }))}
                      className="bg-gray-700 border-gray-600 text-white"
                    />
                  </div>

                  <Button 
                    onClick={handleConnect} 
                    disabled={!config.email || !config.apiKey || isConnecting}
                    className="w-full bg-blue-600 hover:bg-blue-700"
                  >
                    <Key className="w-4 h-4 mr-2" />
                    {isConnecting ? 'Validating...' : 'Connect DataForSEO'}
                  </Button>
                </div>
              </>
            ) : (
              <Alert className="bg-green-500/20 border-green-500/50">
                <CheckCircle className="h-4 w-4" />
                <AlertDescription className="text-green-400">
                  Successfully connected to DataForSEO! Your SEO intelligence is now active.
                </AlertDescription>
              </Alert>
            )}
          </CardContent>
        </Card>
      </div>

      <div className="border-t border-gray-700 pt-6 flex justify-between">
        <Button variant="outline" onClick={onCancel} className="border-gray-600 text-gray-300">
          Cancel
        </Button>
        <Button onClick={() => onUpdate(integration.id, config.isConnected ? 'connected' : 'disconnected', config)} 
                className="bg-amber-600 hover:bg-amber-700 text-black">
          <CheckCircle className="w-4 h-4 mr-2" />
          Save Configuration
        </Button>
      </div>
    </div>
  );
};

export default DataForSEOConfig;