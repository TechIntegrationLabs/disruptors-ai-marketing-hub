import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { 
  Search, 
  CheckCircle, 
  AlertTriangle, 
  TrendingUp,
  MousePointer,
  Eye,
  AlertCircle,
  RefreshCw,
  Chrome
} from 'lucide-react';

const GoogleSearchConsoleConfig = ({ integration, onUpdate, onCancel }) => {
  const [config, setConfig] = useState({
    isConnected: false,
    selectedProperty: '',
    dataCollection: {
      searchQueries: true,
      pagePerformance: true,
      indexStatus: true,
      coreWebVitals: true,
      crawlErrors: true
    },
    syncFrequency: 'daily',
    dateRange: '3months'
  });
  const [activeTab, setActiveTab] = useState('connection');
  const [isConnecting, setIsConnecting] = useState(false);

  const mockProperties = [
    { url: 'https://example.com/', type: 'Domain property', verified: true },
    { url: 'https://blog.example.com/', type: 'URL prefix', verified: true },
    { url: 'https://shop.example.com/', type: 'URL prefix', verified: false }
  ];

  const mockSearchData = [
    { query: 'digital marketing tips', impressions: 12400, clicks: 890, ctr: 7.2, position: 3.4 },
    { query: 'SEO best practices', impressions: 8900, clicks: 612, ctr: 6.9, position: 4.1 },
    { query: 'content marketing strategy', impressions: 6700, clicks: 445, ctr: 6.6, position: 4.8 },
    { query: 'social media marketing', impressions: 5200, clicks: 334, ctr: 6.4, position: 5.2 }
  ];

  const handleGoogleConnect = async () => {
    setIsConnecting(true);
    setTimeout(() => {
      setConfig(prev => ({ ...prev, isConnected: true }));
      setIsConnecting(false);
    }, 2000);
  };

  const handleSave = () => {
    onUpdate(integration.id, config.isConnected ? 'connected' : 'disconnected', config);
  };

  return (
    <div className="h-full flex flex-col">
      <Tabs value={activeTab} onValueChange={setActiveTab} className="flex-grow flex flex-col">
        <TabsList className="grid w-full grid-cols-4 bg-gray-800 mx-6 mt-4">
          <TabsTrigger value="connection">Connection</TabsTrigger>
          <TabsTrigger value="data">Data Collection</TabsTrigger>
          <TabsTrigger value="insights">Insights</TabsTrigger>
          <TabsTrigger value="data-flow">Data Flow</TabsTrigger>
        </TabsList>

        <div className="flex-grow p-6 overflow-y-auto">
          <TabsContent value="connection" className="space-y-6 mt-0">
            <Card className="bg-gray-800 border-gray-700">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <Chrome className="w-5 h-5" />
                  Connect Google Search Console
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {!config.isConnected ? (
                  <>
                    <p className="text-gray-400 text-sm">
                      Connect Google Search Console to monitor your site's organic search performance, 
                      identify optimization opportunities, and track technical SEO health.
                    </p>
                    
                    <Alert className="bg-gray-700 border-gray-600">
                      <AlertTriangle className="h-4 w-4" />
                      <AlertDescription className="text-gray-300">
                        Make sure your website is verified in Google Search Console before connecting.
                        This integration will access search performance data and indexing status.
                      </AlertDescription>
                    </Alert>

                    <Button
                      onClick={handleGoogleConnect}
                      disabled={isConnecting}
                      className="w-full bg-blue-600 hover:bg-blue-700"
                    >
                      <Chrome className="w-4 h-4 mr-2" />
                      {isConnecting ? 'Connecting...' : 'Connect with Google'}
                    </Button>
                  </>
                ) : (
                  <>
                    <Alert className="bg-green-500/20 border-green-500/50">
                      <CheckCircle className="h-4 w-4" />
                      <AlertDescription className="text-green-400">
                        Successfully connected to Google Search Console!
                      </AlertDescription>
                    </Alert>

                    <div>
                      <label className="block text-sm font-medium text-gray-300 mb-2">
                        Select Property
                      </label>
                      <Select value={config.selectedProperty} onValueChange={(value) => setConfig(prev => ({ ...prev, selectedProperty: value }))}>
                        <SelectTrigger className="bg-gray-700 border-gray-600 text-white">
                          <SelectValue placeholder="Choose a verified property..." />
                        </SelectTrigger>
                        <SelectContent className="bg-gray-700 border-gray-600">
                          {mockProperties.map(property => (
                            <SelectItem key={property.url} value={property.url} disabled={!property.verified}>
                              <div className="flex items-center gap-2">
                                {property.verified ? (
                                  <CheckCircle className="w-3 h-3 text-green-400" />
                                ) : (
                                  <AlertCircle className="w-3 h-3 text-red-400" />
                                )}
                                <div>
                                  <div className="text-sm">{property.url}</div>
                                  <div className="text-xs opacity-75">{property.type}</div>
                                </div>
                              </div>
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </>
                )}
              </CardContent>
            </Card>

            {config.isConnected && config.selectedProperty && (
              <Card className="bg-gray-800 border-gray-700">
                <CardHeader>
                  <CardTitle className="text-white">Property Overview</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <div className="text-center">
                      <div className="text-2xl font-bold text-white">342K</div>
                      <div className="text-sm text-gray-400">Total Clicks</div>
                      <div className="text-xs text-green-400 mt-1">+12% vs last month</div>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-white">8.7M</div>
                      <div className="text-sm text-gray-400">Impressions</div>
                      <div className="text-xs text-green-400 mt-1">+8% vs last month</div>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-white">3.9%</div>
                      <div className="text-sm text-gray-400">Avg CTR</div>
                      <div className="text-xs text-green-400 mt-1">+0.3% vs last month</div>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-white">18.4</div>
                      <div className="text-sm text-gray-400">Avg Position</div>
                      <div className="text-xs text-red-400 mt-1">-2.1 vs last month</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="data" className="space-y-6 mt-0">
            <Card className="bg-gray-800 border-gray-700">
              <CardHeader>
                <CardTitle className="text-white">Data Collection Settings</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <h4 className="font-medium text-white">Data Types</h4>
                    
                    <div className="flex items-center justify-between">
                      <div>
                        <label className="text-sm font-medium text-white">Search Queries</label>
                        <p className="text-xs text-gray-400">Top keywords, CTR, impressions</p>
                      </div>
                      <Switch
                        checked={config.dataCollection.searchQueries}
                        onCheckedChange={(checked) => setConfig(prev => ({
                          ...prev,
                          dataCollection: { ...prev.dataCollection, searchQueries: checked }
                        }))}
                      />
                    </div>

                    <div className="flex items-center justify-between">
                      <div>
                        <label className="text-sm font-medium text-white">Page Performance</label>
                        <p className="text-xs text-gray-400">Individual page metrics</p>
                      </div>
                      <Switch
                        checked={config.dataCollection.pagePerformance}
                        onCheckedChange={(checked) => setConfig(prev => ({
                          ...prev,
                          dataCollection: { ...prev.dataCollection, pagePerformance: checked }
                        }))}
                      />
                    </div>

                    <div className="flex items-center justify-between">
                      <div>
                        <label className="text-sm font-medium text-white">Index Status</label>
                        <p className="text-xs text-gray-400">Coverage reports, indexing issues</p>
                      </div>
                      <Switch
                        checked={config.dataCollection.indexStatus}
                        onCheckedChange={(checked) => setConfig(prev => ({
                          ...prev,
                          dataCollection: { ...prev.dataCollection, indexStatus: checked }
                        }))}
                      />
                    </div>

                    <div className="flex items-center justify-between">
                      <div>
                        <label className="text-sm font-medium text-white">Core Web Vitals</label>
                        <p className="text-xs text-gray-400">Page experience metrics</p>
                      </div>
                      <Switch
                        checked={config.dataCollection.coreWebVitals}
                        onCheckedChange={(checked) => setConfig(prev => ({
                          ...prev,
                          dataCollection: { ...prev.dataCollection, coreWebVitals: checked }
                        }))}
                      />
                    </div>

                    <div className="flex items-center justify-between">
                      <div>
                        <label className="text-sm font-medium text-white">Crawl Errors</label>
                        <p className="text-xs text-gray-400">Crawling and indexing errors</p>
                      </div>
                      <Switch
                        checked={config.dataCollection.crawlErrors}
                        onCheckedChange={(checked) => setConfig(prev => ({
                          ...prev,
                          dataCollection: { ...prev.dataCollection, crawlErrors: checked }
                        }))}
                      />
                    </div>
                  </div>

                  <div className="space-y-4">
                    <h4 className="font-medium text-white">Sync Settings</h4>
                    
                    <div>
                      <label className="block text-sm font-medium text-gray-300 mb-2">
                        Data Sync Frequency
                      </label>
                      <Select value={config.syncFrequency} onValueChange={(value) => setConfig(prev => ({ ...prev, syncFrequency: value }))}>
                        <SelectTrigger className="bg-gray-700 border-gray-600 text-white">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent className="bg-gray-700 border-gray-600">
                          <SelectItem value="daily">Daily</SelectItem>
                          <SelectItem value="weekly">Weekly</SelectItem>
                          <SelectItem value="monthly">Monthly</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-300 mb-2">
                        Historical Data Range
                      </label>
                      <Select value={config.dateRange} onValueChange={(value) => setConfig(prev => ({ ...prev, dateRange: value }))}>
                        <SelectTrigger className="bg-gray-700 border-gray-600 text-white">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent className="bg-gray-700 border-gray-600">
                          <SelectItem value="1month">Last 1 Month</SelectItem>
                          <SelectItem value="3months">Last 3 Months</SelectItem>
                          <SelectItem value="6months">Last 6 Months</SelectItem>
                          <SelectItem value="1year">Last Year</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <Alert className="bg-gray-700 border-gray-600">
                      <RefreshCw className="h-4 w-4" />
                      <AlertDescription className="text-gray-300">
                        GSC data has a 2-3 day delay. Historical data beyond 16 months is not available.
                      </AlertDescription>
                    </Alert>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="insights" className="space-y-6 mt-0">
            <Card className="bg-gray-800 border-gray-700">
              <CardHeader>
                <CardTitle className="text-white">Top Performing Queries</CardTitle>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow className="border-gray-700">
                      <TableHead className="text-white">Query</TableHead>
                      <TableHead className="text-white text-right">Impressions</TableHead>
                      <TableHead className="text-white text-right">Clicks</TableHead>
                      <TableHead className="text-white text-right">CTR</TableHead>
                      <TableHead className="text-white text-right">Position</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {mockSearchData.map((row, index) => (
                      <TableRow key={index} className="border-gray-700">
                        <TableCell className="font-medium text-white">{row.query}</TableCell>
                        <TableCell className="text-gray-300 text-right">{row.impressions.toLocaleString()}</TableCell>
                        <TableCell className="text-gray-300 text-right">{row.clicks.toLocaleString()}</TableCell>
                        <TableCell className="text-gray-300 text-right">{row.ctr}%</TableCell>
                        <TableCell className="text-gray-300 text-right">{row.position}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card className="bg-gray-800 border-gray-700">
                <CardHeader>
                  <CardTitle className="text-white">Optimization Opportunities</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="p-3 bg-gray-700 rounded-lg">
                      <div className="flex items-center gap-2 mb-2">
                        <TrendingUp className="w-4 h-4 text-green-400" />
                        <span className="font-medium text-white text-sm">High Impression, Low CTR</span>
                      </div>
                      <p className="text-xs text-gray-400">
                        15 queries with &gt;1000 impressions but &lt;2% CTR. Optimize titles and meta descriptions.
                      </p>
                    </div>
                    
                    <div className="p-3 bg-gray-700 rounded-lg">
                      <div className="flex items-center gap-2 mb-2">
                        <Eye className="w-4 h-4 text-yellow-400" />
                        <span className="font-medium text-white text-sm">Position 4-10 Queries</span>
                      </div>
                      <p className="text-xs text-gray-400">
                        23 queries ranking 4-10. Small improvements could move them to page 1.
                      </p>
                    </div>

                    <div className="p-3 bg-gray-700 rounded-lg">
                      <div className="flex items-center gap-2 mb-2">
                        <MousePointer className="w-4 h-4 text-blue-400" />
                        <span className="font-medium text-white text-sm">Content Gaps</span>
                      </div>
                      <p className="text-xs text-gray-400">
                        8 high-volume queries with no current ranking. Content opportunities identified.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-gray-800 border-gray-700">
                <CardHeader>
                  <CardTitle className="text-white">Technical Health</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <span className="text-gray-300 text-sm">Indexed Pages</span>
                      <div className="flex items-center gap-2">
                        <span className="text-white font-medium">1,247</span>
                        <CheckCircle className="w-4 h-4 text-green-400" />
                      </div>
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <span className="text-gray-300 text-sm">Coverage Issues</span>
                      <div className="flex items-center gap-2">
                        <span className="text-white font-medium">12</span>
                        <AlertTriangle className="w-4 h-4 text-yellow-400" />
                      </div>
                    </div>

                    <div className="flex items-center justify-between">
                      <span className="text-gray-300 text-sm">Core Web Vitals</span>
                      <div className="flex items-center gap-2">
                        <span className="text-white font-medium">Good</span>
                        <CheckCircle className="w-4 h-4 text-green-400" />
                      </div>
                    </div>

                    <div className="flex items-center justify-between">
                      <span className="text-gray-300 text-sm">Mobile Usability</span>
                      <div className="flex items-center gap-2">
                        <span className="text-white font-medium">3 issues</span>
                        <AlertCircle className="w-4 h-4 text-red-400" />
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="data-flow" className="space-y-6 mt-0">
            <Card className="bg-gray-800 border-gray-700">
              <CardHeader>
                <CardTitle className="text-white">Search Console Data Integration</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div className="text-center">
                    <div className="text-2xl mb-2">🔍</div>
                    <h3 className="font-medium text-white">Google Search Console</h3>
                    <p className="text-sm text-gray-400">Organic search performance data</p>
                  </div>

                  <div className="flex justify-center">
                    <div className="w-px h-12 bg-gray-600"></div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                    <Card className="bg-gray-700 border-gray-600">
                      <CardContent className="p-4 text-center">
                        <Search className="w-6 h-6 text-cyan-400 mx-auto mb-2" />
                        <h4 className="text-sm font-medium text-white">Business Brain</h4>
                        <p className="text-xs text-gray-400 mt-1">Top keywords, search trends, content gaps</p>
                      </CardContent>
                    </Card>

                    <Card className="bg-gray-700 border-gray-600">
                      <CardContent className="p-4 text-center">
                        <TrendingUp className="w-6 h-6 text-green-400 mx-auto mb-2" />
                        <h4 className="text-sm font-medium text-white">Content Ideation</h4>
                        <p className="text-xs text-gray-400 mt-1">Topic opportunities, keyword targeting</p>
                      </CardContent>
                    </Card>

                    <Card className="bg-gray-700 border-gray-600">
                      <CardContent className="p-4 text-center">
                        <RefreshCw className="w-6 h-6 text-purple-400 mx-auto mb-2" />
                        <h4 className="text-sm font-medium text-white">Internal Linking</h4>
                        <p className="text-xs text-gray-400 mt-1">Page authority, link opportunities</p>
                      </CardContent>
                    </Card>

                    <Card className="bg-gray-700 border-gray-600">
                      <CardContent className="p-4 text-center">
                        <AlertTriangle className="w-6 h-6 text-amber-400 mx-auto mb-2" />
                        <h4 className="text-sm font-medium text-white">Schema Wizard</h4>
                        <p className="text-xs text-gray-400 mt-1">Rich results, technical optimization</p>
                      </CardContent>
                    </Card>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </div>

        <div className="border-t border-gray-700 p-6 flex justify-between">
          <Button variant="outline" onClick={onCancel} className="border-gray-600 text-gray-300">
            Cancel
          </Button>
          <Button onClick={handleSave} className="bg-amber-600 hover:bg-amber-700 text-black">
            <CheckCircle className="w-4 h-4 mr-2" />
            Save Configuration
          </Button>
        </div>
      </Tabs>
    </div>
  );
};

export default GoogleSearchConsoleConfig;