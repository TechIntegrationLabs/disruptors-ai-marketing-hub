
import React, { useState, useEffect, useCallback } from 'react';
import AdminSidebar from "../components/admin/AdminSidebar";
import DashboardOverview from "../components/admin/DashboardOverview";
import AIModuleManager from "../components/admin/AIModuleManager";
import MCPServerManager from "../components/admin/MCPServerManager";
import DevServicesControl from "../components/admin/DevServicesControl";
import RepoAdmin from "../components/admin/RepoAdmin";
import TelemetryDashboard from "../components/admin/TelemetryDashboard";
import ReplicateAiPanel from "../components/admin/ReplicateAiPanel";
import BusinessBrainBuilder from '../components/admin/BusinessBrainBuilder';
import BrandDNABuilder from '../components/admin/BrandDNABuilder';
import WebsiteOSCMS from '../components/admin/WebsiteOSCMS';
import AgentOrchestra from '../components/admin/AgentOrchestra';
import SubAgentManagement from '../components/admin/SubAgentManagement';
import CommandPalette from '../components/admin/CommandPalette';
import IntegrationsHub from '../components/admin/IntegrationsHub';
import GenerativeCoreStudio from '../components/admin/GenerativeCoreStudio';

const moduleCommands = {
  dashboard: [
    { verb: 'Open modules', module: 'Dashboard' },
    { verb: 'Run diagnostics', module: 'Dashboard' },
    { verb: 'Create incident note', module: 'Dashboard' },
  ],
  'repo-admin': [
    { verb: 'Create PR', module: 'Repo Admin' },
    { verb: 'Run tests', module: 'Repo Admin' },
    { verb: 'Rollback to ...', module: 'Repo Admin' },
  ],
  'business-brain': [
    { verb: 'Add source', module: 'Business Brain' },
    { verb: 'Re-embed', module: 'Business Brain' },
    { verb: 'Export KB', module: 'Business Brain' },
  ],
  'brand-dna': [
    { verb: 'Generate guideline PDF', module: 'Brand DNA' },
    { verb: 'Audit current site', module: 'Brand DNA' },
    { verb: 'Validate page/asset', module: 'Brand DNA' },
  ],
  'website-os': [
    { verb: 'Schedule publish 5pm', module: 'WebsiteOS CMS' },
    { verb: 'Restore previous', module: 'WebsiteOS CMS' },
    { verb: 'New content', module: 'WebsiteOS CMS' },
  ],
  'telemetry': [
    { verb: 'Create funnel', module: 'Telemetry' },
    { verb: 'Share report', module: 'Telemetry' },
    { verb: 'Schedule weekly', module: 'Telemetry' },
  ],
  'replicate-ai': [
    { verb: 'Run with preset...', module: 'Replicate AI' },
    { verb: 'Cap budget', module: 'Replicate AI' },
    { verb: 'Switch default model', module: 'Replicate AI' },
  ],
  'ai-modules': [
    { verb: 'Promote to beta', module: 'AI Modules' },
    { verb: 'Analyze cost', module: 'AI Modules' },
  ],
  'mcp-servers': [
    { verb: 'Rotate key', module: 'MCP Servers' },
    { verb: 'Restart all', module: 'MCP Servers' },
  ],
  'dev-services': [
    { verb: 'Restart all', module: 'Dev Services' },
    { verb: 'Open logs', module: 'Dev Services' },
  ],
   'agent-orchestra': [
    { verb: 'New workflow', module: 'Agent Orchestra' },
    { verb: 'View active runs', module: 'Agent Orchestra' },
  ],
  'sub-agents': [
    { verb: 'Evaluate agent', module: 'Sub-Agents' },
    { verb: 'Set new guardrail', module: 'Sub-Agents' },
  ],
};

const moduleComponents = {
  'dashboard': DashboardOverview,
  'repo-admin': RepoAdmin,
  'business-brain': BusinessBrainBuilder,
  'brand-dna': BrandDNABuilder,
  'website-os': WebsiteOSCMS,
  'telemetry': TelemetryDashboard,
  'ai-modules': AIModuleManager,
  'mcp-servers': MCPServerManager,
  'agent-orchestra': AgentOrchestra,
  'dev-services': DevServicesControl,
  'replicate-ai': ReplicateAiPanel,
  'sub-agents': SubAgentManagement,
  'integrations': IntegrationsHub,
  'generative-core': GenerativeCoreStudio
};

export default function AdminPanel() {
  const [activeModule, setActiveModule] = useState('dashboard');
  const [isCommandPaletteOpen, setCommandPaletteOpen] = useState(false);
  const [isSidebarCollapsed, setSidebarCollapsed] = useState(false);

  const handleKeyDown = useCallback((event) => {
    if ((event.metaKey || event.ctrlKey) && event.key === 'k') {
      event.preventDefault();
      setCommandPaletteOpen(open => !open);
    }
  }, []);

  useEffect(() => {
    document.addEventListener('keydown', handleKeyDown);
    return () => {
      document.removeEventListener('keydown', handleKeyDown);
    };
  }, [handleKeyDown]);


  // FIX: Changed 'activeTab' to 'activeModule' to correctly reference the state variable
  const ActiveComponent = moduleComponents[activeModule] || DashboardOverview; 
  const allCommands = Object.values(moduleCommands).flat();

  return (
    <div className="min-h-screen bg-gray-900 flex">
      <AdminSidebar 
        activeModule={activeModule} 
        onModuleChange={setActiveModule}
        isCollapsed={isSidebarCollapsed}
        onToggle={() => setSidebarCollapsed(!isSidebarCollapsed)}
      />
      <main className="flex-1 overflow-auto">
        <div className="p-6">
          <ActiveComponent />
        </div>
      </main>
      <CommandPalette 
        isOpen={isCommandPaletteOpen}
        onClose={() => setCommandPaletteOpen(false)}
        commands={allCommands}
        onCommandSelect={(cmd) => {
            const targetModule = Object.keys(moduleCommands).find(key => moduleCommands[key].some(c => c.verb === cmd.verb));
            if(targetModule) setActiveModule(targetModule);
            console.log('Command selected:', cmd);
        }}
      />
    </div>
  );
}
