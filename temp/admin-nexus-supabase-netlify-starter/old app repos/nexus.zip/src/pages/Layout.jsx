
import React from "react";

export default function Layout({ children }) {
  return (
    <div className="min-h-screen bg-gray-900">
      <style>
        {`
          :root {
            --primary-cyan: #00D4FF;
            --primary-blue: #1E40AF;
            --electric-blue: #3B82F6;
            --accent-green: #10B981;
            --dark-cyan: #0891B2;
            --light-cyan: #A5F3FC;
            --success-green: #059669;
            --warning-yellow: #F59E0B;
            --error-red: #EF4444;
            --dark-bg: #111827;
            --darker-bg: #0F172A;
            --card-bg: #1F2937;
            --border-color: #374151;
          }
          
          /* Custom scrollbar */
          ::-webkit-scrollbar {
            width: 6px;
            height: 6px;
          }
          
          ::-webkit-scrollbar-track {
            background: #1F2937;
          }
          
          ::-webkit-scrollbar-thumb {
            background: #00D4FF;
            border-radius: 3px;
          }
          
          ::-webkit-scrollbar-thumb:hover {
            background: #0891B2;
          }
          
          /* Smooth focus styles */
          *:focus-visible {
            outline: 2px solid #00D4FF;
            outline-offset: 2px;
          }
          
          /* Custom glow effects */
          .glow-cyan {
            box-shadow: 0 0 20px rgba(0, 212, 255, 0.3);
          }
          
          .glow-green {
            box-shadow: 0 0 20px rgba(16, 185, 129, 0.3);
          }
          
          /* Gradient backgrounds */
          .bg-gradient-cyber {
            background: linear-gradient(135deg, #1E40AF 0%, #00D4FF 100%);
          }
          
          .bg-gradient-success {
            background: linear-gradient(135deg, #059669 0%, #10B981 100%);
          }
        `}
      </style>
      {children}
    </div>
  );
}
