import React, { useState, useRef, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { motion } from "framer-motion";
import { 
  Zap, 
  Cpu, 
  Globe, 
  BarChart3, 
  Shield, 
  Rocket,
  ChevronRight,
  Sparkles
} from "lucide-react";
import CommandModal from "../components/admin/CommandModal";

const features = [
  {
    title: "AI-Powered Solutions",
    description: "33 AI modules for SEO, content generation, and automation",
    icon: Cpu,
    count: "33 Modules"
  },
  {
    title: "Global Infrastructure",
    description: "20 MCP servers managing worldwide integrations",
    icon: Globe,
    count: "20 Servers"
  },
  {
    title: "Real-time Analytics",
    description: "Live performance monitoring and business intelligence",
    icon: BarChart3,
    count: "Live Data"
  },
  {
    title: "Advanced Security",
    description: "Enterprise-grade security with automated monitoring",
    icon: Shield,
    count: "24/7"
  }
];

export default function Home() {
  const navigate = useNavigate();
  const [showCommandModal, setShowCommandModal] = useState(false);
  const [clickCount, setClickCount] = useState(0);
  const clickTimeout = useRef(null);
  const logoRef = useRef(null);

  const handleLogoClick = () => {
    setClickCount(prev => prev + 1);

    // Clear existing timeout
    if (clickTimeout.current) {
      clearTimeout(clickTimeout.current);
    }

    // Check for triple click
    if (clickCount === 2) {
      // Triple click detected - show admin modal
      setShowCommandModal(true);
      setClickCount(0);
      
      // Add visual feedback
      if (logoRef.current) {
        logoRef.current.classList.add('animate-pulse');
        setTimeout(() => {
          if (logoRef.current) {
            logoRef.current.classList.remove('animate-pulse');
          }
        }, 500);
      }
      return;
    }

    // Reset click count after 1 second
    clickTimeout.current = setTimeout(() => {
      setClickCount(0);
    }, 1000);
  };

  const handleCommand = (command) => {
    switch (command) {
      case 'admin':
      case 'control':
      case 'sys':
        navigate(createPageUrl('AdminPanel'));
        break;
      case 'figma':
      case 'dev':
      case 'tools':
      case 'scripts':
      case 'matrix':
        // For now, redirect to admin panel - these could be separate pages later
        navigate(createPageUrl('AdminPanel'));
        break;
      default:
        console.log(`Command not recognized: ${command}`);
    }
  };

  useEffect(() => {
    return () => {
      if (clickTimeout.current) {
        clearTimeout(clickTimeout.current);
      }
    };
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-900 to-black relative overflow-hidden">
      {/* Background Effects */}
      <div className="absolute inset-0">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-cyan-500/10 rounded-full blur-3xl"></div>
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-blue-500/10 rounded-full blur-3xl"></div>
      </div>

      <div className="relative z-10">
        {/* Header */}
        <header className="p-6 flex justify-between items-center">
          <div 
            ref={logoRef}
            onClick={handleLogoClick}
            className="flex items-center space-x-3 cursor-pointer transition-all duration-300 hover:scale-105"
          >
            <div className="w-12 h-12 bg-gradient-to-r from-cyan-500 to-blue-500 rounded-xl flex items-center justify-center">
              <Zap className="w-7 h-7 text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-white">Disruptors Media</h1>
              <p className="text-sm text-cyan-400">Digital Innovation Platform</p>
            </div>
          </div>
          <Badge className="bg-gray-800 text-cyan-400 border-cyan-500/30">
            v2.0 ALPHA
          </Badge>
        </header>

        {/* Hero Section */}
        <main className="px-6 py-16">
          <div className="max-w-6xl mx-auto">
            <motion.div
              initial={{ opacity: 0, y: 40 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              className="text-center mb-16"
            >
              <h1 className="text-5xl md:text-7xl font-bold text-white mb-6 leading-tight">
                The Future of
                <span className="bg-gradient-to-r from-cyan-400 to-blue-500 bg-clip-text text-transparent">
                  {" "}Digital Control
                </span>
              </h1>
              <p className="text-xl text-gray-300 mb-8 max-w-3xl mx-auto">
                Harness the power of AI-driven automation, real-time analytics, and intelligent 
                orchestration through our revolutionary platform.
              </p>
              <div className="flex items-center justify-center space-x-4">
                <Button 
                  size="lg" 
                  className="bg-gradient-to-r from-cyan-500 to-blue-500 hover:from-cyan-600 hover:to-blue-600 text-white px-8"
                >
                  <Rocket className="w-5 h-5 mr-2" />
                  Explore Platform
                  <ChevronRight className="w-5 h-5 ml-2" />
                </Button>
                <Button 
                  size="lg" 
                  variant="outline" 
                  className="border-gray-600 text-gray-300 hover:bg-gray-800"
                >
                  Learn More
                </Button>
              </div>
            </motion.div>

            {/* Features Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
              {features.map((feature, index) => (
                <motion.div
                  key={feature.title}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.2 + index * 0.1 }}
                >
                  <Card className="bg-gray-800/50 border-gray-700 hover:border-cyan-500/50 transition-all duration-300 backdrop-blur-sm">
                    <CardHeader className="pb-3">
                      <div className="flex items-center justify-between">
                        <div className="p-3 bg-gradient-to-r from-cyan-500 to-blue-500 rounded-lg">
                          <feature.icon className="w-6 h-6 text-white" />
                        </div>
                        <Badge variant="outline" className="border-cyan-500/50 text-cyan-400">
                          {feature.count}
                        </Badge>
                      </div>
                      <CardTitle className="text-white text-lg">{feature.title}</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-gray-400 text-sm leading-relaxed">
                        {feature.description}
                      </p>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>

            {/* System Status */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.8 }}
            >
              <Card className="bg-gray-800/50 border-gray-700 backdrop-blur-sm">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-4">
                      <div className="flex items-center space-x-2">
                        <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse"></div>
                        <span className="text-green-500 font-semibold">All Systems Operational</span>
                      </div>
                      <div className="flex items-center space-x-6 text-sm text-gray-400">
                        <span>Uptime: 99.9%</span>
                        <span>Response: 142ms</span>
                        <span>Load: 0.42</span>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2 text-cyan-400">
                      <Sparkles className="w-4 h-4" />
                      <span className="text-sm font-semibold">Peak Performance</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            {/* Hidden Easter Egg Hint */}
            <div className="text-center mt-16">
              <p className="text-xs text-gray-600">
                "The most powerful tools are hidden in plain sight" 
                <span className="ml-2 opacity-30">✨</span>
              </p>
            </div>
          </div>
        </main>
      </div>

      {/* Command Modal */}
      <CommandModal 
        isOpen={showCommandModal}
        onClose={() => setShowCommandModal(false)}
        onCommand={handleCommand}
      />
    </div>
  );
}