import React, { useState, useCallback, useMemo } from 'react';
import { KeywordSet } from '@/api/entities';
import { Keyword } from '@/api/entities';
import { KeywordCluster } from '@/api/entities';
import { toast } from 'sonner';
import { Loader2, Plus, BrainCircuit, Table, ListTree } from 'lucide-react';
import KeywordFinderControls from './KeywordFinderControls';
import KeywordSuggestions from './KeywordSuggestions';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from '@/components/ui/button';
import { keywordResearch } from '@/api/functions';

export default function KeywordResults() {
    const [isLoading, setIsLoading] = useState(false);
    const [keywordSet, setKeywordSet] = useState(null);
    const [keywords, setKeywords] = useState([]);
    const [clusters, setClusters] = useState([]);
    const [activeTab, setActiveTab] = useState("clusters");
    const [currentSeedKeywords, setCurrentSeedKeywords] = useState([]);

    const handleSearch = useCallback(async (searchParams) => {
        setIsLoading(true);
        setKeywordSet(null);
        setKeywords([]);
        setClusters([]);
        setCurrentSeedKeywords(searchParams.seedKeywords);
        toast.info("Finding keywords... This may take a moment.", { icon: <BrainCircuit className="w-4 h-4" /> });

        try {
            const response = await keywordResearch(searchParams);
            
            if (response.data.error) {
                throw new Error(response.data.error);
            }

            const { keywords: keywordData, clusters: clusterData } = response.data;

            // Create a new Keyword Set
            const newSet = await KeywordSet.create({
                name: `Research for: ${searchParams.seedKeywords.join(', ')}`,
                locale: searchParams.locale,
                seed_keywords: searchParams.seedKeywords
            });
            setKeywordSet(newSet);

            // Create clusters and save keywords
            const createdClusters = [];
            const allKeywords = [];

            for (const clusterData of clusterData) {
                const newCluster = await KeywordCluster.create({
                    name: clusterData.cluster_name,
                    keyword_set_id: newSet.id
                });
                createdClusters.push({ ...newCluster, keywords: [] });

                for (const keywordText of clusterData.keywords) {
                    const kwData = keywordData.find(k => k.keyword === keywordText);
                    if (kwData) {
                        const newKeyword = await Keyword.create({
                            text: kwData.keyword,
                            locale: searchParams.locale,
                            volume: kwData.volume,
                            cpc: kwData.cpc,
                            competition: kwData.competition,
                            difficulty: kwData.difficulty,
                            intent: kwData.intent,
                            last_checked_at: new Date().toISOString(),
                            cluster_id: newCluster.id,
                            keyword_set_id: newSet.id
                        });
                        allKeywords.push(newKeyword);
                        const targetCluster = createdClusters.find(c => c.id === newCluster.id);
                        if (targetCluster) {
                            targetCluster.keywords.push(newKeyword);
                        }
                    }
                }
            }
            setKeywords(allKeywords);
            setClusters(createdClusters);
            toast.success("Keyword research complete!");

        } catch (error) {
            console.error("Error fetching keyword data:", error);
            toast.error(`Failed to fetch keyword data: ${error.message}`);
        } finally {
            setIsLoading(false);
        }
    }, []);

    const selectedKeywordsCount = 0; // Placeholder

    return (
        <div className="space-y-6">
            <KeywordFinderControls onSearch={handleSearch} isLoading={isLoading} />
            
            <KeywordSuggestions 
                onKeywordSelect={(keyword) => {
                    // This will be handled by the parent component to update the seed keywords
                    const event = new CustomEvent('keywordSuggestionSelected', { 
                        detail: { keyword } 
                    });
                    window.dispatchEvent(event);
                }}
                selectedKeywords={currentSeedKeywords}
            />

            {isLoading && !keywordSet && (
                 <div className="flex flex-col items-center justify-center h-96 dm-card-solid text-center p-8">
                    <Loader2 className="w-12 h-12 text-yellow-400 animate-spin mb-6" />
                    <h3 className="text-2xl font-display dm-text-white">Generating Keyword Insights</h3>
                    <p className="dm-text-gray-300 max-w-md mt-2">Fetching real-time data from DataForSEO API...</p>
                </div>
            )}

            {keywordSet && (
                <div className="dm-card-solid animate-fade-in-up">
                    <div className="p-6 border-b dm-border-gray-700 flex justify-between items-center">
                        <div>
                            <h3 className="font-display text-xl dm-text-white">{keywordSet.name}</h3>
                            <p className="dm-text-gray-400 text-sm">Found {keywords.length} keywords across {clusters.length} clusters.</p>
                        </div>
                        <Button disabled={selectedKeywordsCount === 0} className="dm-button-primary">
                            <Plus className="w-4 h-4 mr-2" />
                            Save {selectedKeywordsCount} Selected Keywords
                        </Button>
                    </div>
                    <Tabs value={activeTab} onValueChange={setActiveTab}>
                        <TabsList className="px-6 border-b dm-border-gray-700">
                             <TabsTrigger value="clusters" className="flex gap-2 items-center"><ListTree className="w-4 h-4" /> Cluster View</TabsTrigger>
                             <TabsTrigger value="table" className="flex gap-2 items-center"><Table className="w-4 h-4" /> Table View</TabsTrigger>
                        </TabsList>
                        <TabsContent value="clusters" className="p-6">
                            <div className="space-y-4">
                                {clusters.map((cluster) => (
                                    <div key={cluster.id} className="border rounded-lg p-4 dm-border-gray-700">
                                        <h4 className="font-semibold dm-text-white mb-2">{cluster.name}</h4>
                                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2">
                                            {cluster.keywords.map((keyword) => (
                                                <div key={keyword.id} className="bg-gray-800 p-2 rounded text-sm">
                                                    <div className="dm-text-white font-medium">{keyword.text}</div>
                                                    <div className="dm-text-gray-400 text-xs">
                                                        Vol: {keyword.volume} • CPC: ${keyword.cpc} • Diff: {keyword.difficulty}
                                                    </div>
                                                </div>
                                            ))}
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </TabsContent>
                        <TabsContent value="table" className="p-6">
                             <div className="overflow-x-auto">
                                <table className="w-full">
                                    <thead>
                                        <tr className="border-b dm-border-gray-700">
                                            <th className="text-left py-2 dm-text-gray-300">Keyword</th>
                                            <th className="text-left py-2 dm-text-gray-300">Volume</th>
                                            <th className="text-left py-2 dm-text-gray-300">CPC</th>
                                            <th className="text-left py-2 dm-text-gray-300">Competition</th>
                                            <th className="text-left py-2 dm-text-gray-300">Difficulty</th>
                                            <th className="text-left py-2 dm-text-gray-300">Intent</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {keywords.map((keyword) => (
                                            <tr key={keyword.id} className="border-b dm-border-gray-800">
                                                <td className="py-2 dm-text-white">{keyword.text}</td>
                                                <td className="py-2 dm-text-gray-300">{keyword.volume?.toLocaleString()}</td>
                                                <td className="py-2 dm-text-gray-300">${keyword.cpc}</td>
                                                <td className="py-2 dm-text-gray-300">{Math.round(keyword.competition * 100)}%</td>
                                                <td className="py-2 dm-text-gray-300">{keyword.difficulty}</td>
                                                <td className="py-2 dm-text-gray-300">{keyword.intent}</td>
                                            </tr>
                                        ))}
                                    </tbody>
                                </table>
                            </div>
                        </TabsContent>
                    </Tabs>
                </div>
            )}
        </div>
    );
}