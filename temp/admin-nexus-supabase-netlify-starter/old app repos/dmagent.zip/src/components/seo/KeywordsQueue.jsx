import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Target, X, Trash2, FileText, Sparkles } from 'lucide-react';
import { toast } from 'sonner';

export default function KeywordsQueue({ keywords, onRemoveKeyword, onClearQueue }) {
    const handleGenerateContentBrief = () => {
        if (keywords.length === 0) {
            toast.error("Add some keywords to your queue first!");
            return;
        }

        // Create a content brief prompt with the selected keywords
        const keywordList = keywords.map(k => k.text).join(', ');
        const prompt = `Create a comprehensive content brief using these target keywords: ${keywordList}

Please include:
1. Content title suggestions
2. Target search intent analysis
3. Recommended content structure
4. Key points to cover
5. Internal linking opportunities

Focus on creating content that would rank well for these keywords while providing genuine value to readers.`;

        // Copy to clipboard for now - in a real app, this could trigger the blog content writer agent
        navigator.clipboard.writeText(prompt).then(() => {
            toast.success("Content brief copied to clipboard! You can now paste this into the Blog Content Writer agent.");
        }).catch(() => {
            toast.error("Failed to copy content brief to clipboard.");
        });
    };

    const getIntentColor = (intent) => {
        switch (intent) {
            case 'Transactional': return 'bg-green-100 text-green-800 border-green-200';
            case 'Commercial': return 'bg-blue-100 text-blue-800 border-blue-200';
            case 'Navigational': return 'bg-purple-100 text-purple-800 border-purple-200';
            case 'Informational': return 'bg-orange-100 text-orange-800 border-orange-200';
            default: return 'bg-gray-100 text-gray-800 border-gray-200';
        }
    };

    return (
        <Card className="dm-card-solid animate-fade-in-up">
            <CardHeader className="pb-4">
                <div className="flex items-center justify-between">
                    <CardTitle className="font-display text-lg dm-text-white flex items-center gap-2">
                        <Target className="w-5 h-5 text-yellow-400" />
                        Keywords Queue
                    </CardTitle>
                    <Badge variant="secondary" className="bg-yellow-500/20 text-yellow-300 border-yellow-500/50">
                        {keywords.length}
                    </Badge>
                </div>
                <p className="text-sm dm-text-gray-400 mt-1">
                    Selected keywords for content creation
                </p>
            </CardHeader>

            <CardContent>
                {keywords.length === 0 ? (
                    <div className="text-center py-8">
                        <Target className="w-12 h-12 dm-text-gray-500 mx-auto mb-4" />
                        <p className="dm-text-gray-400 text-sm">
                            Click keywords from the research results to add them to your queue.
                        </p>
                    </div>
                ) : (
                    <>
                        <ScrollArea className="h-48 mb-4">
                            <div className="space-y-2">
                                {keywords.map((keyword, index) => (
                                    <div 
                                        key={`${keyword.text}-${index}`}
                                        className="flex items-center justify-between bg-gray-800/30 rounded-lg p-3 border border-gray-700"
                                    >
                                        <div className="flex-1 min-w-0">
                                            <div className="flex items-center gap-2 mb-1">
                                                <span className="dm-text-white font-medium truncate">
                                                    {keyword.text}
                                                </span>
                                                <Badge className={`${getIntentColor(keyword.intent)} text-xs`}>
                                                    {keyword.intent}
                                                </Badge>
                                            </div>
                                            <div className="flex items-center gap-3 text-xs dm-text-gray-400">
                                                <span>Vol: {keyword.volume?.toLocaleString() || 'N/A'}</span>
                                                <span>KD: {keyword.difficulty || 'N/A'}</span>
                                                <span>CPC: ${keyword.cpc || '0'}</span>
                                            </div>
                                        </div>
                                        <Button
                                            size="sm"
                                            variant="ghost"
                                            onClick={() => onRemoveKeyword(keyword.text)}
                                            className="text-red-400 hover:text-red-300 hover:bg-red-500/20 h-8 w-8 p-0 ml-2"
                                        >
                                            <X className="w-4 h-4" />
                                        </Button>
                                    </div>
                                ))}
                            </div>
                        </ScrollArea>

                        {/* Action Buttons */}
                        <div className="space-y-2">
                            <Button 
                                onClick={handleGenerateContentBrief}
                                className="dm-button-primary w-full"
                            >
                                <FileText className="w-4 h-4 mr-2" />
                                Generate Content Brief
                            </Button>
                            
                            <div className="flex gap-2">
                                <Button 
                                    onClick={onClearQueue}
                                    variant="outline"
                                    size="sm"
                                    className="flex-1 dm-button-ghost text-red-400 hover:text-red-300"
                                >
                                    <Trash2 className="w-4 h-4 mr-2" />
                                    Clear Queue
                                </Button>
                                <Button 
                                    onClick={() => {
                                        const keywordList = keywords.map(k => k.text).join('\n');
                                        navigator.clipboard.writeText(keywordList).then(() => {
                                            toast.success("Keywords copied to clipboard!");
                                        });
                                    }}
                                    variant="outline"
                                    size="sm"
                                    className="flex-1 dm-button-ghost"
                                >
                                    Copy List
                                </Button>
                            </div>
                        </div>

                        {/* Summary Stats */}
                        <div className="mt-4 pt-4 border-t border-gray-700">
                            <div className="grid grid-cols-2 gap-4 text-center">
                                <div>
                                    <div className="text-lg font-bold dm-text-white">
                                        {Math.round(keywords.reduce((sum, k) => sum + (k.volume || 0), 0) / keywords.length).toLocaleString()}
                                    </div>
                                    <div className="text-xs dm-text-gray-400">Avg. Volume</div>
                                </div>
                                <div>
                                    <div className="text-lg font-bold dm-text-white">
                                        {Math.round(keywords.reduce((sum, k) => sum + (k.difficulty || 0), 0) / keywords.length)}
                                    </div>
                                    <div className="text-xs dm-text-gray-400">Avg. Difficulty</div>
                                </div>
                            </div>
                        </div>
                    </>
                )}
            </CardContent>
        </Card>
    );
}