import React, { useState, useCallback, useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
    Table, 
    TableBody, 
    TableCell, 
    TableHead, 
    TableHeader, 
    TableRow 
} from '@/components/ui/table';
import { 
    Search, 
    ArrowUpDown, 
    ArrowUp, 
    ArrowDown, 
    Plus, 
    BarChart3, 
    Target,
    Loader2,
    Database,
    Filter
} from 'lucide-react';
import { keywordResearch } from '@/api/functions';
import { KeywordSet } from '@/api/entities';
import { Keyword } from '@/api/entities';
import { KeywordCluster } from '@/api/entities';
import { toast } from 'sonner';

export default function KeywordTable({ 
    onSearch, 
    isLoading, 
    keywordData, 
    setKeywordData, 
    selectedKeywords, 
    onToggleKeywordSelection, 
    onAddToQueue,
    currentSeedKeywords
}) {
    const [searchFilter, setSearchFilter] = useState('');
    const [volumeFilter, setVolumeFilter] = useState('all');
    const [difficultyFilter, setDifficultyFilter] = useState('all');
    const [intentFilter, setIntentFilter] = useState('all');
    const [sortConfig, setSortConfig] = useState({ key: 'volume', direction: 'desc' });
    const [currentPage, setCurrentPage] = useState(1);
    const [pageSize] = useState(25);
    const [activeView, setActiveView] = useState('table');

    const handleSearchExecute = useCallback(async (searchParams) => {
        setKeywordData({ keywords: [], clusters: [], totalResults: 0 });
        toast.info("Researching keywords... This may take a moment.", { icon: <BarChart3 className="w-4 h-4" /> });

        try {
            const response = await keywordResearch(searchParams);
            
            if (response.data.error) {
                throw new Error(response.data.error);
            }

            const { keywords: keywordData, clusters: clusterData } = response.data;

            // Create a new Keyword Set
            const newSet = await KeywordSet.create({
                name: `Research for: ${searchParams.seedKeywords.join(', ')}`,
                locale: searchParams.locale,
                seed_keywords: searchParams.seedKeywords
            });

            // Create clusters and save keywords
            const createdClusters = [];
            const allKeywords = [];

            for (const clusterData of clusterData) {
                const newCluster = await KeywordCluster.create({
                    name: clusterData.cluster_name,
                    keyword_set_id: newSet.id
                });
                createdClusters.push({ ...newCluster, keywords: [] });

                for (const keywordText of clusterData.keywords) {
                    const kwData = keywordData.find(k => k.keyword === keywordText);
                    if (kwData) {
                        const newKeyword = await Keyword.create({
                            text: kwData.keyword,
                            locale: searchParams.locale,
                            volume: kwData.volume,
                            cpc: kwData.cpc,
                            competition: kwData.competition,
                            difficulty: kwData.difficulty,
                            intent: kwData.intent,
                            last_checked_at: new Date().toISOString(),
                            cluster_id: newCluster.id,
                            keyword_set_id: newSet.id
                        });
                        allKeywords.push(newKeyword);
                        const targetCluster = createdClusters.find(c => c.id === newCluster.id);
                        if (targetCluster) {
                            targetCluster.keywords.push(newKeyword);
                        }
                    }
                }
            }

            setKeywordData({
                keywords: allKeywords,
                clusters: createdClusters,
                totalResults: allKeywords.length,
                keywordSet: newSet
            });

            toast.success(`Found ${allKeywords.length} keywords across ${createdClusters.length} clusters!`);
            setCurrentPage(1);

        } catch (error) {
            console.error("Error fetching keyword data:", error);
            toast.error(`Failed to fetch keyword data: ${error.message}`);
        }
    }, [setKeywordData]);

    // Forward search calls to our handler
    React.useEffect(() => {
        if (onSearch) {
            onSearch.current = handleSearchExecute;
        }
    }, [handleSearchExecute, onSearch]);

    const getIntentColor = (intent) => {
        switch (intent) {
            case 'Transactional': return 'bg-green-100 text-green-800 border-green-200';
            case 'Commercial': return 'bg-blue-100 text-blue-800 border-blue-200';
            case 'Navigational': return 'bg-purple-100 text-purple-800 border-purple-200';
            case 'Informational': return 'bg-orange-100 text-orange-800 border-orange-200';
            default: return 'bg-gray-100 text-gray-800 border-gray-200';
        }
    };

    const getDifficultyColor = (difficulty) => {
        if (difficulty <= 30) return 'bg-green-500';
        if (difficulty <= 60) return 'bg-yellow-500';
        return 'bg-red-500';
    };

    const filteredKeywords = useMemo(() => {
        let filtered = keywordData.keywords.filter(keyword => {
            const matchesSearch = keyword.text.toLowerCase().includes(searchFilter.toLowerCase());
            const matchesVolume = volumeFilter === 'all' || 
                (volumeFilter === 'high' && keyword.volume >= 1000) ||
                (volumeFilter === 'medium' && keyword.volume >= 100 && keyword.volume < 1000) ||
                (volumeFilter === 'low' && keyword.volume < 100);
            const matchesDifficulty = difficultyFilter === 'all' ||
                (difficultyFilter === 'easy' && keyword.difficulty <= 30) ||
                (difficultyFilter === 'medium' && keyword.difficulty > 30 && keyword.difficulty <= 60) ||
                (difficultyFilter === 'hard' && keyword.difficulty > 60);
            const matchesIntent = intentFilter === 'all' || keyword.intent === intentFilter;
            
            return matchesSearch && matchesVolume && matchesDifficulty && matchesIntent;
        });

        // Apply sorting
        if (sortConfig.key) {
            filtered.sort((a, b) => {
                let aVal = a[sortConfig.key];
                let bVal = b[sortConfig.key];
                
                if (typeof aVal === 'string') {
                    aVal = aVal.toLowerCase();
                    bVal = bVal.toLowerCase();
                }
                
                if (sortConfig.direction === 'asc') {
                    return aVal < bVal ? -1 : aVal > bVal ? 1 : 0;
                } else {
                    return aVal > bVal ? -1 : aVal < bVal ? 1 : 0;
                }
            });
        }

        return filtered;
    }, [keywordData.keywords, searchFilter, volumeFilter, difficultyFilter, intentFilter, sortConfig]);

    const paginatedKeywords = useMemo(() => {
        const startIndex = (currentPage - 1) * pageSize;
        return filteredKeywords.slice(startIndex, startIndex + pageSize);
    }, [filteredKeywords, currentPage, pageSize]);

    const totalPages = Math.ceil(filteredKeywords.length / pageSize);

    const handleSort = (key) => {
        setSortConfig(prev => ({
            key,
            direction: prev.key === key && prev.direction === 'desc' ? 'asc' : 'desc'
        }));
    };

    const getSortIcon = (key) => {
        if (sortConfig.key !== key) return <ArrowUpDown className="w-4 h-4 text-gray-400" />;
        return sortConfig.direction === 'asc' ? 
            <ArrowUp className="w-4 h-4 text-blue-500" /> : 
            <ArrowDown className="w-4 h-4 text-blue-500" />;
    };

    const handleSelectAll = (checked) => {
        if (checked) {
            const newSelections = paginatedKeywords.filter(
                keyword => !selectedKeywords.find(s => s.text === keyword.text)
            );
            newSelections.forEach(onToggleKeywordSelection);
        } else {
            paginatedKeywords.forEach(keyword => {
                if (selectedKeywords.find(s => s.text === keyword.text)) {
                    onToggleKeywordSelection(keyword);
                }
            });
        }
    };

    const isKeywordSelected = (keyword) => {
        return selectedKeywords.some(s => s.text === keyword.text);
    };

    const selectedOnPageCount = paginatedKeywords.filter(isKeywordSelected).length;
    const allOnPageSelected = selectedOnPageCount === paginatedKeywords.length && paginatedKeywords.length > 0;

    return (
        <Card className="dm-card-solid animate-fade-in-up">
            <CardHeader className="border-b dm-border-gray-700">
                <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                    <div>
                        <CardTitle className="font-display text-xl dm-text-white flex items-center gap-2">
                            <Database className="w-5 h-5 text-yellow-400" />
                            Keyword Research Results
                        </CardTitle>
                        <p className="dm-text-gray-400 text-sm mt-1">
                            {filteredKeywords.length} of {keywordData.totalResults} keywords found
                        </p>
                    </div>
                    {selectedKeywords.length > 0 && (
                        <Badge variant="secondary" className="bg-yellow-500/20 text-yellow-300 border-yellow-500/50">
                            {selectedKeywords.length} selected
                        </Badge>
                    )}
                </div>
            </CardHeader>

            <CardContent className="p-6">
                {/* Filters */}
                <div className="flex flex-wrap gap-4 mb-6">
                    <div className="relative flex-1 min-w-[200px]">
                        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                        <Input
                            placeholder="Search keywords..."
                            value={searchFilter}
                            onChange={(e) => setSearchFilter(e.target.value)}
                            className="dm-input pl-10"
                        />
                    </div>
                    
                    <Select value={volumeFilter} onValueChange={setVolumeFilter}>
                        <SelectTrigger className="w-32 dm-input">
                            <SelectValue placeholder="Volume" />
                        </SelectTrigger>
                        <SelectContent>
                            <SelectItem value="all">All Volume</SelectItem>
                            <SelectItem value="high">High (1K+)</SelectItem>
                            <SelectItem value="medium">Medium (100-1K)</SelectItem>
                            <SelectItem value="low">Low (&lt;100)</SelectItem>
                        </SelectContent>
                    </Select>

                    <Select value={difficultyFilter} onValueChange={setDifficultyFilter}>
                        <SelectTrigger className="w-32 dm-input">
                            <SelectValue placeholder="Difficulty" />
                        </SelectTrigger>
                        <SelectContent>
                            <SelectItem value="all">All Difficulty</SelectItem>
                            <SelectItem value="easy">Easy (0-30)</SelectItem>
                            <SelectItem value="medium">Medium (31-60)</SelectItem>
                            <SelectItem value="hard">Hard (61-100)</SelectItem>
                        </SelectContent>
                    </Select>

                    <Select value={intentFilter} onValueChange={setIntentFilter}>
                        <SelectTrigger className="w-40 dm-input">
                            <SelectValue placeholder="Intent" />
                        </SelectTrigger>
                        <SelectContent>
                            <SelectItem value="all">All Intent</SelectItem>
                            <SelectItem value="Informational">Informational</SelectItem>
                            <SelectItem value="Commercial">Commercial</SelectItem>
                            <SelectItem value="Transactional">Transactional</SelectItem>
                            <SelectItem value="Navigational">Navigational</SelectItem>
                        </SelectContent>
                    </Select>
                </div>

                {/* Loading State */}
                {isLoading && (
                    <div className="flex flex-col items-center justify-center h-96">
                        <Loader2 className="w-12 h-12 text-yellow-400 animate-spin mb-6" />
                        <h3 className="text-2xl font-display dm-text-white">Researching Keywords</h3>
                        <p className="dm-text-gray-300 max-w-md mt-2 text-center">
                            Fetching real-time data from DataForSEO API...
                        </p>
                    </div>
                )}

                {/* Results */}
                {!isLoading && keywordData.keywords.length > 0 && (
                    <Tabs value={activeView} onValueChange={setActiveView}>
                        <TabsList className="bg-gray-800/50 border border-gray-700 mb-6">
                            <TabsTrigger value="table" className="data-[state=active]:bg-yellow-500 data-[state=active]:text-gray-900">
                                Table View
                            </TabsTrigger>
                            <TabsTrigger value="clusters" className="data-[state=active]:bg-yellow-500 data-[state=active]:text-gray-900">
                                Cluster View
                            </TabsTrigger>
                        </TabsList>

                        <TabsContent value="table">
                            <div className="rounded-lg border border-gray-700 overflow-hidden">
                                <Table>
                                    <TableHeader className="bg-gray-800/50">
                                        <TableRow className="border-gray-700 hover:bg-gray-800/30">
                                            <TableHead className="w-12">
                                                <Checkbox
                                                    checked={allOnPageSelected}
                                                    onCheckedChange={handleSelectAll}
                                                    className="border-gray-500"
                                                />
                                            </TableHead>
                                            <TableHead 
                                                className="dm-text-gray-300 cursor-pointer hover:dm-text-white"
                                                onClick={() => handleSort('text')}
                                            >
                                                <div className="flex items-center gap-2">
                                                    Keyword {getSortIcon('text')}
                                                </div>
                                            </TableHead>
                                            <TableHead 
                                                className="dm-text-gray-300 cursor-pointer hover:dm-text-white text-right"
                                                onClick={() => handleSort('volume')}
                                            >
                                                <div className="flex items-center gap-2 justify-end">
                                                    Volume {getSortIcon('volume')}
                                                </div>
                                            </TableHead>
                                            <TableHead 
                                                className="dm-text-gray-300 cursor-pointer hover:dm-text-white text-right"
                                                onClick={() => handleSort('cpc')}
                                            >
                                                <div className="flex items-center gap-2 justify-end">
                                                    CPC {getSortIcon('cpc')}
                                                </div>
                                            </TableHead>
                                            <TableHead 
                                                className="dm-text-gray-300 cursor-pointer hover:dm-text-white text-center"
                                                onClick={() => handleSort('difficulty')}
                                            >
                                                <div className="flex items-center gap-2 justify-center">
                                                    KD {getSortIcon('difficulty')}
                                                </div>
                                            </TableHead>
                                            <TableHead 
                                                className="dm-text-gray-300 cursor-pointer hover:dm-text-white"
                                                onClick={() => handleSort('intent')}
                                            >
                                                <div className="flex items-center gap-2">
                                                    Intent {getSortIcon('intent')}
                                                </div>
                                            </TableHead>
                                            <TableHead className="w-20"></TableHead>
                                        </TableRow>
                                    </TableHeader>
                                    <TableBody>
                                        {paginatedKeywords.map((keyword) => (
                                            <TableRow 
                                                key={keyword.id} 
                                                className={`border-gray-700 hover:bg-gray-800/30 ${
                                                    isKeywordSelected(keyword) ? 'bg-yellow-500/10' : ''
                                                }`}
                                            >
                                                <TableCell>
                                                    <Checkbox
                                                        checked={isKeywordSelected(keyword)}
                                                        onCheckedChange={() => onToggleKeywordSelection(keyword)}
                                                        className="border-gray-500"
                                                    />
                                                </TableCell>
                                                <TableCell className="dm-text-white font-medium">
                                                    {keyword.text}
                                                </TableCell>
                                                <TableCell className="dm-text-gray-300 text-right">
                                                    {keyword.volume ? keyword.volume.toLocaleString() : 'N/A'}
                                                </TableCell>
                                                <TableCell className="dm-text-gray-300 text-right">
                                                    ${keyword.cpc || 0}
                                                </TableCell>
                                                <TableCell className="text-center">
                                                    <div className="flex items-center gap-2">
                                                        <div className="flex-1 bg-gray-700 rounded-full h-2">
                                                            <div 
                                                                className={`h-2 rounded-full ${getDifficultyColor(keyword.difficulty)}`}
                                                                style={{ width: `${Math.min(keyword.difficulty, 100)}%` }}
                                                            />
                                                        </div>
                                                        <span className="dm-text-gray-300 text-sm w-8">{keyword.difficulty}</span>
                                                    </div>
                                                </TableCell>
                                                <TableCell>
                                                    <Badge className={getIntentColor(keyword.intent)}>
                                                        {keyword.intent}
                                                    </Badge>
                                                </TableCell>
                                                <TableCell>
                                                    <Button
                                                        size="sm"
                                                        variant="ghost"
                                                        onClick={() => onAddToQueue(keyword)}
                                                        className="dm-button-ghost h-8 w-8 p-0"
                                                    >
                                                        <Plus className="w-4 h-4" />
                                                    </Button>
                                                </TableCell>
                                            </TableRow>
                                        ))}
                                    </TableBody>
                                </Table>
                            </div>

                            {/* Pagination */}
                            {totalPages > 1 && (
                                <div className="flex items-center justify-between mt-6">
                                    <p className="dm-text-gray-400 text-sm">
                                        Showing {((currentPage - 1) * pageSize) + 1} to {Math.min(currentPage * pageSize, filteredKeywords.length)} of {filteredKeywords.length} results
                                    </p>
                                    <div className="flex gap-2">
                                        <Button
                                            variant="outline"
                                            size="sm"
                                            onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
                                            disabled={currentPage === 1}
                                            className="dm-button-ghost"
                                        >
                                            Previous
                                        </Button>
                                        <Button
                                            variant="outline"
                                            size="sm"
                                            onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
                                            disabled={currentPage === totalPages}
                                            className="dm-button-ghost"
                                        >
                                            Next
                                        </Button>
                                    </div>
                                </div>
                            )}
                        </TabsContent>

                        <TabsContent value="clusters">
                            <div className="space-y-4">
                                {keywordData.clusters.map((cluster) => (
                                    <div key={cluster.id} className="border border-gray-700 rounded-lg p-4">
                                        <h4 className="font-semibold dm-text-white mb-3 flex items-center gap-2">
                                            <Target className="w-4 h-4 text-yellow-400" />
                                            {cluster.name}
                                        </h4>
                                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2">
                                            {cluster.keywords.map((keyword) => (
                                                <div 
                                                    key={keyword.id} 
                                                    className="bg-gray-800/50 p-3 rounded border border-gray-700 hover:border-yellow-500/50 transition-colors cursor-pointer"
                                                    onClick={() => onAddToQueue(keyword)}
                                                >
                                                    <div className="dm-text-white font-medium mb-1">{keyword.text}</div>
                                                    <div className="dm-text-gray-400 text-xs flex items-center gap-3">
                                                        <span>Vol: {keyword.volume?.toLocaleString()}</span>
                                                        <span>KD: {keyword.difficulty}</span>
                                                        <Badge className={`${getIntentColor(keyword.intent)} text-xs`}>
                                                            {keyword.intent}
                                                        </Badge>
                                                    </div>
                                                </div>
                                            ))}
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </TabsContent>
                    </Tabs>
                )}

                {/* Empty State */}
                {!isLoading && keywordData.keywords.length === 0 && (
                    <div className="text-center py-12">
                        <Database className="w-16 h-16 dm-text-gray-500 mx-auto mb-4" />
                        <h3 className="text-xl font-display dm-text-white mb-2">Ready for Research</h3>
                        <p className="dm-text-gray-400">
                            Enter your seed keywords and search parameters to discover high-impact keywords for content creation.
                        </p>
                    </div>
                )}
            </CardContent>
        </Card>
    );
}