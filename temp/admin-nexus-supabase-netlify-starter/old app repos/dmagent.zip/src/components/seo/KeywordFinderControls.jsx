
import React, { useState, useEffect, useCallback } from 'react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Search, X } from 'lucide-react';
import { Badge } from '@/components/ui/badge';

export default function KeywordFinderControls({ onSearch, isLoading, compact = false }) {
    const [seedKeywords, setSeedKeywords] = useState('');
    const [keywordTags, setKeywordTags] = useState([]);
    const [locale, setLocale] = useState('us');
    const [language, setLanguage] = useState('en');
    const [device, setDevice] = useState('desktop');

    const addKeywordTag = useCallback((keyword) => {
        if (!keywordTags.includes(keyword) && keyword.trim()) {
            setKeywordTags(prev => [...prev, keyword.trim()]);
        }
    }, [keywordTags]); // keywordTags must be a dependency here for the .includes() check

    // Listen for keyword suggestions from the AI component
    useEffect(() => {
        const handleKeywordSuggestion = (event) => {
            const { keyword } = event.detail;
            addKeywordTag(keyword);
        };

        window.addEventListener('keywordSuggestionSelected', handleKeywordSuggestion);
        return () => {
            window.removeEventListener('keywordSuggestionSelected', handleKeywordSuggestion);
        };
    }, [addKeywordTag]); // addKeywordTag is now a stable function due to useCallback (or changes only when its own deps change)

    const removeKeywordTag = (keywordToRemove) => {
        setKeywordTags(prev => prev.filter(k => k !== keywordToRemove));
    };

    const handleKeywordInput = (e) => {
        setSeedKeywords(e.target.value);
    };

    const handleKeyDown = (e) => {
        if (e.key === 'Enter' && seedKeywords.trim()) {
            e.preventDefault();
            addKeywordTag(seedKeywords);
            setSeedKeywords('');
        } else if (e.key === 'Enter' && keywordTags.length > 0) {
            e.preventDefault();
            handleSearch();
        }
    };

    const handleSearch = () => {
        if (keywordTags.length === 0) return;
        onSearch({
            seedKeywords: keywordTags,
            locale,
            language,
            device
        });
    };

    if (compact) {
        return (
            <div className="space-y-4">
                <div className="space-y-3">
                    <label className="text-sm font-medium dm-text-gray-300">Seed Keywords</label>
                    
                    {/* Display current keywords as tags */}
                    {keywordTags.length > 0 && (
                        <div className="flex flex-wrap gap-2">
                            {keywordTags.map((keyword, index) => (
                                <Badge
                                    key={index}
                                    variant="secondary"
                                    className="bg-yellow-500/20 text-yellow-300 border-yellow-500/50 flex items-center gap-1"
                                >
                                    {keyword}
                                    <X 
                                        className="w-3 h-3 cursor-pointer hover:text-red-300" 
                                        onClick={() => removeKeywordTag(keyword)}
                                    />
                                </Badge>
                            ))}
                        </div>
                    )}
                    
                    <Input
                        placeholder="e.g., roof repair, hvac maintenance"
                        value={seedKeywords}
                        onChange={handleKeywordInput}
                        onKeyDown={handleKeyDown}
                        className="dm-input"
                    />
                    <p className="text-xs dm-text-gray-500">
                        Type keywords and press Enter to add them.
                    </p>
                </div>

                <div className="space-y-3">
                    <div className="space-y-2">
                        <label className="text-sm font-medium dm-text-gray-300">Location</label>
                        <Select value={locale} onValueChange={setLocale}>
                            <SelectTrigger className="dm-input">
                                <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                                <SelectItem value="us">United States</SelectItem>
                                <SelectItem value="gb">United Kingdom</SelectItem>
                                <SelectItem value="ca">Canada</SelectItem>
                                <SelectItem value="au">Australia</SelectItem>
                            </SelectContent>
                        </Select>
                    </div>
                    
                    <div className="space-y-2">
                        <label className="text-sm font-medium dm-text-gray-300">Device</label>
                        <Select value={device} onValueChange={setDevice}>
                            <SelectTrigger className="dm-input">
                                <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                                <SelectItem value="desktop">Desktop</SelectItem>
                                <SelectItem value="mobile">Mobile</SelectItem>
                            </SelectContent>
                        </Select>
                    </div>
                </div>

                <Button 
                    onClick={handleSearch} 
                    disabled={isLoading || keywordTags.length === 0} 
                    className="dm-button-primary w-full flex items-center gap-2"
                >
                    <Search className="w-4 h-4" />
                    <span>{isLoading ? 'Researching...' : `Research (${keywordTags.length})`}</span>
                </Button>
            </div>
        );
    }

    // Original full-width layout for non-compact mode
    return (
        <div className="dm-card-solid p-6 space-y-4">
            <div className="space-y-3">
                <label className="text-sm font-medium dm-text-gray-300">Seed Keywords</label>
                
                {/* Display current keywords as tags */}
                {keywordTags.length > 0 && (
                    <div className="flex flex-wrap gap-2">
                        {keywordTags.map((keyword, index) => (
                            <Badge
                                key={index}
                                variant="secondary"
                                className="bg-yellow-500/20 text-yellow-300 border-yellow-500/50 flex items-center gap-1"
                            >
                                {keyword}
                                <X 
                                    className="w-3 h-3 cursor-pointer hover:text-red-300" 
                                    onClick={() => removeKeywordTag(keyword)}
                                />
                            </Badge>
                        ))}
                    </div>
                )}
                
                <Input
                    placeholder="e.g., roof repair, hvac maintenance (press Enter to add)"
                    value={seedKeywords}
                    onChange={handleKeywordInput}
                    onKeyDown={handleKeyDown}
                    className="dm-input"
                />
                <p className="text-xs dm-text-gray-500">
                    Type keywords and press Enter to add them, or click suggestions below.
                </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 items-end">
                <div className="space-y-2">
                    <label className="text-sm font-medium dm-text-gray-300">Location</label>
                    <Select value={locale} onValueChange={setLocale}>
                        <SelectTrigger className="dm-input"><SelectValue /></SelectTrigger>
                        <SelectContent>
                            <SelectItem value="us">United States</SelectItem>
                            <SelectItem value="gb">United Kingdom</SelectItem>
                            <SelectItem value="ca">Canada</SelectItem>
                            <SelectItem value="au">Australia</SelectItem>
                        </SelectContent>
                    </Select>
                </div>
                <div className="space-y-2">
                    <label className="text-sm font-medium dm-text-gray-300">Device</label>
                    <Select value={device} onValueChange={setDevice}>
                        <SelectTrigger className="dm-input"><SelectValue /></SelectTrigger>
                        <SelectContent>
                            <SelectItem value="desktop">Desktop</SelectItem>
                            <SelectItem value="mobile">Mobile</SelectItem>
                        </SelectContent>
                    </Select>
                </div>
                <div className="md:col-span-2">
                    <Button 
                        onClick={handleSearch} 
                        disabled={isLoading || keywordTags.length === 0} 
                        className="dm-button-primary h-11 w-full flex items-center gap-2"
                    >
                        <Search className="w-4 h-4" />
                        <span>{isLoading ? 'Searching...' : `Find Keywords (${keywordTags.length})`}</span>
                    </Button>
                </div>
            </div>
        </div>
    );
}
