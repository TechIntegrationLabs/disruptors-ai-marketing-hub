import React, { useState, useEffect, useCallback } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from '@/components/ui/button';
import { X, Loader2, Database, ChevronRight, Trash2 } from 'lucide-react';
import { KeywordSet } from '@/api/entities';
import { KeywordCluster } from '@/api/entities';
import { toast } from 'sonner';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Badge } from '@/components/ui/badge';
import { formatDistanceToNow } from 'date-fns';

export default function SavedKeywordsDrawer({ isOpen, onClose }) {
    const [keywordSets, setKeywordSets] = useState([]);
    const [loading, setLoading] = useState(true);
    const [expandedSet, setExpandedSet] = useState(null);

    const loadKeywordSets = useCallback(async () => {
        setLoading(true);
        try {
            const sets = await KeywordSet.list('-created_date');
            const setsWithDetails = await Promise.all(sets.map(async (set) => {
                const clusters = await KeywordCluster.filter({ keyword_set_id: set.id });
                return { ...set, cluster_count: clusters.length };
            }));
            setKeywordSets(setsWithDetails);
        } catch (error) {
            console.error("Error loading saved keyword sets:", error);
            toast.error("Failed to load saved keyword sets.");
        } finally {
            setLoading(false);
        }
    }, []);

    useEffect(() => {
        if (isOpen) {
            loadKeywordSets();
        }
    }, [isOpen, loadKeywordSets]);
    
    const handleToggleExpand = (setId) => {
        setExpandedSet(prev => (prev === setId ? null : setId));
    };

    const handleDeleteSet = async (e, setId, setName) => {
        e.stopPropagation();
        if(window.confirm(`Are you sure you want to delete the keyword set "${setName}"? This will also delete all associated keywords and clusters.`)) {
            try {
                const clusters = await KeywordCluster.filter({ keyword_set_id: setId });
                await Promise.all(clusters.map(c => KeywordCluster.delete(c.id)));
                
                await KeywordSet.delete(setId);

                toast.success(`Keyword set "${setName}" deleted.`);
                loadKeywordSets();

            } catch (error) {
                console.error("Error deleting keyword set:", error);
                toast.error("Failed to delete keyword set.");
            }
        }
    };

    return (
        <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
            <DialogContent className="max-w-lg h-[80vh] dm-bg-navy-light dm-text-white flex flex-col">
                <DialogHeader className="flex-shrink-0">
                    <DialogTitle className="font-display text-2xl dm-text-white">Saved Keywords</DialogTitle>
                    <DialogDescription className="dm-text-gray-400">
                        Manage your saved keyword sets and sync them to the writer.
                    </DialogDescription>
                </DialogHeader>

                <ScrollArea className="flex-1 mt-4">
                    <div className="space-y-4">
                        {loading ? (
                            <div className="flex items-center justify-center h-40">
                                <Loader2 className="w-8 h-8 text-yellow-400 animate-spin" />
                            </div>
                        ) : keywordSets.length === 0 ? (
                            <div className="text-center py-10">
                                <Database className="w-12 h-12 text-gray-500 mx-auto mb-4" />
                                <h4 className="font-semibold text-lg dm-text-white">No Keyword Sets Found</h4>
                                <p className="dm-text-gray-400 text-sm mt-1">Use the finder to create and save your first set.</p>
                            </div>
                        ) : (
                            <div className="space-y-3">
                                {keywordSets.map(set => (
                                    <div key={set.id} className="dm-card-solid bg-gray-800/50 hover:bg-gray-800 transition-colors rounded-lg">
                                        <div className="flex items-center p-4 cursor-pointer" onClick={() => handleToggleExpand(set.id)}>
                                            <div className="flex-1 min-w-0">
                                                <p className="font-semibold dm-text-white truncate">{set.name}</p>
                                                <div className="text-xs dm-text-gray-400 flex items-center gap-4 mt-1">
                                                    <span>{formatDistanceToNow(new Date(set.created_date), { addSuffix: true })}</span>
                                                    <Badge variant="secondary" className="bg-yellow-500/10 text-yellow-300">{set.cluster_count} Clusters</Badge>
                                                </div>
                                            </div>
                                            <div className="flex items-center gap-2">
                                                <Button size="icon" variant="ghost" className="h-8 w-8 text-red-400 hover:bg-red-500/20 hover:text-red-300" onClick={(e) => handleDeleteSet(e, set.id, set.name)}>
                                                    <Trash2 className="w-4 h-4"/>
                                                </Button>
                                                <ChevronRight className={`w-5 h-5 dm-text-gray-400 transition-transform ${expandedSet === set.id ? 'rotate-90' : ''}`} />
                                            </div>
                                        </div>
                                        {expandedSet === set.id && (
                                             <div className="pb-4 px-4 border-t border-gray-700">
                                                <p className="text-sm font-medium dm-text-gray-300 mt-3 mb-2">Seed Keywords:</p>
                                                <div className="flex flex-wrap gap-2">
                                                    {set.seed_keywords.map((sk, i) => (
                                                        <Badge key={i} variant="outline" className="text-gray-300 border-gray-600">{sk}</Badge>
                                                    ))}
                                                </div>
                                             </div>
                                        )}
                                    </div>
                                ))}
                            </div>
                        )}
                    </div>
                </ScrollArea>

                <div className="flex-shrink-0 pt-4 border-t dm-border-gray-700">
                    <Button onClick={onClose} variant="outline" className="dm-button-secondary w-full">
                        Close
                    </Button>
                </div>

                <Button 
                    onClick={onClose} 
                    variant="ghost"
                    size="icon"
                    className="absolute top-4 right-4 text-gray-400 hover:text-white transition-colors"
                >
                    <X className="w-5 h-5" />
                </Button>
            </DialogContent>
        </Dialog>
    );
}