import React, { useState, useEffect, useCallback } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { BrainCircuit, Loader2, RefreshCw, Lightbulb } from 'lucide-react';
import { generateKeywordSuggestions } from '@/api/functions';
import { toast } from 'sonner';

export default function KeywordSuggestions({ onKeywordSelect, selectedKeywords = [] }) {
    const [suggestions, setSuggestions] = useState([]);
    const [loading, setLoading] = useState(false);

    const loadSuggestions = useCallback(async () => {
        setLoading(true);
        try {
            const response = await generateKeywordSuggestions();
            
            if (response.data.error) {
                throw new Error(response.data.error);
            }

            setSuggestions(response.data.keywords || []);
        } catch (error) {
            console.error("Error loading keyword suggestions:", error);
            toast.error("Failed to load keyword suggestions");
            setSuggestions([]);
        } finally {
            setLoading(false);
        }
    }, []);

    useEffect(() => {
        loadSuggestions();
    }, [loadSuggestions]);

    const handleKeywordClick = (keyword) => {
        if (onKeywordSelect) {
            onKeywordSelect(keyword);
        }
    };

    const isSelected = (keyword) => {
        return selectedKeywords.some(selected => 
            selected.toLowerCase().trim() === keyword.toLowerCase().trim()
        );
    };

    return (
        <Card className="dm-card-solid animate-fade-in-up" style={{ animationDelay: '100ms' }}>
            <CardHeader className="pb-4">
                <div className="flex items-center justify-between">
                    <CardTitle className="font-display text-lg dm-text-white flex items-center gap-2">
                        <BrainCircuit className="w-5 h-5 text-yellow-400" />
                        AI Keyword Suggestions
                    </CardTitle>
                    <Button
                        variant="ghost"
                        size="sm"
                        onClick={loadSuggestions}
                        disabled={loading}
                        className="dm-button-ghost"
                    >
                        <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
                    </Button>
                </div>
                <p className="text-sm dm-text-gray-400 mt-1">
                    AI-powered keyword suggestions based on your Business Brain data. Click to add to search.
                </p>
            </CardHeader>
            
            <CardContent>
                {loading ? (
                    <div className="flex items-center justify-center py-8">
                        <Loader2 className="w-6 h-6 text-yellow-400 animate-spin mr-2" />
                        <span className="dm-text-gray-300">Analyzing your business...</span>
                    </div>
                ) : suggestions.length === 0 ? (
                    <div className="text-center py-8">
                        <Lightbulb className="w-8 h-8 dm-text-gray-500 mx-auto mb-2" />
                        <p className="dm-text-gray-400">No suggestions available. Try refreshing or check your Business Brain setup.</p>
                    </div>
                ) : (
                    <div className="space-y-4">
                        <div className="flex flex-wrap gap-2">
                            {suggestions.map((keyword, index) => {
                                const selected = isSelected(keyword);
                                return (
                                    <Badge
                                        key={index}
                                        variant="outline"
                                        className={`cursor-pointer transition-all duration-200 hover:scale-105 ${
                                            selected
                                                ? 'bg-yellow-500/20 text-yellow-300 border-yellow-500/50 shadow-sm'
                                                : 'dm-text-gray-400 border-gray-600 hover:border-yellow-500/50 hover:text-yellow-300'
                                        }`}
                                        onClick={() => handleKeywordClick(keyword)}
                                    >
                                        {keyword}
                                    </Badge>
                                );
                            })}
                        </div>
                        
                        {suggestions.length > 0 && (
                            <div className="pt-3 border-t border-gray-700">
                                <p className="text-xs dm-text-gray-500 text-center">
                                    💡 Tip: Click any keyword to add it to your search terms
                                </p>
                            </div>
                        )}
                    </div>
                )}
            </CardContent>
        </Card>
    );
}