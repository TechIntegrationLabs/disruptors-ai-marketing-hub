
import React, { useState, useEffect, useRef } from 'react';
import { agentSDK } from '@/agents';
import { InvokeLLM } from '@/api/integrations';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Send, Loader2 } from 'lucide-react';
import MessageBubble from './MessageBubble';
import { Client } from '@/api/entities';
import { BlogPost } from '@/api/entities';
import { SocialPost } from '@/api/entities';
import { FileDocument } from '@/api/entities';
import { toast } from 'sonner';

const CONFIRMATION_SEPARATOR = '---|||---Ready to upload to the library?';

export default function ChatInterface({ agent, conversationId, onConversationCreated }) {
    const [conversation, setConversation] = useState(null);
    const [messages, setMessages] = useState([]);
    const [userInput, setUserInput] = useState('');
    const [isLoading, setIsLoading] = useState(true);
    const [isAgentThinking, setIsAgentThinking] = useState(false);
    const [clientData, setClientData] = useState(null);
    const [knowledgeFiles, setKnowledgeFiles] = useState([]);
    const [pendingContent, setPendingContent] = useState(null);
    const [showSaveConfirmation, setShowSaveConfirmation] = useState(false);
    const viewportRef = useRef(null);

    const socialAgents = useRef([
        'instagram_content_creator',
        'facebook_content_creator',
        'linkedin_content_creator',
        'twitter_content_creator',
        'tiktok_content_creator',
        'youtube_content_creator',
        'reddit_content_creator'
    ]).current;

    useEffect(() => {
        const loadClientData = async () => {
            try {
                let clientInfo = await Client.list("name", 1);
                if (clientInfo.length > 0) {
                    setClientData(clientInfo[0]);
                }
            } catch (error) {
                console.error("Error loading client data:", error);
            }
        };
        loadClientData();
    }, []);

    useEffect(() => {
        const loadKnowledgeFiles = async () => {
            if (agent?.name) {
                try {
                    const agentSpecificFiles = await FileDocument.filter({
                        agent_name: agent.name
                    });

                    const sharedFiles = await FileDocument.filter({
                        agent_name: 'shared'
                    });

                    const allFilesMap = new Map();
                    sharedFiles.forEach(file => allFilesMap.set(file.id, file));
                    agentSpecificFiles.forEach(file => allFilesMap.set(file.id, file));

                    const combinedFiles = Array.from(allFilesMap.values());
                    setKnowledgeFiles(combinedFiles);

                } catch (error) {
                    console.error("Error loading knowledge base files:", error);
                    setKnowledgeFiles([]);
                }
            } else {
                setKnowledgeFiles([]);
            }
        };
        loadKnowledgeFiles();
    }, [agent]);

    useEffect(() => {
        const loadConversation = async () => {
            if (conversationId) {
                try {
                    setIsLoading(true);
                    const conv = await agentSDK.getConversation(conversationId);
                    setConversation(conv);
                    setMessages(conv.messages || []);
                } catch (error) {
                    console.error("Error loading conversation:", error);
                    setConversation(null);
                    setMessages([]);
                } finally {
                    setIsLoading(false);
                }
            } else {
                 setConversation(null);
                 setMessages([]);
                 setIsLoading(false);
                 setPendingContent(null);
                 setShowSaveConfirmation(false);
                 setIsAgentThinking(false);
            }
        };

        loadConversation();
    }, [conversationId]);

    useEffect(() => {
        if (conversation) {
            const unsubscribe = agentSDK.subscribeToConversation(conversation.id, (data) => {
                setMessages(data.messages || []);
            });
            return () => unsubscribe();
        }
    }, [conversation]);

    const saveSocialPost = async (contentToSave, originalPrompt) => {
        try {
            const channel = agent.name.replace('_content_creator', '');

            await SocialPost.create({
                channel: channel,
                content: contentToSave,
                original_prompt: originalPrompt || 'Generated content',
                status: 'Suggested',
                ai_generated: true
            });

            toast.success("Social post saved to Library", {
                description: `A new ${agent.display_name} post is now available in the Social Post Library.`,
                duration: 4000
            });

        } catch (error) {
            console.error("Error saving social post to library:", error);
            toast.error("Failed to save to Social Post Library", {
                description: "The post couldn't be saved. You can try again.",
                duration: 6000
            });
        }
    };

    const saveContentToLibrary = async (contentToSave, originalPrompt) => {
        if (agent?.name === 'blog_content_writer') {
            await saveBlogPost(contentToSave);
        } else if (socialAgents.includes(agent?.name)) {
            await saveSocialPost(contentToSave, originalPrompt);
        }
    };

    const saveBlogPost = async (contentToSave) => {
        try {
            const contentStartIndex = contentToSave.search(/<h[1-2][^>]*>|#\s/);
            const cleanContent = contentStartIndex !== -1 ? contentToSave.substring(contentStartIndex) : contentToSave;

            let title = 'AI Generated Blog Post';
            const titleMatch = cleanContent.match(/<h[1-2][^>]*>(.*?)<\/h[1-2]>|^#\s+(.+)/m);
            if (titleMatch) {
                title = (titleMatch[1] || titleMatch[2] || '').replace(/<[^>]*>/g, '').trim();
            }

            if (title.length > 100) {
                title = title.substring(0, 97) + '...';
            }

            await BlogPost.create({
                title: title,
                content: cleanContent,
                keywords: clientData?.focus_keywords || '',
                status: 'Draft',
                ai_generated: true
            });

            toast.success("Blog post saved to Library", {
                description: `"${title}" is now available in the Blog Library.`,
                duration: 4000
            });

        } catch (error) {
            console.error("Error saving blog content to library:", error);
            toast.error("Failed to save to Blog Library", {
                description: "The blog post couldn't be saved. You can try again.",
                duration: 6000
            });
        }
    };


    useEffect(() => {
        if (viewportRef.current) {
            viewportRef.current.scrollTo({
                top: viewportRef.current.scrollHeight,
                behavior: 'smooth'
            });
        }

        const lastMessage = messages[messages.length - 1];

        if (isAgentThinking && lastMessage?.role === 'assistant') {
            setIsAgentThinking(false);
        }

        const isSavableAgent = agent?.name === 'blog_content_writer' || socialAgents.includes(agent?.name);

        if (isSavableAgent && lastMessage?.role === 'assistant' && lastMessage.content?.includes(CONFIRMATION_SEPARATOR)) {
            const parts = lastMessage.content.split(CONFIRMATION_SEPARATOR);
            const content = parts[0];
            setPendingContent(content);
            setShowSaveConfirmation(true);
        } else {
            if(lastMessage?.role === 'user' || (lastMessage?.role === 'assistant' && !lastMessage?.content?.includes(CONFIRMATION_SEPARATOR))) {
                setShowSaveConfirmation(false);
                setPendingContent(null);
            }
        }
    }, [messages, agent, isAgentThinking, socialAgents]);

    const generateConversationTitle = async (firstMessage) => {
        try {
            const response = await InvokeLLM({
                prompt: `Create a very short, concise title (4-6 words) for a conversation that starts with this message: "${firstMessage}". The title should capture the main topic or request. Examples: "Blog Ideas for Tech Startup", "Social Media Content Strategy", "SEO Keywords Research"`,
                response_json_schema: {
                    type: "object",
                    properties: {
                        title: {
                            type: "string",
                            description: "A short, 4-6 word title for the conversation."
                        }
                    },
                    required: ["title"]
                }
            });
            return response.title;
        } catch (error) {
            console.error("Error generating title:", error);
            return firstMessage.length > 50 ? firstMessage.substring(0, 50) + '...' : firstMessage;
        }
    };

    const createConversationFromFirstMessage = async (firstMessage) => {
        setIsLoading(true);
        try {
            const conversationName = await generateConversationTitle(firstMessage);

            const newConv = await agentSDK.createConversation({
                agent_name: agent?.name,
                metadata: {
                    name: conversationName,
                }
            });

            if (onConversationCreated) {
                onConversationCreated(newConv);
            }

            setConversation(newConv);
            setMessages(newConv.messages || []);
            return newConv;
        } catch (error) {
            console.error("Error creating conversation:", error);
            return null;
        } finally {
            setIsLoading(false);
        }
    };

    const handleSendMessage = async (messageText) => {
        const contentToSend = messageText || userInput;
        if (!contentToSend.trim() || !agent) return;

        setUserInput('');
        setShowSaveConfirmation(false);
        setIsAgentThinking(true);

        try {
            let currentConversation = conversation;

            if (!currentConversation) {
                currentConversation = await createConversationFromFirstMessage(contentToSend);
                if (!currentConversation) {
                    setUserInput(contentToSend);
                    setIsAgentThinking(false);
                    return;
                }
            }

            const finalMessageContent = createAgentContext(clientData, contentToSend);

            await agentSDK.addMessage(currentConversation, {
                role: 'user',
                content: finalMessageContent,
            });

        } catch (error) {
            console.error("Error sending message:", error);
            toast.error("Message Failed to Send", {
                description: "There was a problem sending your message. Please try again in a moment.",
                duration: 6000
            });
            setUserInput(contentToSend);
            setIsAgentThinking(false);
        }
    };

    const handleConfirmation = async (shouldSave) => {
        setShowSaveConfirmation(false);
        if (shouldSave) {
            if (pendingContent) {
                const lastUserMessage = displayedMessages.filter(msg => msg.role === 'user').pop();
                const originalPrompt = lastUserMessage?.content || 'Generated content';

                await saveContentToLibrary(pendingContent, originalPrompt);
                setPendingContent(null);
            }
        } else {
            setPendingContent(null);
            toast.info("You can type your revisions below.", { duration: 3000 });
        }
    };

    const createAgentContext = (clientSettings, userMessage) => {
        if (agent?.name === 'general_content_assistant') {
            return userMessage;
        }

        const agentName = agent?.display_name || agent?.name?.split('_').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ') || 'Content Creator';

        let context = `You are ${agentName} for Disruptors Media. The user's request is: "${userMessage}"`;

        if (knowledgeFiles.length > 0) {
            context += `\n\n**IMPORTANT CONTEXT**: The user has uploaded ${knowledgeFiles.length} reference document(s) to the knowledge base. These include files like: ${knowledgeFiles.map(f => f.filename).slice(0, 3).join(', ')}${knowledgeFiles.length > 3 ? ` and ${knowledgeFiles.length - 3} more` : ''}. Use your understanding of best practices for this type of content creation, keeping in mind that there are likely specific brand guidelines, style requirements, or reference materials that should inform your response.`;
        }

        if (clientSettings) {
            context += `\n\n**DISRUPTORS MEDIA CLIENT PROFILE:**`;

            // Basic Business Info
            context += `\n- Company: ${clientSettings.name}`;
            if (clientSettings.industry) context += `\n- Industry: ${clientSettings.industry}`;
            if (clientSettings.category) context += `\n- Category: ${clientSettings.category}`;
            if (clientSettings.sub_niche) context += `\n- Sub-niche: ${clientSettings.sub_niche}`;
            if (clientSettings.service_area) context += `\n- Service Area: ${clientSettings.service_area}`;
            if (clientSettings.service_details) context += `\n- Business Focus: ${clientSettings.service_details}`;

            // Business Brain Data
            if (clientSettings.owner_name) context += `\n- Owner: ${clientSettings.owner_name}${clientSettings.owner_role ? ` (${clientSettings.owner_role})` : ''}`;
            if (clientSettings.avg_ticket_ltv_range) context += `\n- Avg Ticket/LTV: ${clientSettings.avg_ticket_ltv_range}`;
            if (clientSettings.top_services_products?.length > 0) {
                context += `\n- Top Services: ${clientSettings.top_services_products.join(', ')}`;
            }

            // Brand DNA
            if (clientSettings.brand_personality) {
                context += `\n\n**BRAND DNA:**`;
                context += `\n- Personality: ${clientSettings.brand_personality}`;
            }
            if (clientSettings.brand_traits?.length > 0) {
                context += `\n- Traits: ${clientSettings.brand_traits.join(', ')}`;
            }
            if (clientSettings.messaging_pillars?.length > 0) {
                context += `\n- Messaging Pillars: ${clientSettings.messaging_pillars.join('; ')}`;
            }

            // Voice & Tone Settings
            if (clientSettings.voice_tone) {
                const tone = clientSettings.voice_tone;
                context += `\n\n**VOICE & TONE SETTINGS:**`;
                if (tone.clarity_vs_jargon) context += `\n- Clarity vs Jargon: ${tone.clarity_vs_jargon}/5 (higher = more clarity, less jargon)`;
                if (tone.empathy_level) context += `\n- Empathy Level: ${tone.empathy_level}/5`;
                if (tone.authority_vs_humility) context += `\n- Authority vs Humility: ${tone.authority_vs_humility}/5`;
                if (tone.formality_level) context += `\n- Formality: ${tone.formality_level}/5 (lower = more casual)`;
                if (tone.risk_taking) context += `\n- Risk Taking: ${tone.risk_taking}/5`;
            }

            // Language Guidelines
            if (clientSettings.language_dos) context += `\n\n**LANGUAGE DO'S:** ${clientSettings.language_dos}`;
            if (clientSettings.language_donts) context += `\n**LANGUAGE DON'TS:** ${clientSettings.language_donts}`;

            // ICP Information
            if (clientSettings.icp_segments?.length > 0) {
                context += `\n\n**TARGET AUDIENCE (ICP):`;
                clientSettings.icp_segments.forEach((segment, index) => {
                    context += `\n${index + 1}. ${segment.name}: ${segment.description}`;
                    if (segment.goals?.length > 0) context += `\n   Goals: ${segment.goals.join(', ')}`;
                    if (segment.fears?.length > 0) context += `\n   Fears: ${segment.fears.join(', ')}`;
                });
            }

            // SEO Keywords
            if (clientSettings.focus_keywords) {
                context += `\n\n**SEO KEYWORDS (select 1-3 strategically):** ${clientSettings.focus_keywords}`;
            }

            // Keyword Clusters
            if (clientSettings.keyword_clusters) {
                context += `\n\n**KEYWORD CLUSTERS:**`;
                Object.entries(clientSettings.keyword_clusters).forEach(([category, keywords]) => {
                    if (keywords?.length > 0) {
                        context += `\n- ${category.replace('_', ' ').toUpperCase()}: ${keywords.join(', ')}`;
                    }
                });
            }

            // Style Examples
            if (clientSettings.style_examples) {
                const examples = clientSettings.style_examples;
                context += `\n\n**STYLE EXAMPLES:**`;
                if (examples.hooks?.length > 0) context += `\n- Hooks: ${examples.hooks.join('; ')}`;
                if (examples.ctas?.length > 0) context += `\n- CTAs: ${examples.ctas.join('; ')}`;
                if (examples.social_closers?.length > 0) context += `\n- Social Closers: ${examples.social_closers.join('; ')}`;
            }

            // Owner Voice Samples
            if (clientSettings.owner_voice_idioms?.length > 0) {
                context += `\n\n**OWNER VOICE PATTERNS:** ${clientSettings.owner_voice_idioms.join('; ')}`;
            }
            if (clientSettings.regional_cues) {
                context += `\n**REGIONAL LANGUAGE:** ${clientSettings.regional_cues}`;
            }

            // Compliance & Constraints
            if (clientSettings.compliance_constraints) {
                context += `\n\n**COMPLIANCE CONSTRAINTS:** ${clientSettings.compliance_constraints}`;
            }

            // Content Frameworks
            if (clientSettings.content_frameworks) {
                context += `\n\n**CONTENT FRAMEWORKS:** Follow the specific guidelines for each content type as defined in your core instructions.`;
            }

            // Prose Constraints
            if (clientSettings.prose_constraints) {
                const prose = clientSettings.prose_constraints;
                context += `\n\n**WRITING CONSTRAINTS:**`;
                if (prose.max_sentence_length) context += `\n- Max sentence length: ${prose.max_sentence_length} words`;
                if (prose.concrete_to_jargon_ratio) context += `\n- Concrete to jargon ratio: ${prose.concrete_to_jargon_ratio}`;
                if (prose.reading_level) context += `\n- Reading level: ${prose.reading_level}`;
                if (prose.proof_requirement) context += `\n- Proof requirement: ${prose.proof_requirement}`;
            }

            // Legacy AI Writing Directives (fallback)
            if (clientSettings.ai_writing_directives) {
                context += `\n\n**ADDITIONAL WRITING GUIDELINES:** ${clientSettings.ai_writing_directives}`;
            }
        }

        const isSavableAgent = agent?.name === 'blog_content_writer' || socialAgents.includes(agent?.name);
        if (isSavableAgent) {
             context += `\n\n**CRITICAL OUTPUT INSTRUCTION:** Your response MUST be ONLY the generated content following the Disruptors Media brand guidelines above. Do NOT include any conversational preamble, introductions, or explanations like "Here is the content you requested:". The output must be ready for direct storage. AFTER the complete content, you MUST append this exact string: "${CONFIRMATION_SEPARATOR}" (without quotes). This separator signals the completion of the content and readiness for review/saving.`;
        }

        return context;
    };

    const agentDisplayName = agent?.display_name || agent?.name?.split('_').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ') || 'AI Agent';

    const displayedMessages = messages.map(msg => {
        if (msg.role === 'assistant' && msg.content?.includes(CONFIRMATION_SEPARATOR)) {
            return { ...msg, content: msg.content.split(CONFIRMATION_SEPARATOR)[0] };
        }
        if (msg.role === 'user' && msg.content?.includes("DISRUPTORS MEDIA CLIENT PROFILE:")) {
            const match = msg.content.match(/The user's request is: "(.*?)"/s);
            const originalContent = match ? match[1] : "Processing request...";
            return { ...msg, content: originalContent };
        }
        return msg;
    });

    return (
        <div className="flex flex-col h-full">
            <div className="border-b dm-border-steel p-4 bg-white">
                <h2 className="font-semibold dm-text-ink text-lg flex items-center gap-2 font-sans">
                    {agentDisplayName}
                    {(agent?.name === 'blog_content_writer' || socialAgents.includes(agent?.name)) && (
                        <span className="text-sm dm-bg-signal text-white px-2 py-1 rounded-full font-sans">
                            Library-Enabled
                        </span>
                    )}
                </h2>
                <div className="text-sm dm-text-steel mt-1 flex items-center gap-4">
                    <span>
                        Ready to create disruptive content for {clientData?.name || 'your business'}.
                    </span>
                    {knowledgeFiles.length > 0 && (
                        <span className="text-xs dm-bg-mint dm-text-ink px-2 py-1 rounded-full font-medium font-sans">
                            {knowledgeFiles.length} reference file(s) available
                        </span>
                    )}
                </div>
            </div>

            <ScrollArea className="flex-1 p-4 dm-bg-paper" ref={viewportRef}>
                {isLoading ? (
                    <div className="flex justify-center items-center h-32">
                        <Loader2 className="w-6 h-6 animate-spin dm-text-steel" />
                    </div>
                ) : (
                    <>
                        <div className="space-y-4">
                            {displayedMessages.map((message, index) => (
                                <MessageBubble key={message.id || index} message={message} agent={agent} />
                            ))}
                        </div>
                        {isAgentThinking && (
                            <MessageBubble message={{ role: 'assistant' }} isTyping={true} />
                        )}
                    </>
                )}
            </ScrollArea>

            <div className="border-t dm-border-steel p-4 bg-white">
                 {showSaveConfirmation && (
                    <div className="flex flex-col sm:flex-row items-center justify-center gap-2 sm:gap-4 mb-4 p-3 dm-bg-mint rounded-lg">
                        <p className="text-sm font-semibold dm-text-ink text-center sm:text-left font-sans">Ready to save to the library?</p>
                        <div className="flex gap-2">
                            <Button size="sm" className="dm-button-primary" onClick={() => handleConfirmation(true)}>Yes, Save</Button>
                            <Button size="sm" className="dm-button-secondary" onClick={() => handleConfirmation(false)}>No, I have changes</Button>
                        </div>
                    </div>
                )}
                <div className="flex gap-2">
                    <Input
                        value={userInput}
                        onChange={(e) => setUserInput(e.target.value)}
                        placeholder={showSaveConfirmation ? "Type here to make revisions..." : "Ask me to create disruptive content..."}
                        className="flex-1"
                        onKeyDown={(e) => {
                            if (e.key === 'Enter' && !e.shiftKey) {
                                e.preventDefault();
                                handleSendMessage();
                            }
                        }}
                        disabled={isAgentThinking}
                    />
                    <Button
                        onClick={() => handleSendMessage()}
                        disabled={!userInput.trim() || isAgentThinking}
                        className="dm-button-primary"
                    >
                        {isAgentThinking ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
                    </Button>
                </div>
            </div>
        </div>
    );
}
