import React from 'react';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

export default function AgentPicker({ agents, selectedAgent, onAgentChange }) {
    const handleSelect = (agentName) => {
        if (onAgentChange) {
            onAgentChange(agentName);
        }
    };

    return (
        <div className="p-4 space-y-2">
            {agents.map((agent) => (
                <Button
                    key={agent.name}
                    onClick={() => handleSelect(agent.name)}
                    variant="ghost"
                    className={cn(
                        "w-full justify-start gap-3 px-3 py-6 h-auto text-left dm-text-gray-300 hover:dm-text-white hover:bg-gray-700/50",
                        selectedAgent?.name === agent.name && "bg-yellow-500/20 dm-text-gold hover:bg-yellow-500/30 hover:dm-text-gold"
                    )}
                >
                    <div className={cn(
                        "p-2 rounded-lg",
                        selectedAgent?.name === agent.name ? "bg-yellow-500/20" : "bg-gray-700/50"
                    )}>
                        <agent.icon className={cn(
                            "w-5 h-5",
                            selectedAgent?.name === agent.name ? "dm-text-gold" : "dm-text-gray-400"
                        )} />
                    </div>
                    <div className="flex-1">
                        <p className="font-semibold">{agent.display_name}</p>
                        <p className="text-xs dm-text-gray-400">{agent.category}</p>
                    </div>
                </Button>
            ))}
        </div>
    );
}