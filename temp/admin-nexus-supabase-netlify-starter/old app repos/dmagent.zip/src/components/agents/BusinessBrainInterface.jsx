import React, { useState, useEffect } from 'react';
import { Client } from '@/api/entities';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';
import { BrainCircuit, Save, Loader2, Plus, X, Building, Users, MessageSquare, Target, Zap } from 'lucide-react';

export default function BusinessBrainInterface({ onClientUpdated }) {
  const [client, setClient] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [activeTab, setActiveTab] = useState('profile');

  // Form states
  const [basicInfo, setBasicInfo] = useState({});
  const [brandDNA, setBrandDNA] = useState({});
  const [voiceTone, setVoiceTone] = useState({});
  const [icpSegments, setIcpSegments] = useState([]);
  const [keywordClusters, setKeywordClusters] = useState({});
  const [styleExamples, setStyleExamples] = useState({});
  const [contentFrameworks, setContentFrameworks] = useState({});
  const [proseConstraints, setProseConstraints] = useState({});

  useEffect(() => {
    loadClientData();
  }, []);

  const loadClientData = async () => {
    setIsLoading(true);
    try {
      let clientData = await Client.list("name", 1);
      
      if (clientData.length === 0) {
        const defaultClient = await Client.create({
          name: "My Business",
          hourly_rate: 0,
          currency: "USD",
          color: "#FF3B30",
          status: "active",
          brand_personality: "Challenger",
          prose_constraints: {
            max_sentence_length: 20,
            concrete_to_jargon_ratio: "70/30",
            reading_level: "Grade 7-9",
            proof_requirement: "1 claim → 1 proof link"
          }
        });
        clientData = [defaultClient];
      }
      
      const loadedClient = clientData[0];
      setClient(loadedClient);
      
      // Set form states
      setBasicInfo({
        name: loadedClient.name || '',
        primary_url: loadedClient.primary_url || '',
        owner_name: loadedClient.owner_name || '',
        owner_role: loadedClient.owner_role || '',
        category: loadedClient.category || '',
        sub_niche: loadedClient.sub_niche || '',
        service_area: loadedClient.service_area || '',
        avg_ticket_ltv_range: loadedClient.avg_ticket_ltv_range || '',
        top_services_products: loadedClient.top_services_products || ['', '', ''],
        compliance_constraints: loadedClient.compliance_constraints || ''
      });

      setBrandDNA({
        brand_personality: loadedClient.brand_personality || 'Challenger',
        brand_traits: loadedClient.brand_traits || [],
        messaging_pillars: loadedClient.messaging_pillars || [],
        taglines_value_props: loadedClient.taglines_value_props || [],
        language_dos: loadedClient.language_dos || '',
        language_donts: loadedClient.language_donts || ''
      });

      setVoiceTone(loadedClient.voice_tone || {
        clarity_vs_jargon: 4,
        empathy_level: 4,
        authority_vs_humility: 4,
        formality_level: 2,
        risk_taking: 3
      });

      setIcpSegments(loadedClient.icp_segments || []);
      setKeywordClusters(loadedClient.keyword_clusters || {});
      setStyleExamples(loadedClient.style_examples || { hooks: [], ctas: [], social_closers: [] });
      setContentFrameworks(loadedClient.content_frameworks || {});
      setProseConstraints(loadedClient.prose_constraints || {
        max_sentence_length: 20,
        concrete_to_jargon_ratio: "70/30",
        reading_level: "Grade 7-9",
        proof_requirement: "1 claim → 1 proof link"
      });

    } catch (error) {
      console.error("Failed to load client data", error);
      toast.error("Could not load Business Brain data.");
    } finally {
      setIsLoading(false);
    }
  };

  const saveBusinessBrain = async () => {
    if (!client) return;
    
    setIsSaving(true);
    try {
      const updatedClient = {
        ...basicInfo,
        ...brandDNA,
        voice_tone: voiceTone,
        icp_segments: icpSegments,
        keyword_clusters: keywordClusters,
        style_examples: styleExamples,
        content_frameworks: contentFrameworks,
        prose_constraints: proseConstraints,
        focus_keywords: Object.values(keywordClusters).flat().join(', '),
        owner_voice_idioms: styleExamples.hooks?.concat(styleExamples.social_closers || []) || []
      };

      await Client.update(client.id, updatedClient);
      
      if (onClientUpdated) {
        onClientUpdated(updatedClient);
      }
      
      toast.success("Business Brain updated successfully! All AI agents will now use this information.", {
        duration: 4000
      });
      
      await loadClientData(); // Refresh
    } catch (error) {
      console.error("Error saving Business Brain:", error);
      toast.error("Failed to save Business Brain. Please try again.");
    } finally {
      setIsSaving(false);
    }
  };

  const addIcpSegment = () => {
    setIcpSegments([...icpSegments, {
      name: '',
      description: '',
      goals: [],
      fears: [],
      triggers: []
    }]);
  };

  const updateIcpSegment = (index, field, value) => {
    const updated = [...icpSegments];
    updated[index] = { ...updated[index], [field]: value };
    setIcpSegments(updated);
  };

  const removeIcpSegment = (index) => {
    setIcpSegments(icpSegments.filter((_, i) => i !== index));
  };

  if (isLoading) {
    return (
      <Card className="dm-card">
        <CardContent className="dm-generous-spacing flex items-center justify-center">
          <Loader2 className="w-8 h-8 animate-spin dm-text-steel" />
          <span className="ml-2 dm-text-steel">Loading Business Brain...</span>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <Card className="dm-card border-2 dm-border-signal">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 font-headline dm-text-ink">
            <BrainCircuit className="w-6 h-6 dm-text-signal" />
            Business Brain Configuration
          </CardTitle>
          <CardDescription>
            Configure your business profile and brand DNA. This information powers all AI agents to create content that sounds authentically like your business.
          </CardDescription>
        </CardHeader>
      </Card>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="profile" className="flex items-center gap-2">
            <Building className="w-4 h-4" />
            Profile
          </TabsTrigger>
          <TabsTrigger value="brand" className="flex items-center gap-2">
            <Zap className="w-4 h-4" />
            Brand DNA
          </TabsTrigger>
          <TabsTrigger value="voice" className="flex items-center gap-2">
            <MessageSquare className="w-4 h-4" />
            Voice & Tone
          </TabsTrigger>
          <TabsTrigger value="audience" className="flex items-center gap-2">
            <Users className="w-4 h-4" />
            Audience
          </TabsTrigger>
          <TabsTrigger value="content" className="flex items-center gap-2">
            <Target className="w-4 h-4" />
            Content
          </TabsTrigger>
        </TabsList>

        <TabsContent value="profile" className="space-y-6">
          <Card className="dm-card">
            <CardHeader>
              <CardTitle className="font-headline">Business Profile</CardTitle>
              <CardDescription>Core information about your business</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Business Name</Label>
                  <Input
                    value={basicInfo.name}
                    onChange={(e) => setBasicInfo({...basicInfo, name: e.target.value})}
                    placeholder="Your business name"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Primary Website URL</Label>
                  <Input
                    value={basicInfo.primary_url}
                    onChange={(e) => setBasicInfo({...basicInfo, primary_url: e.target.value})}
                    placeholder="https://yourbusiness.com"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Owner Name</Label>
                  <Input
                    value={basicInfo.owner_name}
                    onChange={(e) => setBasicInfo({...basicInfo, owner_name: e.target.value})}
                    placeholder="Business owner name"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Owner Role/Title</Label>
                  <Input
                    value={basicInfo.owner_role}
                    onChange={(e) => setBasicInfo({...basicInfo, owner_role: e.target.value})}
                    placeholder="CEO, Founder, Owner, etc."
                  />
                </div>
                <div className="space-y-2">
                  <Label>Industry Category</Label>
                  <Input
                    value={basicInfo.category}
                    onChange={(e) => setBasicInfo({...basicInfo, category: e.target.value})}
                    placeholder="e.g., Construction, HVAC, Roofing"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Sub-Niche</Label>
                  <Input
                    value={basicInfo.sub_niche}
                    onChange={(e) => setBasicInfo({...basicInfo, sub_niche: e.target.value})}
                    placeholder="e.g., Residential roofing, Commercial HVAC"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Service Area</Label>
                  <Input
                    value={basicInfo.service_area}
                    onChange={(e) => setBasicInfo({...basicInfo, service_area: e.target.value})}
                    placeholder="e.g., Denver Metro, Colorado Springs"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Average Ticket/LTV Range</Label>
                  <Input
                    value={basicInfo.avg_ticket_ltv_range}
                    onChange={(e) => setBasicInfo({...basicInfo, avg_ticket_ltv_range: e.target.value})}
                    placeholder="e.g., $500-$2,000, $10k-$50k"
                  />
                </div>
              </div>
              
              <div className="space-y-2">
                <Label>Top 3 Services/Products (Priority Order)</Label>
                {basicInfo.top_services_products?.map((service, index) => (
                  <Input
                    key={index}
                    value={service}
                    onChange={(e) => {
                      const updated = [...basicInfo.top_services_products];
                      updated[index] = e.target.value;
                      setBasicInfo({...basicInfo, top_services_products: updated});
                    }}
                    placeholder={`Service/Product ${index + 1}`}
                  />
                ))}
              </div>

              <div className="space-y-2">
                <Label>Compliance Constraints</Label>
                <Textarea
                  value={basicInfo.compliance_constraints}
                  onChange={(e) => setBasicInfo({...basicInfo, compliance_constraints: e.target.value})}
                  placeholder="Any regulatory constraints, prohibited claims, required disclaimers..."
                  rows={3}
                />
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="brand" className="space-y-6">
          <Card className="dm-card">
            <CardHeader>
              <CardTitle className="font-headline">Brand DNA</CardTitle>
              <CardDescription>Define your brand's personality and core messaging</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <Label>Brand Personality/Archetype</Label>
                <Select value={brandDNA.brand_personality} onValueChange={(value) => setBrandDNA({...brandDNA, brand_personality: value})}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Challenger">Challenger - Disruptive, questions status quo</SelectItem>
                    <SelectItem value="Mentor">Mentor - Wise guide, helpful teacher</SelectItem>
                    <SelectItem value="Expert">Expert - Authoritative, knowledgeable</SelectItem>
                    <SelectItem value="Innovator">Innovator - Creative, forward-thinking</SelectItem>
                    <SelectItem value="Caregiver">Caregiver - Nurturing, supportive</SelectItem>
                    <SelectItem value="Other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Brand Traits (comma-separated)</Label>
                <Input
                  value={brandDNA.brand_traits?.join(', ') || ''}
                  onChange={(e) => setBrandDNA({...brandDNA, brand_traits: e.target.value.split(',').map(s => s.trim()).filter(s => s)})}
                  placeholder="Direct, Bold, Practical, No-BS, Pro-craft"
                />
              </div>

              <div className="space-y-2">
                <Label>Messaging Pillars (up to 5)</Label>
                <Textarea
                  value={brandDNA.messaging_pillars?.join('\n') || ''}
                  onChange={(e) => setBrandDNA({...brandDNA, messaging_pillars: e.target.value.split('\n').filter(s => s.trim())})}
                  placeholder="Practical AI, real results&#10;Owner's voice wins&#10;System > one-off&#10;Proof over promises&#10;Community & connection"
                  rows={5}
                />
              </div>

              <div className="space-y-2">
                <Label>Language DO's</Label>
                <Textarea
                  value={brandDNA.language_dos}
                  onChange={(e) => setBrandDNA({...brandDNA, language_dos: e.target.value})}
                  placeholder="Short, vivid verbs; concrete examples; numbers; owner quotes; local cues"
                  rows={3}
                />
              </div>

              <div className="space-y-2">
                <Label>Language DON'Ts</Label>
                <Textarea
                  value={brandDNA.language_donts}
                  onChange={(e) => setBrandDNA({...brandDNA, language_donts: e.target.value})}
                  placeholder="Vague 'revolutionize,' 'cutting-edge' without proof; dunking on people; politics"
                  rows={3}
                />
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="voice" className="space-y-6">
          <Card className="dm-card">
            <CardHeader>
              <CardTitle className="font-headline">Voice & Tone Settings</CardTitle>
              <CardDescription>Fine-tune how your AI agents communicate</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {[
                { key: 'clarity_vs_jargon', label: 'Clarity vs Jargon', low: 'Heavy Jargon', high: 'Maximum Clarity' },
                { key: 'empathy_level', label: 'Empathy Level', low: 'Low Empathy', high: 'High Empathy' },
                { key: 'authority_vs_humility', label: 'Authority vs Humility', low: 'Humble', high: 'Authoritative' },
                { key: 'formality_level', label: 'Formality Level', low: 'Very Casual', high: 'Very Formal' },
                { key: 'risk_taking', label: 'Risk Taking', low: 'Conservative', high: 'Bold Risk-Taking' }
              ].map(({ key, label, low, high }) => (
                <div key={key} className="space-y-2">
                  <Label>{label}</Label>
                  <div className="flex items-center gap-4">
                    <span className="text-sm dm-text-steel">{low}</span>
                    <input
                      type="range"
                      min="1"
                      max="5"
                      value={voiceTone[key] || 3}
                      onChange={(e) => setVoiceTone({...voiceTone, [key]: parseInt(e.target.value)})}
                      className="flex-1"
                    />
                    <span className="text-sm dm-text-steel">{high}</span>
                    <Badge className="dm-bg-signal text-white min-w-[2rem] text-center">
                      {voiceTone[key] || 3}
                    </Badge>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="audience" className="space-y-6">
          <Card className="dm-card">
            <CardHeader>
              <CardTitle className="font-headline">Ideal Customer Profile (ICP)</CardTitle>
              <CardDescription>Define your target audience segments</CardDescription>
              <Button 
                onClick={addIcpSegment}
                className="dm-button-secondary w-fit"
              >
                <Plus className="w-4 h-4 mr-2" />
                Add ICP Segment
              </Button>
            </CardHeader>
            <CardContent className="space-y-6">
              {icpSegments.map((segment, index) => (
                <Card key={index} className="border dm-border-steel">
                  <CardHeader>
                    <div className="flex justify-between items-center">
                      <CardTitle className="text-lg">Segment {index + 1}</CardTitle>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => removeIcpSegment(index)}
                        className="dm-text-signal hover:dm-bg-signal hover:text-white"
                      >
                        <X className="w-4 h-4" />
                      </Button>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label>Segment Name</Label>
                        <Input
                          value={segment.name || ''}
                          onChange={(e) => updateIcpSegment(index, 'name', e.target.value)}
                          placeholder="e.g., Owner-Operators (Trades)"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label>Description</Label>
                        <Input
                          value={segment.description || ''}
                          onChange={(e) => updateIcpSegment(index, 'description', e.target.value)}
                          placeholder="Brief description of this segment"
                        />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label>Goals (comma-separated)</Label>
                      <Input
                        value={segment.goals?.join(', ') || ''}
                        onChange={(e) => updateIcpSegment(index, 'goals', e.target.value.split(',').map(s => s.trim()).filter(s => s))}
                        placeholder="Steady leads, fewer tire-kickers, professional brand"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Fears (comma-separated)</Label>
                      <Input
                        value={segment.fears?.join(', ') || ''}
                        onChange={(e) => updateIcpSegment(index, 'fears', e.target.value.split(',').map(s => s.trim()).filter(s => s))}
                        placeholder="Tech overwhelm, wasted spend, losing authentic voice"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Triggers (comma-separated)</Label>
                      <Input
                        value={segment.triggers?.join(', ') || ''}
                        onChange={(e) => updateIcpSegment(index, 'triggers', e.target.value.split(',').map(s => s.trim()).filter(s => s))}
                        placeholder="Busy season prep, hiring push, bad agency experience"
                      />
                    </div>
                  </CardContent>
                </Card>
              ))}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="content" className="space-y-6">
          <Card className="dm-card">
            <CardHeader>
              <CardTitle className="font-headline">Content & Style Guidelines</CardTitle>
              <CardDescription>Style examples and content constraints for AI agents</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label>Hook Examples</Label>
                  <Textarea
                    value={styleExamples.hooks?.join('\n') || ''}
                    onChange={(e) => setStyleExamples({...styleExamples, hooks: e.target.value.split('\n').filter(s => s.trim())})}
                    placeholder="Here's how a $0 tool saved a roofer $3k last month&#10;This HVAC trick cuts install time by 40%"
                    rows={3}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Call-to-Action Examples</Label>
                  <Textarea
                    value={styleExamples.ctas?.join('\n') || ''}
                    onChange={(e) => setStyleExamples({...styleExamples, ctas: e.target.value.split('\n').filter(s => s.trim())})}
                    placeholder="Steal the checklist&#10;Book the 15-min plan call"
                    rows={3}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Social Closers</Label>
                  <Textarea
                    value={styleExamples.social_closers?.join('\n') || ''}
                    onChange={(e) => setStyleExamples({...styleExamples, social_closers: e.target.value.split('\n').filter(s => s.trim())})}
                    placeholder="Questions? Reply 'ROOF' and I'll send the SOP&#10;Drop 🔥 if you want the template"
                    rows={3}
                  />
                </div>
              </div>

              <div className="space-y-4 border-t pt-6">
                <h3 className="font-semibold dm-text-ink">Writing Constraints</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Max Sentence Length (words)</Label>
                    <Input
                      type="number"
                      value={proseConstraints.max_sentence_length || 20}
                      onChange={(e) => setProseConstraints({...proseConstraints, max_sentence_length: parseInt(e.target.value)})}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Reading Level</Label>
                    <Select 
                      value={proseConstraints.reading_level || 'Grade 7-9'} 
                      onValueChange={(value) => setProseConstraints({...proseConstraints, reading_level: value})}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Grade 5-7">Grade 5-7 (Simple)</SelectItem>
                        <SelectItem value="Grade 7-9">Grade 7-9 (Standard)</SelectItem>
                        <SelectItem value="Grade 9-12">Grade 9-12 (Advanced)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <div className="flex justify-end">
        <Button 
          onClick={saveBusinessBrain} 
          disabled={isSaving}
          className="dm-button-primary"
        >
          {isSaving ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Save className="w-4 h-4 mr-2" />}
          Save Business Brain
        </Button>
      </div>
    </div>
  );
}