import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { toast } from 'sonner';
import { BookOpen, ArrowRight } from 'lucide-react';
import BusinessBrainInterface from './BusinessBrainInterface';

export default function TrainingInterface({ agent }) {
  const [showBusinessBrain, setShowBusinessBrain] = useState(false);

  const agentDisplayName = agent?.display_name || agent?.name?.split('_').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ') || 'AI Agent';
  
  if (showBusinessBrain) {
    return <BusinessBrainInterface onClientUpdated={() => {
      toast.success("Business Brain updated! Your agents are now trained with the latest information.");
      setShowBusinessBrain(false);
    }} />;
  }

  return (
    <div className="space-y-6">
      <Card className="dm-card border-2 dm-border-signal">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 font-headline dm-text-ink">
            <BookOpen className="w-5 h-5 dm-text-signal" />
            Business Brain Training
          </CardTitle>
          <CardDescription>
            Configure your Business Brain to train all AI agents with your company's unique brand DNA, voice, target audience, and content guidelines. This ensures every piece of content sounds authentically like <strong>your business</strong>.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="dm-bg-mint p-6 rounded-lg space-y-4">
            <h3 className="font-semibold dm-text-ink">What is the Business Brain?</h3>
            <p className="dm-text-ink">
              The Business Brain is Disruptors Media's comprehensive client profiling system that captures:
            </p>
            <ul className="list-disc list-inside dm-text-ink space-y-2">
              <li><strong>Business Profile:</strong> Your industry, services, target market, and unique positioning</li>
              <li><strong>Brand DNA:</strong> Personality, voice, tone, messaging pillars, and style guidelines</li>
              <li><strong>Voice & Tone:</strong> Precise settings for how formal, authoritative, and empathetic your content should be</li>
              <li><strong>Ideal Customer Profile:</strong> Detailed audience segments with their goals, fears, and triggers</li>
              <li><strong>Content Guidelines:</strong> Specific examples of hooks, CTAs, and writing constraints</li>
            </ul>
            <p className="dm-text-ink">
              Once configured, every AI agent will automatically use this information to create content that sounds like it came directly from your business owner.
            </p>
          </div>

          <div className="mt-6 flex justify-center">
            <Button 
              onClick={() => setShowBusinessBrain(true)}
              className="dm-button-primary text-lg px-8 py-3"
            >
              Configure Business Brain
              <ArrowRight className="w-5 h-5 ml-2" />
            </Button>
          </div>
        </CardContent>
      </Card>

      <Card className="dm-card">
        <CardHeader>
          <CardTitle className="font-headline">Current Agent: {agentDisplayName}</CardTitle>
          <CardDescription>
            This agent specializes in {agent?.description?.toLowerCase() || 'content creation'}. Once you configure the Business Brain above, this agent will automatically use that information for all content generation.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="p-4 dm-bg-paper border rounded-md text-sm dm-text-ink">
            <p className="font-medium mb-2">Agent Core Capabilities:</p>
            <p>{agent?.description || "This agent helps create high-quality content tailored to your specific business needs using Disruptors Media's proven content frameworks."}</p>
            <p className="mt-3 text-xs dm-text-steel">
              <strong>Note:</strong> This agent will automatically combine its specialized capabilities with your Business Brain data for personalized, on-brand content generation.
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}