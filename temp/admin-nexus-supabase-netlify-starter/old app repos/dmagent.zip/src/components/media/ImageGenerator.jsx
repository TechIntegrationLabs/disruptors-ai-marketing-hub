import React, { useState } from 'react';
import { generateMedia } from '@/api/functions';
import { getMediaStatus } from '@/api/functions';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Loader2, Sparkles, Download, ImagePlus } from 'lucide-react';
import { toast } from 'sonner';

export default function ImageGenerator() {
    const [prompt, setPrompt] = useState('');
    const [negativePrompt, setNegativePrompt] = useState('');
    const [aspectRatio, setAspectRatio] = useState('1:1');
    const [style, setStyle] = useState('Cinematic');
    const [isLoading, setIsLoading] = useState(false);
    const [generatedImages, setGeneratedImages] = useState([]);

    const handleGenerate = async () => {
        if (!prompt.trim()) {
            toast.error("Please enter a prompt.");
            return;
        }
        
        setIsLoading(true);
        setGeneratedImages([]);
        toast.info("Generating image... This can take a few moments.", { icon: <Sparkles className="w-4 h-4" /> });

        try {
            const response = await generateMedia({
                type: 'image',
                prompt: prompt,
                negativePrompt: negativePrompt,
                aspectRatio: aspectRatio,
                style: style,
                numOutputs: 1
            });

            if (response.data.error) {
                throw new Error(response.data.error);
            }

            const result = response.data;

            if (result.status === 'succeeded' && result.urls) {
                setGeneratedImages(result.urls.map(url => ({ url })));
                toast.success("Image generated successfully!");
            } else if (result.id) {
                // Poll for completion
                await pollForCompletion(result.id);
            } else {
                throw new Error("Unexpected response from image generator.");
            }
        } catch (error) {
            console.error("Error generating image:", error);
            toast.error(`Failed to generate image: ${error.message}`);
        } finally {
            setIsLoading(false);
        }
    };

    const pollForCompletion = async (predictionId) => {
        const maxAttempts = 60;
        let attempts = 0;

        const poll = async () => {
            if (attempts >= maxAttempts) {
                throw new Error("Image generation timed out");
            }

            try {
                const statusResponse = await getMediaStatus(predictionId);
                const status = statusResponse.data;

                if (status.status === 'succeeded' && status.urls) {
                    setGeneratedImages(status.urls.map(url => ({ url })));
                    toast.success("Image generated successfully!");
                    return;
                } else if (status.status === 'failed') {
                    throw new Error(status.error || "Image generation failed");
                } else if (status.status === 'processing' || status.status === 'starting') {
                    attempts++;
                    setTimeout(poll, 5000);
                }
            } catch (error) {
                throw error;
            }
        };

        await poll();
    };

    return (
        <div className="flex flex-col h-full">
            <div className="flex-1 p-6 space-y-4 overflow-y-auto">
                <Textarea
                    placeholder="e.g., product photo of a stainless steel coffee mug on marble"
                    value={prompt}
                    onChange={(e) => setPrompt(e.target.value)}
                    className="dm-input h-24"
                />
                <Textarea
                    placeholder="Negative prompt (e.g., blurry, cartoon, text)"
                    value={negativePrompt}
                    onChange={(e) => setNegativePrompt(e.target.value)}
                    className="dm-input h-16"
                />
                <div className="grid grid-cols-2 gap-4">
                    <Select value={aspectRatio} onValueChange={setAspectRatio}>
                        <SelectTrigger className="dm-input"><SelectValue placeholder="Aspect Ratio" /></SelectTrigger>
                        <SelectContent>
                            <SelectItem value="1:1">1:1 (Square)</SelectItem>
                            <SelectItem value="16:9">16:9 (Widescreen)</SelectItem>
                            <SelectItem value="4:5">4:5 (Portrait)</SelectItem>
                            <SelectItem value="9:16">9:16 (Story)</SelectItem>
                        </SelectContent>
                    </Select>
                    <Select value={style} onValueChange={setStyle}>
                        <SelectTrigger className="dm-input"><SelectValue placeholder="Style" /></SelectTrigger>
                        <SelectContent>
                            <SelectItem value="Photorealistic">Photorealistic</SelectItem>
                            <SelectItem value="Cinematic">Cinematic</SelectItem>
                            <SelectItem value="Product">Product</SelectItem>
                            <SelectItem value="Flat Illustration">Flat Illustration</SelectItem>
                            <SelectItem value="Iconic">Iconic</SelectItem>
                        </SelectContent>
                    </Select>
                </div>
                
                <div className="border-t dm-border-gray-700 pt-4">
                    {isLoading ? (
                        <div className="flex items-center justify-center h-48 bg-gray-800/50 rounded-lg">
                            <div className="text-center">
                                <Loader2 className="w-8 h-8 text-yellow-400 animate-spin mx-auto" />
                                <p className="mt-2 dm-text-gray-300">Generating...</p>
                            </div>
                        </div>
                    ) : generatedImages.length > 0 ? (
                        <div className="grid grid-cols-1 gap-4">
                            {generatedImages.map((image, index) => (
                                <div key={index} className="group relative">
                                    <img src={image.url} alt="Generated image" className="w-full h-auto rounded-lg" />
                                    <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
                                        <Button size="icon" className="dm-button-ghost"><ImagePlus className="w-5 h-5" /></Button>
                                        <Button size="icon" className="dm-button-ghost"><Download className="w-5 h-5" /></Button>
                                    </div>
                                </div>
                            ))}
                        </div>
                    ) : (
                        <div className="flex items-center justify-center h-48 bg-gray-800/50 rounded-lg">
                             <p className="dm-text-gray-400">Your generated images will appear here.</p>
                        </div>
                    )}
                </div>

            </div>
            <div className="p-4 border-t dm-border-gray-700">
                <Button onClick={handleGenerate} disabled={isLoading} className="dm-button-primary w-full flex items-center gap-2">
                    {isLoading ? (
                        <Loader2 className="w-4 h-4 animate-spin" />
                    ) : (
                        <Sparkles className="w-4 h-4" />
                    )}
                    <span>Generate</span>
                </Button>
            </div>
        </div>
    );
}