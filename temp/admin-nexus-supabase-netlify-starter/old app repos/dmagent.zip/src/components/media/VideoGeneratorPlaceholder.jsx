import React from 'react';
import { Film } from 'lucide-react';

export default function VideoGeneratorPlaceholder() {
    return (
        <div className="flex flex-col items-center justify-center h-full text-center p-8 dm-bg-navy-light">
            <Film className="w-12 h-12 text-gray-500 mb-4" />
            <h3 className="font-display text-xl dm-text-white">Video Generation Coming Soon</h3>
            <p className="dm-text-gray-400 max-w-sm mt-2">
                The ability to generate short video clips from text prompts is planned for a future update.
            </p>
        </div>
    );
}