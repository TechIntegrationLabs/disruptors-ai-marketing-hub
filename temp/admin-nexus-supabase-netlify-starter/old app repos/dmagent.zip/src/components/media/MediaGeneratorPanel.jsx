import React, { useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Sparkles, Film, Wand2 } from 'lucide-react';
import ImageGenerator from './ImageGenerator';
import VideoGeneratorPlaceholder from './VideoGeneratorPlaceholder';

export default function MediaGeneratorPanel() {
    const [activeTab, setActiveTab] = useState('image');

    return (
        <div className="dm-card-solid w-full h-full flex flex-col">
            <div className="p-4 border-b dm-border-gray-700">
                <h3 className="font-display text-lg dm-text-white flex items-center gap-2">
                    <Sparkles className="w-5 h-5 text-yellow-400" />
                    Generate Media
                </h3>
            </div>
            <Tabs value={activeTab} onValueChange={setActiveTab} className="flex-1 flex flex-col">
                <TabsList className="mx-4 mt-4 w-fit bg-gray-800/50 border border-gray-700">
                    <TabsTrigger value="image" className="flex items-center gap-2">
                        <Sparkles className="w-4 h-4" /> Images
                    </TabsTrigger>
                    <TabsTrigger value="video" className="flex items-center gap-2" disabled>
                        <Film className="w-4 h-4" /> Video
                    </TabsTrigger>
                     <TabsTrigger value="tools" className="flex items-center gap-2" disabled>
                        <Wand2 className="w-4 h-4" /> Tools
                    </TabsTrigger>
                </TabsList>
                <div className="flex-1 min-h-0">
                    <TabsContent value="image" className="h-full m-0">
                        <ImageGenerator />
                    </TabsContent>
                    <TabsContent value="video" className="h-full m-0">
                        <VideoGeneratorPlaceholder />
                    </TabsContent>
                </div>
            </Tabs>
        </div>
    );
}