import { base44 } from './base44Client';


export const keywordResearch = base44.functions.keywordResearch;

export const generateMedia = base44.functions.generateMedia;

export const getMediaStatus = base44.functions.getMediaStatus;

export const generateKeywordSuggestions = base44.functions.generateKeywordSuggestions;

