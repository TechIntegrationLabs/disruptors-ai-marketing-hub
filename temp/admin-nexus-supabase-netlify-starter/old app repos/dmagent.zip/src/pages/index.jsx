import React from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { BrainCircuit, FileText, Share2, Calendar, MessagesSquare, ArrowRight } from 'lucide-react';

const features = [
    {
        title: "AI Content Agents",
        description: "Deploy specialized AI agents that create authentic, on-brand content for your business.",
        icon: BrainCircuit,
        url: createPageUrl("AIAgents"),
        gradient: "from-yellow-400 to-orange-500",
        delay: "0ms"
    },
    {
        title: "Blog Library",
        description: "Centralized hub for all your AI-generated and curated blog content.",
        icon: FileText,
        url: createPageUrl("BlogLibrary"),
        gradient: "from-blue-400 to-cyan-500",
        delay: "100ms"
    },
    {
        title: "Social Post Library",
        description: "Manage and deploy social media content across all platforms seamlessly.",
        icon: Share2,
        url: createPageUrl("SocialPostLibrary"),
        gradient: "from-purple-400 to-pink-500",
        delay: "200ms"
    },
    {
        title: "Content Calendar",
        description: "Strategic overview of your entire content ecosystem and publishing schedule.",
        icon: Calendar,
        url: createPageUrl("ContentCalendar"),
        gradient: "from-green-400 to-emerald-500",
        delay: "300ms"
    },
    {
        title: "Team Chat",
        description: "Real-time collaboration space for your content team and stakeholders.",
        icon: MessagesSquare,
        url: createPageUrl("TeamChat"),
        gradient: "from-red-400 to-rose-500",
        delay: "400ms"
    }
];

export default function Index() {
  return (
    <div className="relative z-10 p-6 lg:p-12 space-y-12">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="animate-fade-in-up mb-10">
          <h1 className="text-4xl md:text-5xl font-display dm-text-white">Dashboard</h1>
          <p className="text-xl dm-text-gray-300 mt-2">Quick access to your content tools and libraries.</p>
        </div>

        {/* Features Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <Link to={feature.url} key={feature.title} className="group animate-fade-in-up" style={{ animationDelay: feature.delay }}>
              <Card className="dm-card h-full relative overflow-hidden dm-interactive">
                <div className={`absolute top-0 left-0 right-0 h-1 bg-gradient-to-r ${feature.gradient}`}></div>
                
                <CardHeader className="relative pb-4">
                  <div className="flex items-center justify-between mb-4">
                    <div className={`p-3 rounded-xl bg-gradient-to-br ${feature.gradient} shadow-lg group-hover:scale-110 transition-transform duration-300`}>
                      <feature.icon className="h-6 w-6 text-white" />
                    </div>
                    <ArrowRight className="w-5 h-5 dm-text-gray-400 group-hover:dm-text-gold transition-all duration-300 group-hover:translate-x-1" />
                  </div>
                  <CardTitle className="text-xl font-display dm-text-white group-hover:dm-text-gold transition-colors duration-300">
                    {feature.title}
                  </CardTitle>
                </CardHeader>
                
                <CardContent className="pt-0">
                  <p className="dm-text-gray-300 leading-relaxed">{feature.description}</p>
                  
                  <div className="mt-6 flex items-center text-sm font-semibold dm-text-gray-400 group-hover:dm-text-gold transition-colors duration-300">
                    <span>Explore {feature.title}</span>
                    <ArrowRight className="w-4 h-4 ml-2 transform group-hover:translate-x-1 transition-transform duration-300" />
                  </div>
                </CardContent>

                {/* Hover Effect */}
                <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/5 to-transparent translate-x-[-100%] group-hover:translate-x-[100%] transition-transform duration-700"></div>
              </Card>
            </Link>
          ))}
        </div>
      </div>
    </div>
  );
}