import React, { useState, useCallback } from 'react';
import { Search, BrainCircuit, Target } from 'lucide-react';
import KeywordFinderControls from '../components/seo/KeywordFinderControls';
import KeywordSuggestions from '../components/seo/KeywordSuggestions';
import KeywordTable from '../components/seo/KeywordTable';
import KeywordsQueue from '../components/seo/KeywordsQueue';
import SavedKeywordsDrawer from '../components/seo/SavedKeywordsDrawer';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

export default function SEOKeywordFinder() {
    const [keywordData, setKeywordData] = useState({
        keywords: [],
        clusters: [],
        totalResults: 0
    });
    const [isLoading, setIsLoading] = useState(false);
    const [selectedKeywords, setSelectedKeywords] = useState([]);
    const [keywordsQueue, setKeywordsQueue] = useState([]);
    const [currentSeedKeywords, setCurrentSeedKeywords] = useState([]);
    const [isDrawerOpen, setIsDrawerOpen] = useState(false);

    const handleSearch = useCallback(async (searchParams) => {
        setIsLoading(true);
        setKeywordData({ keywords: [], clusters: [], totalResults: 0 });
        setCurrentSeedKeywords(searchParams.seedKeywords);
        setSelectedKeywords([]);
    }, []);

    const handleKeywordSelect = (keyword) => {
        const event = new CustomEvent('keywordSuggestionSelected', { 
            detail: { keyword } 
        });
        window.dispatchEvent(event);
    };

    const handleAddToQueue = (keyword) => {
        if (!keywordsQueue.find(k => k.text === keyword.text)) {
            setKeywordsQueue(prev => [...prev, keyword]);
        }
    };

    const handleRemoveFromQueue = (keywordText) => {
        setKeywordsQueue(prev => prev.filter(k => k.text !== keywordText));
    };

    const handleClearQueue = () => {
        setKeywordsQueue([]);
    };

    const handleToggleKeywordSelection = (keyword) => {
        setSelectedKeywords(prev => {
            const isSelected = prev.find(k => k.text === keyword.text);
            if (isSelected) {
                return prev.filter(k => k.text !== keyword.text);
            } else {
                return [...prev, keyword];
            }
        });
    };

    const handleBulkAddToQueue = () => {
        const newKeywords = selectedKeywords.filter(
            selected => !keywordsQueue.find(queued => queued.text === selected.text)
        );
        setKeywordsQueue(prev => [...prev, ...newKeywords]);
        setSelectedKeywords([]);
    };

    return (
        <div className="relative z-10 p-6 space-y-8">
            <div className="max-w-full mx-auto">
                {/* Header */}
                <div className="text-left space-y-6 mb-8 animate-fade-in-up">
                    <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-yellow-500/20 border border-yellow-500/30 backdrop-blur-sm">
                        <Search className="w-4 h-4 text-yellow-400" />
                        <span className="text-sm font-medium text-yellow-300">SEO Toolkit</span>
                    </div>
                    <h1 className="text-4xl md:text-6xl font-display dm-text-white">
                        Keyword Research & Content Planning
                    </h1>
                    <p className="text-xl dm-text-gray-300 max-w-4xl">
                        Discover high-impact keywords, analyze search intent, and build your content strategy with data from DataForSEO API.
                    </p>
                </div>

                {/* Quick Actions Header */}
                <div className="flex justify-between items-center mb-6">
                    <div className="flex items-center gap-4">
                        {selectedKeywords.length > 0 && (
                            <Button 
                                onClick={handleBulkAddToQueue} 
                                className="dm-button-secondary"
                            >
                                <Target className="w-4 h-4 mr-2" />
                                Add {selectedKeywords.length} to Queue
                            </Button>
                        )}
                    </div>
                    <Button 
                        onClick={() => setIsDrawerOpen(true)} 
                        className="dm-button-ghost"
                    >
                        View Saved Research
                    </Button>
                </div>

                {/* Main Layout */}
                <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
                    {/* Left Panel - Controls & Suggestions */}
                    <div className="lg:col-span-1 space-y-6">
                        {/* Search Controls */}
                        <Card className="dm-card-solid animate-fade-in-up">
                            <CardHeader className="pb-4">
                                <CardTitle className="font-display text-lg dm-text-white flex items-center gap-2">
                                    <Search className="w-5 h-5 text-yellow-400" />
                                    Search Parameters
                                </CardTitle>
                            </CardHeader>
                            <CardContent className="p-6">
                                <KeywordFinderControls 
                                    onSearch={handleSearch} 
                                    isLoading={isLoading}
                                    compact={true}
                                />
                            </CardContent>
                        </Card>

                        {/* AI Suggestions */}
                        <KeywordSuggestions 
                            onKeywordSelect={handleKeywordSelect}
                            selectedKeywords={currentSeedKeywords}
                        />

                        {/* Keywords Queue */}
                        <KeywordsQueue 
                            keywords={keywordsQueue}
                            onRemoveKeyword={handleRemoveFromQueue}
                            onClearQueue={handleClearQueue}
                        />
                    </div>

                    {/* Main Content Area - Results Table */}
                    <div className="lg:col-span-3">
                        <KeywordTable 
                            onSearch={handleSearch}
                            isLoading={isLoading}
                            keywordData={keywordData}
                            setKeywordData={setKeywordData}
                            selectedKeywords={selectedKeywords}
                            onToggleKeywordSelection={handleToggleKeywordSelection}
                            onAddToQueue={handleAddToQueue}
                            currentSeedKeywords={currentSeedKeywords}
                        />
                    </div>
                </div>
            </div>

            <SavedKeywordsDrawer 
                isOpen={isDrawerOpen} 
                onClose={() => setIsDrawerOpen(false)} 
            />
        </div>
    );
}