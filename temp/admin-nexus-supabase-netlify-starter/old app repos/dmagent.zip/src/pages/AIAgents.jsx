
import React, { useState, useEffect, useCallback } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { BrainCircuit, MessageCircle, Settings, FileText, Zap, MessagesSquare, Sparkles } from 'lucide-react';
import ChatInterface from '../components/agents/ChatInterface';
import TrainingInterface from '../components/agents/TrainingInterface';
import KnowledgeBase from '../components/agents/KnowledgeBase';
import ChatHistoryPanel from '../components/agents/ChatHistoryPanel';
import AgentPicker from '../components/agents/AgentPicker';
import MediaGeneratorPanel from '../components/media/MediaGeneratorPanel';

// Import available agents
import { agentSDK } from '@/agents';

const availableAgents = [
  {
    name: 'blog_content_writer',
    display_name: 'Blog Content Writer',
    description: 'Creates SEO-optimized, engaging blog posts that automatically save to your content library using Disruptors Media\'s disruptive brand voice.',
    icon: FileText,
    category: 'Content Creation',
    saves_to_library: true
  },
  {
    name: 'instagram_content_creator',
    display_name: 'Instagram Content Creator', 
    description: 'Develops Instagram posts, stories, and reels optimized for engagement using trades-focused, disruptive content strategies.',
    icon: BrainCircuit,
    category: 'Social Media',
    saves_to_library: true
  },
  {
    name: 'facebook_content_creator',
    display_name: 'Facebook Content Creator',
    description: 'Creates Facebook posts and community content designed to build authentic engagement for trades and service businesses.',
    icon: BrainCircuit, 
    category: 'Social Media',
    saves_to_library: true
  },
  {
    name: 'linkedin_content_creator',
    display_name: 'LinkedIn Content Creator',
    description: 'Develops professional LinkedIn content for thought leadership and B2B networking in the trades industry.',
    icon: BrainCircuit,
    category: 'Social Media', 
    saves_to_library: true
  },
  {
    name: 'twitter_content_creator',
    display_name: 'X (Twitter) Content Creator',
    description: 'Creates engaging X posts and threads for real-time engagement and industry thought leadership.',
    icon: BrainCircuit,
    category: 'Social Media',
    saves_to_library: true
  },
  {
    name: 'tiktok_content_creator',
    display_name: 'TikTok Content Creator',
    description: 'Generates viral TikTok video concepts and scripts for maximum reach in the trades space.',
    icon: BrainCircuit,
    category: 'Social Media',
    saves_to_library: true
  },
  {
    name: 'youtube_content_creator',
    display_name: 'YouTube Content Creator', 
    description: 'Creates YouTube video scripts, titles, and series concepts for subscriber growth.',
    icon: BrainCircuit,
    category: 'Social Media',
    saves_to_library: true
  },
  {
    name: 'reddit_content_creator',
    display_name: 'Reddit Content Creator',
    description: 'Crafts authentic Reddit posts that add value to communities without being promotional.',
    icon: BrainCircuit,
    category: 'Social Media',
    saves_to_library: true
  },
  {
    name: 'email_marketing_specialist',
    display_name: 'Email Marketing Specialist',
    description: 'Designs email campaigns, newsletters, and automated sequences with strategic keyword integration.',
    icon: BrainCircuit,
    category: 'Marketing',
    saves_to_library: false
  },
  {
    name: 'seo_optimizer',
    display_name: 'SEO Optimizer',
    description: 'Provides keyword insights, content strategy, and optimization recommendations based on E-E-A-T and modern best practices.',
    icon: Zap,
    category: 'Strategy',
    saves_to_library: false
  },
  {
    name: 'content_idea_generator',
    display_name: 'Content Idea Generator',
    description: 'Generates content ideas, blog post titles, and outlines based on your Business Brain and industry insights.',
    icon: BrainCircuit,
    category: 'Strategy', 
    saves_to_library: false
  },
  {
    name: 'general_content_assistant',
    display_name: 'General Content Assistant',
    description: 'A versatile assistant for various content tasks, brainstorming, and general marketing questions.',
    icon: MessageCircle,
    category: 'General',
    saves_to_library: false
  }
];

export default function AIAgents() {
  const [selectedAgent, setSelectedAgent] = useState(null);
  const [activeTab, setActiveTab] = useState('chat');
  const [conversations, setConversations] = useState([]);
  const [selectedConversationId, setSelectedConversationId] = useState(null);
  const [refreshTrigger, setRefreshTrigger] = useState(0);
  const [isMediaPanelVisible, setIsMediaPanelVisible] = useState(false);

  useEffect(() => {
    // Default to blog content writer
    const defaultAgent = availableAgents.find(agent => agent.name === 'blog_content_writer');
    if (defaultAgent) {
      setSelectedAgent(defaultAgent);
    }
  }, []);

  const loadConversations = useCallback(async () => {
    if (!selectedAgent) return;
    
    try {
      const agentConversations = await agentSDK.getConversations(selectedAgent.name);
      setConversations(agentConversations);
      
      // Clear selected conversation if it doesn't exist for this agent
      if (selectedConversationId && !agentConversations.find(c => c.id === selectedConversationId)) {
        setSelectedConversationId(null);
      }
    } catch (error) {
      console.error('Error loading conversations:', error);
      setConversations([]);
    }
  }, [selectedAgent, selectedConversationId, setConversations, setSelectedConversationId]);

  useEffect(() => {
    if (selectedAgent) {
      loadConversations();
    }
  }, [selectedAgent, refreshTrigger, loadConversations]);

  const handleAgentSelect = (agentName) => {
    const agent = availableAgents.find(a => a.name === agentName);
    if (agent) {
      setSelectedAgent(agent);
      setSelectedConversationId(null); // Reset conversation when switching agents
      setActiveTab('chat'); // Switch to chat tab
    }
  };

  const handleConversationSelect = (conversationId) => {
    setSelectedConversationId(conversationId);
    setActiveTab('chat');
  };

  const handleConversationCreated = (conversation) => {
    setSelectedConversationId(conversation.id);
    setRefreshTrigger(prev => prev + 1);
  };

  return (
    <div className="h-full bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 relative">
      {/* Animated Background */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-20 left-20 w-64 h-64 bg-yellow-500/10 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-20 right-20 w-80 h-80 bg-blue-500/10 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '1s' }}></div>
      </div>

      <div className="relative z-10 p-6 h-full flex flex-col">
        <div className="max-w-full mx-auto flex-1 flex flex-col w-full">
          {/* Header */}
          <div className="text-center space-y-6 mb-12 animate-fade-in-up">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-yellow-500/20 border border-yellow-500/30 backdrop-blur-sm">
              <BrainCircuit className="w-4 h-4 text-yellow-400" />
              <span className="text-sm font-medium text-yellow-300">Business Brain Powered</span>
            </div>
            
            <h1 className="text-4xl md:text-6xl font-display dm-text-white">
              AI Content Agents
            </h1>
            <p className="text-xl dm-text-gray-300 max-w-3xl mx-auto">
              Create disruptive, on-brand content using AI agents trained with your Business Brain.
            </p>
          </div>

          {/* Main Content Layout */}
          <div className="flex-1 flex gap-6 pt-12">
            {/* Left Sidebar - Agent Selection */}
            <div className="w-80 flex flex-col space-y-6">
              <Card className="dm-card-solid animate-fade-in-up">
                <CardHeader className="pb-4">
                  <CardTitle className="font-display text-lg dm-text-white">Available Agents</CardTitle>
                </CardHeader>
                <CardContent className="p-0">
                  <AgentPicker 
                    agents={availableAgents}
                    selectedAgent={selectedAgent}
                    onAgentChange={handleAgentSelect}
                  />
                </CardContent>
              </Card>

              {/* Conversations History */}
              {selectedAgent && conversations.length > 0 && (
                <Card className="dm-card-solid animate-fade-in-up" style={{ animationDelay: '200ms' }}>
                  <CardHeader className="pb-4">
                    <CardTitle className="font-display text-lg dm-text-white">Recent Conversations</CardTitle>
                  </CardHeader>
                  <CardContent className="p-0">
                    <ChatHistoryPanel 
                      conversations={conversations}
                      selectedConversationId={selectedConversationId}
                      onConversationSelect={handleConversationSelect}
                    />
                  </CardContent>
                </Card>
              )}
            </div>

            {/* Main Content Area */}
            <div className={`flex-1 flex gap-4 ${isMediaPanelVisible ? '' : ''}`}>
              {/* Chat Interface */}
              <div className={`${isMediaPanelVisible ? 'flex-[3]' : 'flex-1'} min-w-0`}>
                {selectedAgent ? (
                  <Card className="dm-card-solid h-full animate-fade-in-up flex flex-col" style={{ animationDelay: '300ms' }}>
                    <CardHeader className="border-b border-gray-700 bg-gradient-to-r from-gray-800/50 to-gray-700/50 rounded-t-xl">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-4">
                          <div className="p-3 rounded-xl bg-gradient-to-br from-yellow-400 to-orange-500 shadow-lg">
                            <selectedAgent.icon className="w-6 h-6 text-white" />
                          </div>
                          <div>
                            <CardTitle className="font-display dm-text-white text-xl">{selectedAgent.display_name}</CardTitle>
                            <p className="text-sm dm-text-gray-300 mt-1">{selectedAgent.description}</p>
                          </div>
                        </div>
                        <div className="flex items-center gap-3">
                          <Badge className="bg-yellow-500/20 text-yellow-300 border-yellow-500/30 font-medium">
                            {selectedAgent.category}
                          </Badge>
                          {selectedAgent.saves_to_library && (
                            <Badge className="bg-green-500/20 text-green-300 border-green-500/30 font-medium animate-pulse-gold">
                              Library-Enabled
                            </Badge>
                          )}
                        </div>
                      </div>
                    </CardHeader>

                    <Tabs value={activeTab} onValueChange={setActiveTab} className="flex-1 flex flex-col">
                      <TabsList className="mx-6 mt-6 w-fit bg-gray-800/50 border border-gray-700">
                        <TabsTrigger value="chat" className="flex items-center gap-2 data-[state=active]:bg-yellow-500 data-[state=active]:text-gray-900">
                          <MessagesSquare className="w-4 h-4" />
                          Chat
                        </TabsTrigger>
                        <TabsTrigger value="training" className="flex items-center gap-2 data-[state=active]:bg-yellow-500 data-[state=active]:text-gray-900">
                          <BrainCircuit className="w-4 h-4" />
                          Training
                        </TabsTrigger>
                        <TabsTrigger value="knowledge" className="flex items-center gap-2 data-[state=active]:bg-yellow-500 data-[state=active]:text-gray-900">
                          <FileText className="w-4 h-4" />
                          Knowledge Base
                        </TabsTrigger>
                      </TabsList>

                      <div className="flex-1 min-h-0">
                        <TabsContent value="chat" className="h-full m-0">
                          <ChatInterface
                            agent={selectedAgent}
                            conversationId={selectedConversationId}
                            onConversationCreated={handleConversationCreated}
                          />
                        </TabsContent>

                        <TabsContent value="training" className="h-full m-0 overflow-auto p-6">
                          <TrainingInterface agent={selectedAgent} />
                        </TabsContent>

                        <TabsContent value="knowledge" className="h-full m-0 overflow-auto p-6">
                          <KnowledgeBase agent={selectedAgent} agents={availableAgents} />
                        </TabsContent>
                      </div>
                    </Tabs>
                  </Card>
                ) : (
                  <Card className="dm-card-solid animate-fade-in-up">
                    <CardContent className="p-16 text-center">
                      <div className="space-y-6">
                        <div className="relative">
                          <BrainCircuit className="w-20 h-20 dm-text-gray-400 mx-auto" />
                          <div className="absolute inset-0 w-20 h-20 dm-text-yellow-500 opacity-30 animate-pulse mx-auto"></div>
                        </div>
                        <div className="space-y-2">
                          <h3 className="text-2xl font-display dm-text-white">Select an AI Agent</h3>
                          <p className="dm-text-gray-300 text-lg">Choose an AI agent from the sidebar to start creating disruptive content.</p>
                        </div>
                        <div className="w-16 h-1 bg-gradient-to-r from-yellow-400 to-orange-500 rounded-full mx-auto"></div>
                      </div>
                    </CardContent>
                  </Card>
                )}
              </div>

              {/* Media Generator Panel */}
              {isMediaPanelVisible && (
                <div className="flex-[2] min-w-0">
                  <MediaGeneratorPanel />
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Media Panel Toggle Button */}
      <Button 
        onClick={() => setIsMediaPanelVisible(!isMediaPanelVisible)}
        className="dm-button-primary absolute bottom-6 right-6 rounded-full h-14 w-14 shadow-lg z-20"
      >
        <Sparkles className="w-6 h-6" />
      </Button>
    </div>
  );
}
