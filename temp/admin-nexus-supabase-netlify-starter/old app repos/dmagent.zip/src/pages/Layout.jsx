

import React from "react";
import { Link, useLocation } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { User as UserIcon, BrainCircuit, Calendar, FileText, Share2, MessagesSquare, LayoutDashboard, Search } from "lucide-react";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarHeader,
  SidebarProvider,
  SidebarTrigger,
} from "@/components/ui/sidebar";

const navigationItems = [
  {
    title: "Dashboard",
    url: createPageUrl("index"),
    icon: LayoutDashboard,
  },
  {
    title: "AI Content Agents",
    url: createPageUrl("AIAgents"),
    icon: BrainCircuit,
  },
  {
    title: "SEO Keyword Finder",
    url: createPageUrl("SEOKeywordFinder"),
    icon: Search,
  },
  {
    title: "Blog Library",
    url: createPageUrl("BlogLibrary"),
    icon: FileText,
  },
  {
    title: "Social Post Library",
    url: createPageUrl("SocialPostLibrary"),
    icon: Share2,
  },
  {
    title: "Content Calendar",
    url: createPageUrl("ContentCalendar"),
    icon: Calendar,
  },
  {
    title: "Team Chat",
    url: createPageUrl("TeamChat"),
    icon: MessagesSquare,
  },
];

const profileItem = {
  title: "My Profile",
  url: createPageUrl("Profile"),
  icon: UserIcon,
};

export default function Layout({ children, currentPageName }) {
  const location = useLocation();

  return (
      <SidebarProvider>
        <style jsx global>{`
          /* Import Professional Typography */
          @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&family=Space+Grotesk:wght@300;400;500;600;700&display=swap');
          
          /* Disruptors Media Design System */
          :root {
            --dm-navy: #1a1d29;
            --dm-navy-light: #242840;
            --dm-navy-dark: #0f1116;
            --dm-gold: #ffd700;
            --dm-gold-dark: #e6c200;
            --dm-gold-light: #fff44d;
            --dm-white: #ffffff;
            --dm-gray-50: #f8fafc;
            --dm-gray-100: #f1f5f9;
            --dm-gray-200: #e2e8f0;
            --dm-gray-300: #cbd5e1;
            --dm-gray-400: #94a3b8;
            --dm-gray-500: #64748b;
            --dm-gray-600: #475569;
            --dm-gray-700: #334155;
            --dm-gray-800: #1e293b;
            --dm-gray-900: #0f172a;
          }

          /* Global Styles */
          body {
            background: linear-gradient(135deg, var(--dm-navy-dark) 0%, var(--dm-navy) 100%);
            font-family: 'Inter', ui-sans-serif, system-ui, sans-serif;
            font-weight: 400;
            line-height: 1.6;
            color: var(--dm-white);
            -webkit-font-smoothing: antialiased;
            -moz-osx-font-smoothing: grayscale;
            min-height: 100vh;
          }

          /* Typography Hierarchy */
          h1, h2, h3, h4, h5, h6, .font-headline {
            font-family: 'Space Grotesk', 'Inter', sans-serif;
            font-weight: 600;
            letter-spacing: -0.025em;
            color: var(--dm-white);
            line-height: 1.2;
          }

          .font-display {
            font-family: 'Space Grotesk', sans-serif;
            font-weight: 700;
            letter-spacing: -0.02em;
          }

          .font-body {
            font-family: 'Inter', ui-sans-serif, system-ui, sans-serif;
          }

          /* Brand Colors */
          .dm-text-navy { color: var(--dm-navy); }
          .dm-text-gold { color: var(--dm-gold); }
          .dm-text-white { color: var(--dm-white); }
          .dm-text-gray-400 { color: var(--dm-gray-400); }
          .dm-text-gray-300 { color: var(--dm-gray-300); }
          
          .dm-bg-navy { background-color: var(--dm-navy); }
          .dm-bg-navy-light { background-color: var(--dm-navy-light); }
          .dm-bg-navy-dark { background-color: var(--dm-navy-dark); }
          .dm-bg-gold { background-color: var(--dm-gold); }
          .dm-bg-white { background-color: var(--dm-white); }
          
          .dm-border-gold { border-color: var(--dm-gold); }
          .dm-border-navy-light { border-color: var(--dm-navy-light); }
          .dm-border-gray-700 { border-color: var(--dm-gray-700); }

          /* Enhanced Components */
          .dm-card {
            background: rgba(255, 255, 255, 0.05);
            backdrop-filter: blur(20px);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 1rem;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3);
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
          }
          
          .dm-card:hover {
            transform: translateY(-4px);
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.4);
            border-color: rgba(255, 215, 0, 0.3);
          }

          .dm-card-solid {
            background: var(--dm-navy-light);
            border: 1px solid var(--dm-gray-700);
            border-radius: 1rem;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.25);
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
          }

          .dm-card-solid:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 30px rgba(0, 0, 0, 0.35);
            border-color: var(--dm-gold);
          }

          .dm-button-primary {
            background: linear-gradient(135deg, var(--dm-gold) 0%, var(--dm-gold-dark) 100%);
            border: none;
            color: var(--dm-navy);
            font-weight: 600;
            font-family: 'Space Grotesk', sans-serif;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
            box-shadow: 0 4px 14px rgba(255, 215, 0, 0.3);
          }
          
          .dm-button-primary:hover {
            background: linear-gradient(135deg, var(--dm-gold-light) 0%, var(--dm-gold) 100%);
            transform: translateY(-1px);
            box-shadow: 0 6px 20px rgba(255, 215, 0, 0.4);
          }

          .dm-button-secondary {
            background: transparent;
            border: 2px solid var(--dm-gold);
            color: var(--dm-gold);
            font-weight: 600;
            font-family: 'Space Grotesk', sans-serif;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
          }
          
          .dm-button-secondary:hover {
            background: var(--dm-gold);
            color: var(--dm-navy);
            transform: translateY(-1px);
            box-shadow: 0 4px 14px rgba(255, 215, 0, 0.3);
          }

          .dm-button-ghost {
            background: transparent;
            border: 1px solid rgba(255, 255, 255, 0.2);
            color: var(--dm-white);
            font-weight: 500;
            transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
          }

          .dm-button-ghost:hover {
            background: rgba(255, 255, 255, 0.1);
            border-color: rgba(255, 215, 0, 0.5);
            color: var(--dm-gold);
          }

          /* Input Styling */
          .dm-input {
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid rgba(255, 255, 255, 0.2);
            color: var(--dm-white);
            font-size: 16px;
            padding: 0.75rem 1rem;
            border-radius: 0.5rem;
            transition: all 0.2s ease;
          }

          .dm-input:focus {
            border-color: var(--dm-gold);
            box-shadow: 0 0 0 3px rgba(255, 215, 0, 0.1);
            background: rgba(255, 255, 255, 0.08);
          }

          .dm-input::placeholder {
            color: var(--dm-gray-400);
          }

          /* Animations */
          @keyframes fadeInUp {
            from {
              opacity: 0;
              transform: translateY(20px);
            }
            to {
              opacity: 1;
              transform: translateY(0);
            }
          }

          @keyframes pulse-gold {
            0%, 100% {
              box-shadow: 0 0 0 0 rgba(255, 215, 0, 0.4);
            }
            50% {
              box-shadow: 0 0 0 6px rgba(255, 215, 0, 0);
            }
          }

          .animate-fade-in-up {
            animation: fadeInUp 0.6s ease-out;
          }

          .animate-pulse-gold {
            animation: pulse-gold 2s infinite;
          }

          /* Scrollbar Styling */
          ::-webkit-scrollbar {
            width: 8px;
          }

          ::-webkit-scrollbar-track {
            background: var(--dm-navy-dark);
          }

          ::-webkit-scrollbar-thumb {
            background: var(--dm-gray-600);
            border-radius: 4px;
          }

          ::-webkit-scrollbar-thumb:hover {
            background: var(--dm-gold);
          }

          /* High Contrast Elements */
          .dm-contrast-high {
            color: var(--dm-white);
            font-weight: 600;
          }

          /* Glassmorphism Effect */
          .dm-glass {
            background: rgba(255, 255, 255, 0.08);
            backdrop-filter: blur(20px);
            border: 1px solid rgba(255, 255, 255, 0.15);
          }

          /* Interactive Elements */
          .dm-interactive {
            cursor: pointer;
            transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
          }

          .dm-interactive:hover {
            transform: scale(1.02);
          }

          .dm-interactive:active {
            transform: scale(0.98);
          }
        `}</style>
        <div className="min-h-screen flex w-full max-w-full overflow-hidden">
          <Sidebar className="dm-border-r dm-border-gray-700 dm-bg-navy-dark">
            <SidebarHeader className="border-b dm-border-gray-700 p-4 dm-bg-navy-dark">
              <Link to={createPageUrl("index")} className="flex items-center justify-center group transition-all duration-300">
                <img 
                  src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68d309b7748aa8ae449566fe/3c5e30d2b_logo.png" 
                  alt="Disruptors Media Logo"
                  className="h-10 w-auto transition-transform duration-300 group-hover:scale-105"
                />
              </Link>
            </SidebarHeader>
            
            <SidebarContent className="p-6 flex flex-col justify-between overflow-y-auto">
              <div className="space-y-8">
                <SidebarGroup>
                  <SidebarGroupLabel className="text-xs font-bold dm-text-gold uppercase tracking-widest px-3 py-2 font-display">
                    Business Brain
                  </SidebarGroupLabel>
                  <SidebarGroupContent className="space-y-2">
                    <SidebarMenu>
                      {navigationItems.map((item, index) => (
                        <SidebarMenuItem key={item.title} className="animate-fade-in-up" style={{ animationDelay: `${index * 50}ms` }}>
                          <SidebarMenuButton 
                            asChild 
                            className={`group relative rounded-xl mb-1 transition-all duration-300 font-body overflow-hidden ${
                              location.pathname === item.url 
                                ? 'dm-bg-gold dm-text-navy shadow-lg' 
                                : 'hover:bg-gray-700/50 dm-text-gray-300 hover:dm-text-white'
                            }`}
                          >
                            <Link to={item.url} className="flex items-center gap-3 px-4 py-3 relative">
                              {location.pathname === item.url && (
                                <div className="absolute left-0 top-2 bottom-2 w-1 dm-bg-navy rounded-r-full"></div>
                              )}
                              <item.icon className={`w-5 h-5 transition-all duration-300 relative z-10 ${
                                location.pathname === item.url ? 'dm-text-navy' : 'dm-text-gray-400 group-hover:dm-text-gold'
                              }`} />
                              <span className="font-medium relative z-10 transition-all duration-300">{item.title}</span>
                              <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/5 to-transparent translate-x-[-100%] group-hover:translate-x-[100%] transition-transform duration-700"></div>
                            </Link>
                          </SidebarMenuButton>
                        </SidebarMenuItem>
                      ))}
                    </SidebarMenu>
                  </SidebarGroupContent>
                </SidebarGroup>
              </div>

              <div className="mt-auto">
                <div className="relative mb-6">
                  <div className="absolute inset-0 flex items-center">
                    <div className="w-full border-t dm-border-gray-700"></div>
                  </div>
                </div>
                <SidebarMenu>
                  <SidebarMenuItem>
                    <SidebarMenuButton
                      asChild
                      className={`group relative rounded-xl mb-1 transition-all duration-300 font-body overflow-hidden ${
                        location.pathname === profileItem.url 
                          ? 'dm-bg-gold dm-text-navy shadow-lg' 
                          : 'hover:bg-gray-700/50 dm-text-gray-300 hover:dm-text-white'
                      }`}
                    >
                      <Link to={profileItem.url} className="flex items-center gap-3 px-4 py-3 relative">
                        {location.pathname === profileItem.url && (
                          <div className="absolute left-0 top-2 bottom-2 w-1 dm-bg-navy rounded-r-full"></div>
                        )}
                        <profileItem.icon className={`w-5 h-5 transition-all duration-300 ${
                          location.pathname === profileItem.url ? 'dm-text-navy' : 'dm-text-gray-400 group-hover:dm-text-gold'
                        }`} />
                        <span className="font-medium transition-all duration-300">{profileItem.title}</span>
                        <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/5 to-transparent translate-x-[-100%] group-hover:translate-x-[100%] transition-transform duration-700"></div>
                      </Link>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                </SidebarMenu>
              </div>
            </SidebarContent>
          </Sidebar>

          <main className="flex-1 dm-bg-navy-dark overflow-hidden min-w-0 relative">
            <div className="absolute inset-0 bg-gradient-to-br from-yellow-500/5 via-transparent to-blue-500/5 pointer-events-none"></div>
            
            <header className="dm-bg-navy-light/90 backdrop-blur-xl border-b dm-border-gray-700 px-4 py-3 md:hidden sticky top-0 z-10">
              <div className="flex items-center gap-4">
                <SidebarTrigger className="hover:bg-gray-800/50 p-2 rounded-lg transition-all duration-300 flex-shrink-0 dm-text-gray-400 hover:dm-text-gold" />
                <img 
                  src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68d309b7748aa8ae449566fe/3c5e30d2b_logo.png" 
                  alt="Disruptors Media Logo"
                  className="h-8 w-auto"
                />
              </div>
            </header>

            <div className="flex-1 overflow-auto w-full h-full">
              <div className="w-full max-w-full h-full relative z-10">
                {children}
              </div>
            </div>
          </main>
        </div>
      </SidebarProvider>
  );
}

